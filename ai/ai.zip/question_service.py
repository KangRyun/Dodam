"""내부 대화 질문 생성 서비스 (S15P11B209-183).

역할: BE 내부 계약 요청 → GMS 대화 LLM 호출(제한적 재시도) → 계약 응답 조립.

루프 위치 확정(2026-07-23, BE 283 머지 근거):
- 대화 루프(질문 반복·질문 수 상한·세션 잠금·폴백 템플릿)는 BE
  ConversationQuestionService가 소유한다.
- 이 서버는 상태 없는 '질문 1건 생성기' — 세션 상태를 들고 있지 않고,
  요청에 담긴 문맥(recentMessages·detectedObjects)만 사용한다.
  근거 정리: _workspace/183_ai_loop-decision.md

재시도 예산(BE read timeout 15초 안쪽):
- 시도당 GMS timeout 4s × 최대 3회(최초 1 + 재시도 2) + 지수 백오프(0.5s + 1.0s)
  = 최악 13.5s < 15s. 초과하면 BE가 READ_TIMEOUT으로 끊고 폴백 템플릿을 저장한다.
- 일시 오류(연결 실패·타임아웃·5xx)만 재시도한다. 4xx(키 오류·잘못된 요청·429)는
  즉시 실패. reason: 4xx는 다시 보내도 같은 결과라 예산만 소모하고,
  429는 짧은 백오프 재시도가 오히려 부하를 키운다.
  (대안 검토: 429만 1회 재시도 — 트래픽이 커지면 재검토. 지금은 BE 폴백이 있어 불필요.)

가드레일:
- 로그에는 request_id·에러 유형·시도 횟수만 남긴다.
  프롬프트(아이 발화 포함)·GMS 키·생성된 질문 원문은 절대 로그 금지.
"""

from __future__ import annotations

import logging
import re
import time
from dataclasses import dataclass

from openai import APIConnectionError, APIStatusError, OpenAIError

import config
import conversation_stop_intent
import crisis_detection
import crisis_guidance
import llm_client
import prompt_injection
import prompts_registry  # 답변 칩 프롬프트 로딩·버전 추적 (S15P11B209-788)
import question_quality
import question_safety
from gms import get_client
from internal_contracts import (
    DetectedObject,
    QuestionOption,
    QuestionRequest,
    QuestionResponse,
    SafetyResult,
)

logger = logging.getLogger(__name__)

# 내부 계약 경로도 draft 경로(llm_client)와 같은 프롬프트 파일을 쓴다 — 버전도 그대로 따른다.
# 버전은 prompts_registry가 중앙 관리하는 통합 버전이다(S15P11B209-595).
# 이건 '대화 경로가 쓸 수 있는 파일 전부'의 버전이다. GMS를 실제로 부른 응답에는 이번에 고른
# 활동 변형만 담은 llm_client.prompt_version_for(activityType)를 싣는다(S15P11B209-786) —
# 두 변형을 모두 적으면 어느 쪽으로 뽑힌 결과인지 사후에 구분할 수 없다.
# 위기·인젝션 결정적 응답은 프롬프트를 쓰지 않으므로 이 전체 버전을 그대로 남긴다.
PROMPT_VERSION = llm_client.PROMPT_VERSION


class UpstreamError(Exception):
    """GMS 최종 실패(재시도 소진 또는 재시도 불가 오류).

    엔드포인트가 502로 매핑 → BE Type.OTHER → 폴백 템플릿 저장 경로.
    """

    def __init__(self, error_code: str, cause_type: str):
        super().__init__(error_code)
        self.error_code = error_code  # AI_UPSTREAM_UNAVAILABLE | AI_UPSTREAM_REJECTED | AI_EMPTY_COMPLETION
        self.cause_type = cause_type  # 원인 예외 클래스명(내용 아님 — 로그 안전)


class SafetyBlockedError(Exception):
    """안전 정책 차단. 엔드포인트가 422 AI_SAFETY_POLICY_BLOCKED로 매핑 →
    BE가 저장 없이 사용자 422로 종료하는 경로."""

    def __init__(self, block_reason_code: str, rule_version: str):
        super().__init__(block_reason_code)
        self.block_reason_code = block_reason_code
        self.rule_version = rule_version


# ── 프롬프트 조립 (S15P11B209-589) ──────────────────────────────
# 이전 placeholder는 무맥락 고정 시스템 프롬프트 + "[상황] 아이가 방금 그림을 그렸어요"
# 고정 문구를 써서 첫 질문이 매번 비슷하게 고정됐다(첫 질문 고정 현상).
# 이제 draft 경로가 이미 검증한 프롬프트(first_question.txt·conversations.txt)를 재사용해
# 그림 탐지 객체·대화 문맥 기반으로 생성한다 — 두 경로를 한 프롬프트로 통일.
# ⚠️ 내부 계약엔 아이 이름이 없다(개인정보 최소화) → 항상 "너"로 부른다.

# 연령(난이도)별 질문 규칙은 ai/prompts/conversation_tone.txt가 소유한다(S15P11B209-786).
# 원래 여기 코드 상수(_DIFFICULTY_RULES)였는데 프롬프트 파일로 옮겼다:
#   ① 아이에게 그대로 들려줄 문구인데 prompts_registry 버전 추적 밖이었다,
#   ② 이 블록을 붙이는 곳이 여기뿐이라 draft 경로엔 연령별 말투가 아예 없었다,
#   ③ 프롬프트 파일의 고정 '말투:' 절과 같은 말을 두 번 해 서로 어긋났다(구 PRESCHOOL
#      "10자 안팎"은 대화 프롬프트의 "반응한 다음 질문을 이어줘"와 동시에 만족할 수 없었다).
# 이제 llm_client가 프롬프트 조립 시 난이도 구획 하나를 골라 싣는다.


def _truncate_description(text: str | None) -> str | None:
    """그림 서술을 프롬프트에 넣기 전 길이 상한으로 자른다(S15P11B209-704).

    VLM 프롬프트가 2~4문장을 지시하므로 정상 범위는 손대지 않는다. 모델이 길게 답해
    [그림 분석 결과] 절이 다른 지시를 압도하는 경우만 막는다. 잘린 사실은 말줄임표로
    남긴다 — 잘랐다는 것을 숨기면 "왜 뒷부분을 안 봤지"를 나중에 추적할 수 없다.
    """
    if not text:
        return None
    stripped = text.strip()
    if not stripped:
        return None
    limit = config.QUESTION_DESCRIPTION_MAX_CHARS
    if len(stripped) <= limit:
        return stripped
    return stripped[:limit].rstrip() + "…"


# ── 탐지 이름의 근거 대조 (S15P11B209-918) ──────────────────────
# 자유 그림(sketch 가중치)은 오탐이 잦다. 탐지 문턱은 YOLO_CONF_THRESHOLD=0.20 이라
# 머리카락이 '덤불'로, 머리가 '달'로 잡힌 채 후보에 남는다. 그 이름이 프롬프트에 들어가면
# 모델은 그것을 실제 대상으로 단정한다(2026-08-05 실측: 덤불 10/10, 달 5/5).
#
# 이름의 근거는 탐지 목록이 아니라 그림 서술이다 — activity_block [[ART_DIARY]]가 이미
# 그렇게 적어 두었는데, 정작 코드는 서술과 대조하지 않고 신뢰도만 보고 이름을 실었다.
# 이제 자유 그림에서는 **서술 원문에 실제로 등장하는 이름만** 프롬프트에 싣는다.
#
# ⚠️ HTP에는 적용하지 않는다. 주제가 활동으로 정해져 있고 HTP 전용 가중치는 sketch보다
#    정확하다. 게다가 표시명이 서술 표현과 다른 정상 케이스가 있다('집의 문' vs "네모난 것").


def _hangul(char: str) -> bool:
    return "가" <= char <= "힣"


def _mentioned_in(name: str | None, description: str | None) -> bool:
    """탐지 표시명이 서술 문장에 실제로 등장하는가.

    단순 부분 문자열이면 '해'가 "칠해져 있어요"에 걸린다. 앞 글자가 한글이면 다른 낱말의
    일부로 보고 세지 않는다 — 탐지 이름은 명사라 문장에서 띄어쓰기나 문장 첫머리에 온다.
    (뒤쪽은 조사가 붙으므로 경계를 두지 않는다: "해가"·"머리카락은")
    """
    if not name or not description:
        return False
    needle = name.strip()
    if not needle:
        return False
    start = description.find(needle)
    while start != -1:
        if start == 0 or not _hangul(description[start - 1]):
            return True
        start = description.find(needle, start + 1)
    return False


def _nameable_objects(req: QuestionRequest) -> list[DetectedObject]:
    """프롬프트에 이름을 실어도 되는 탐지 객체(S15P11B209-918).

    자유 그림은 서술이 뒷받침하는 이름만 남긴다. 서술이 없으면 아무것도 뒷받침하지 못하므로
    빈 목록이 된다 — 이때는 이름을 단정하는 대신 그림 전체를 여는 질문으로 간다.
    """
    if req.activity_type != "ART_DIARY":
        return list(req.detected_objects)
    description = _truncate_description(req.drawing_description)
    return [
        o
        for o in req.detected_objects
        if _mentioned_in(o.object_name or o.object_code, description)
    ]


def _drawing_analysis_text(req: QuestionRequest) -> str | None:
    """첫 질문 프롬프트의 {drawing_analysis} 재료를 만든다.

    그림 서술(VLM)이 있으면 서술을 먼저, 탐지 객체 목록을 뒤에 붙인다(S15P11B209-704).

    reason: 객체 이름만으로는 "왜 하늘을 검게 칠했어?"·"사람이 웃고 있네" 같은
      색·표정·구도 기반 질문이 나올 수 없다. 그 정보는 VLM 서술에만 있다.
      둘을 함께 주는 이유는 서술이 놓친 객체를 목록이 보완하고, 목록이 설명하지 못하는
      맥락을 서술이 채우기 때문이다.
    ⚠️ 서술이 없으면(BE 미전달·분석 실패) 기존 객체 목록 동작을 그대로 유지한다.
    ⚠️ 자유 그림의 목록은 서술이 뒷받침하는 이름만 남는다(S15P11B209-918). 대상 선택
       (_target_for_purpose)과 같은 규칙을 쓴다 — 프롬프트가 이름을 볼 수 있는데 대상만
       막으면, 모델은 목록에서 이름을 집어 온다(918 재현의 '달' 경로가 그랬다).
    """
    description = _truncate_description(req.drawing_description)
    nameable = _nameable_objects(req)
    objects = (
        ", ".join(o.object_name or o.object_code for o in nameable) if nameable else None
    )
    if description and objects:
        return f"{description}\n(그림에서 찾은 것: {objects})"
    return description or objects


def _format_objects_for_log(req: QuestionRequest) -> str:
    """프롬프트에 실제로 들어간 객체 문자열(S15P11B209-710).

    `_drawing_analysis_text`와 같은 값을 남긴다 — 이 줄이 "LLM이 무엇을 보고 질문했는가"에
    대한 유일한 확정 증거다. 상세 로그가 꺼져 있으면 개수만 남긴다(아동 그림 내용 보호).
    """
    material = _drawing_analysis_text(req)
    if material is None:
        return "(없음)"
    if not config.DETECTION_LOG_DETAIL:
        # ⚠️ 서술은 객체 이름보다 훨씬 구체적인 아동 그림 내용이다(색·표정·구도).
        #   상세 로그가 꺼져 있으면 **내용은 남기지 않되**, 서술이 들어갔다는 사실은 남긴다.
        #   그래야 "LLM이 무엇을 보고 질문했는가"를 나중에 내용 없이도 구분할 수 있다.
        parts = [f"{len(req.detected_objects)}건"] if req.detected_objects else []
        if _truncate_description(req.drawing_description):
            parts.append("서술있음")
        return "+".join(parts) if parts else "(없음)"
    return material


def _format_target_for_log(target: DetectedObject | None) -> str:
    """대상 객체를 로그 한 조각으로. 코드는 내부 Enum이라 상세 여부와 무관하게 남긴다."""
    if target is None:
        return "-"
    if not config.DETECTION_LOG_DETAIL:
        return target.object_code
    return f"{target.object_name or target.object_code}({target.confidence:.2f})"


# ── 이미 물어본 질문 (S15P11B209-921) ───────────────────────────
# 프롬프트에 나열할 이전 AI 질문 수. 전부 실으면 지시 블록이 대화 이력만큼 길어져
# 다른 규칙을 밀어낸다. 반복은 대개 직전 몇 개와 겹치므로 최근 것만 본다.
_MAX_ASKED_QUESTIONS = 5


def _asked_questions(req: QuestionRequest) -> list[str]:
    """이 대화에서 이미 건넨 AI 질문 원문(오래된 순, 최대 5건).

    reason: 구 [[ASKED_ALREADY]]는 "이미 이야기한 것은 다시 묻지 마"라고만 하고 무엇을
    물었는지 알려주지 않았다. 실제로 걸러지는 건 askedObjectCodes 뿐이라, 대상 객체가 없는
    질문끼리는 겹쳐도 막을 수단이 없었다. 그림일기는 그리기를 멈출 때마다 질문을 새로
    요청해(S15P11B209-922) 아이가 답하기 전에도 이 구멍이 열린다.
    """
    texts = [
        (m.text or "").strip()
        for m in req.recent_messages
        if (m.sender_type or "").upper() == "AI" and (m.text or "").strip()
    ]
    return texts[-_MAX_ASKED_QUESTIONS:]


# ── 대상 그룹 (S15P11B209-921) ──────────────────────────────────
# 사람 전체(PERSON)와 신체 부위(PERSON_*)는 '한 사람'이라는 하나의 대상이다. 부위는 그
# 사람의 속성이지 옆에 있는 다른 물건이 아니다. 반복 판단·대상 개수 판단에서 함께 묶는다.
#
# ⚠️ 집·나무는 묶지 않는다. 지붕·문·창문은 PDI 표준이 각각 물어보는 대상이고
#    (htp_question_bank [[HOUSE]]), 묶으면 지붕을 물어본 순간 문·창문이 후보에서 사라져
#    713이 만든 '주제 안에서 하나씩 넓혀 가기'가 통째로 죽는다.


def _object_group(object_code: str) -> str:
    """반복·개수 판단에 쓸 대상 그룹 키. 사람 부위만 전체로 접는다."""
    return "PERSON" if object_code.startswith("PERSON_") else object_code


def _target_group_count(req: QuestionRequest) -> int:
    """이름을 쓸 수 있는 탐지 객체가 몇 '대상'인가(부위는 접어서 센다)."""
    return len({_object_group(o.object_code) for o in _nameable_objects(req)})


def _last_child_index(req: QuestionRequest) -> int | None:
    """가장 최근 아이 발화(텍스트 있는 것)의 인덱스. 없으면 None(=첫 질문)."""
    for index in range(len(req.recent_messages) - 1, -1, -1):
        message = req.recent_messages[index]
        if (message.sender_type or "").upper() == "CHILD" and (message.text or "").strip():
            return index
    return None


# 인젝션으로 걸린 과거 발화를 원문 대신 넣는 중립 표시(S15P11B209-742).
_SANITIZED_UTTERANCE = "(아이의 말)"


def _history_dicts(messages: list) -> list[dict]:
    """recent_messages → llm_client._format_history가 받는 [{"role","content"}] 형태로.

    과거 아이 발화 중 프롬프트 인젝션에 걸리는 것은 원문 대신 중립 표시로 치환한다(S15P11B209-742).
    현재 발화의 인젝션은 generate가 앞단에서 막지만, 과거 발화는 BE에 저장돼 history로 다시
    흘러들 수 있어 여기서 한 번 더 걸러 원문이 LLM에 닿지 않게 한다.
    """
    turns: list[dict] = []
    for m in messages:
        if not (m.text or "").strip():
            continue
        is_child = (m.sender_type or "").upper() == "CHILD"
        content = m.text
        if is_child and prompt_injection.scan(m.text):
            content = _SANITIZED_UTTERANCE
        turns.append({"role": "user" if is_child else "assistant", "content": content})
    return turns


# ── HTP 주제·대상 지시 블록 (S15P11B209-713) ────────────────────
# 프롬프트가 '지금 무슨 주제인지'를 몰라 다른 주제 명사를 집어오던 버그(709 원인 4)를 막는다.
# activityType·drawingSubject를 프롬프트에 못박아 다른 주제로 새지 않게 하고, 고른 대상 하나만 묻게 한다.
#
# ⚠️ 무엇을 못 박는가 — S15P11B209-788 B의 핵심 구분:
#   HTP는 아이가 그릴 주제가 집·나무·사람으로 정해져 있다. 그래서 **'지금 어느 주제 단계인가'는
#   활동이 정한 사실**이고 아이가 뒤집을 수 없다(다른 주제로 새면 709 계열 재발).
#   그러나 **그 그림 안의 각 부분이 무엇인지는 아이가 정한다** — 탐지가 '문'이라 해도 아이가
#   창문이라 하면 창문이다. 예전 문구("아이는 '집'을 그렸어. 이건 정해진 사실이야")는 이 둘을
#   뭉쳐 못 박아, 공통 프롬프트(conversation_common)의 "무조건 아이 말을 믿어"와 정면 충돌했다.
#   718 부정 재질문은 아이가 **칩(CHIP_NO)** 으로 부정한 경우만 처리하므로, **말로 정정한 경로**가
#   그 충돌에 그대로 노출됐다.
_SUBJECT_KO = {"HOUSE": "집", "TREE": "나무", "PERSON": "사람"}


def _other_subjects(subject: str | None) -> str:
    """현재 주제를 뺀 나머지 HTP 주제 이름(S15P11B209-788 H).

    예전 문구는 "다른 주제(집·나무·사람)로 넘어가지 마"라고 세 주제를 통째로 나열해
    **현재 주제까지 금지 목록에 넣었다** — 집 단계에서 집을 묻지 말라고 읽힐 수 있었다.
    """
    return "·".join(name for code, name in _SUBJECT_KO.items() if code != subject)


# 지시 문구는 활동별 activity_block 파일이 소유한다(832 이관 · 993 활동별 분리). 코드 안
# 문자열이던 것을 옮긴 이유: GPT에 나가는 지시문인데 prompts_registry 버전 추적 밖이라,
# 788에서 문구를 크게 고쳐도 promptVersion이 그대로였다. 993에서 파일을 활동별로 갈랐다 —
# 한 활동에 맞춘 수정이 다른 활동에 실리지 않게(SINGLE_TARGET 등 같은 키에 활동별 내용).
ACTIVITY_BLOCK_BY_ACTIVITY = {
    "HTP": "activity_block_htp",
    "ART_DIARY": "activity_block_diary",
}


def _activity_block_name(activity_type: str | None) -> str:
    """이 활동이 쓰는 activity_block 파일 이름. 모르는 값은 기본(HTP)으로 둔다."""
    return ACTIVITY_BLOCK_BY_ACTIVITY.get(
        activity_type or "", ACTIVITY_BLOCK_BY_ACTIVITY["HTP"]
    )


def _block(activity_type: str | None, key: str, **values) -> str:
    """활동 블록 구획 하나를 치환해 돌려준다 — 활동별 파일에서 고른다(993)."""
    return prompts_registry.sections(_activity_block_name(activity_type))[key].format(
        **values
    )


def _target_line(req: QuestionRequest, target_name: str) -> str:
    """대상 객체 지시 한 줄 — 첫 질문에서만 '이것만'으로 좁힌다(S15P11B209-788 C).

    target_name은 아이 발화와 무관하게 신뢰도 최고순으로 뽑힌다(_target_for_purpose).
    아이가 이미 말한 뒤에도 "이 하나에 대해서만 물어봐"를 붙이면, 대화 프롬프트의
    "방금 한 말에서 이어지는 질문을 해. 갑자기 주제를 바꾸지 마"와 동시에 지시되어
    프롬프트가 스스로 "바꿔라/바꾸지 마라"를 요구한다.
    """
    key = "TARGET_FIRST" if _last_child_index(req) is None else "TARGET_FOLLOW_UP"
    return _block(req.activity_type, key, target=target_name)


def _activity_block(
    req: QuestionRequest,
    target: DetectedObject | None,
    *,
    reask_candidates: bool = False,
) -> str:
    """activityType·drawingSubject·대상 객체를 프롬프트 지시 블록으로 만든다.

    - HTP: '지금 어느 주제 단계인가'만 확정 사실로 못박아 다른 주제로 넘어가지 못하게 하고,
      그림 안의 각 부분 이름은 아이 말에 따르게 한다(S15P11B209-788 B).
      고른 대상이 있으면 그 하나만, 없으면 주제 그림 전체를 묻게 한다.
    - ART_DIARY: 주제 개념이 없고, 탐지 이름도 믿지 않게 한다 — sketch 가중치는 오탐이 잦아
      이름의 근거는 탐지 목록이 아니라 그림 서술과 아이 말이다.
    - activityType이 없으면(구 BE·주제 미전달) 주제 제약 없이 기존 동작을 유지한다.
    반복 방지: 이미 물어본 게 있으면 새로운 것을 묻도록 덧붙인다(대상 선택에서도 이미 배제됨).
    reask_candidates(S15P11B209-718): 아이가 탐지를 부정해 후보 칩으로 다시 묻는 경우, 보기 중에서
      고르도록 짧게 되묻는 지시를 덧붙인다(보기 내용은 칩으로 제시하므로 프롬프트엔 넣지 않는다).
    """
    subject_ko = _SUBJECT_KO.get(req.drawing_subject or "")
    target_name = (
        (target.object_name or target.object_code) if target is not None else None
    )
    lines: list[str] = []
    if req.activity_type == "HTP" and subject_ko:
        # 못 박는 것은 '활동 단계'다 — 그림 내용의 이름이 아니다(788 B).
        lines.append(
            _block(
                req.activity_type,
                "HTP",
                subject=subject_ko,
                other_subjects=_other_subjects(req.drawing_subject),
            )
        )
        lines.append(
            _target_line(req, target_name)
            if target_name
            else _block(req.activity_type, "HTP_WHOLE", subject=subject_ko)
        )
        # 부위가 대상이면 '누구 것인지'가 아니라 '어떻게 보이는지'를 묻게 한다(S15P11B209-918).
        if _is_person_part(target):
            lines.append(_block(req.activity_type, "PERSON_PART", target=target_name))
        # 이 주제의 첫마디는 주제에서 출발하게 한다(S15P11B209-959). 대상·전체 지시 뒤에
        # 두는 이유: 무엇을 물을지는 위 블록이 이미 정했고, 여기서 더하는 것은 "주제를
        # 이미 안다"는 사실 하나다. 앞에 두면 위 지시와 겹쳐 서로 밀어낸다.
        if _is_htp_opening(req):
            lines.append(_block(req.activity_type, "HTP_OPENING", subject=subject_ko))
    elif req.activity_type == "ART_DIARY":
        # 그림일기 탐지 모델(sketch)은 오탐이 잦다 — 이름의 근거는 탐지 목록이 아니라
        # 그림 서술과 아이 말이다(788 B, 활동별 판단).
        lines.append(_block(req.activity_type, "ART_DIARY"))
        if target_name:
            lines.append(_target_line(req, target_name))
            # 부위가 대상이면 부위 지시를 얹는다(S15P11B209-999). 같은 키지만 HTP 쪽
            #   [[PERSON_PART]]와 착지가 다르다 — 그쪽은 "그 사람의 생각·기분을 물어봐"로
            #   내려앉는데, 자유 그림은 부위 탐지 자체가 오탐인 경우가 많아 그 착지가 없는
            #   사람을 지어내는 쪽으로 샌다. 993이 파일을 가른 덕에 활동별로 나눠 쓸 수 있다.
            if _is_person_part(target):
                lines.append(_block(req.activity_type, "PERSON_PART", target=target_name))
        elif _last_child_index(req) is None:
            # 첫 질문인데 이름을 뒷받침할 근거가 없다 — 이름을 지어 부르지 말고 열린 질문을
            # 하게 한다(S15P11B209-918). 아이가 이미 말한 뒤라면 붙이지 않는다: 그 턴의
            # 지시는 "아이 말을 따라가"이고, 여기에 '열린 질문을 해'를 겹치면 서로 밀어낸다.
            lines.append(_block(req.activity_type, "ART_DIARY_OPEN"))
    elif target_name:
        lines.append(_block(req.activity_type, "TARGET_ONLY", target=target_name))
    if reask_candidates:
        lines.append(_block(req.activity_type, "REASK_CANDIDATES"))
    # 대상이 하나뿐이면 두 번째 대상을 지어내지 못하게 막는다(S15P11B209-921).
    # 반복 방지 지시("새로운 것을 물어봐")가 '다른 물건'으로 읽혀 사람 한 명 그림에서도
    # "옆에 있는 건 뭐야?"가 나왔다. 부위는 접어서 세므로 사람+머리+머리카락은 하나다.
    #
    # ⚠️ 두 구획의 내용은 활동별로 다르다(954에서 갈랐고, 993에서 파일 자체가 갈리며
    #    _DIARY 접미사 키를 없앴다 — 같은 키(SINGLE_TARGET·ASKED_ALREADY)를 각 파일이
    #    자기 활동의 내용으로 소유한다). 954의 판단은 그대로다: HTP는 정체·관계·사건·마음·
    #    앞일로, 자유 그림은 정체·관계·사건·경험·기억으로 잇는다.
    if _target_group_count(req) == 1:
        lines.append(_block(req.activity_type, "SINGLE_TARGET"))
    if req.asked_object_codes:
        lines.append(_block(req.activity_type, "ASKED_ALREADY"))
    # 이미 건넨 질문을 나열해 표현만 바꾼 반복을 막는다(S15P11B209-921).
    # 활동유형과 무관하게 붙인다 — HTP도 대상 객체 없는 질문끼리는 겹치는 것을 못 막는다.
    asked = _asked_questions(req)
    if asked:
        lines.append(
            _block(req.activity_type, "ASKED_QUESTIONS", questions="\n".join(f"  · {q}" for q in asked))
        )
    # 마지막 차례면 맺음말 성격을 준다(S15P11B209-976). 맨 뒤에 붙이는 이유는 HTP_OPENING과
    # 같다 — 무엇을 물을지는 위 블록들이 이미 정했고, 이 구획이 더하는 것은 '어떻게 맺을지'
    # 하나다. 앞에 두면 대상 지시와 겹쳐 서로 밀어낸다.
    if _is_last_question(req):
        lines.append(_block(req.activity_type, "LAST_QUESTION"))
    return "\n".join(lines)


def _build_messages(
    req: QuestionRequest,
    *,
    purpose: str | None = None,
    target: DetectedObject | None = None,
    reask_candidates: bool = False,
) -> list[dict]:
    """요청 문맥 → GMS messages. draft 프롬프트를 재사용해 컨텍스트 기반으로 생성한다.

    - 아이 발화가 아직 없으면: 첫 질문 프롬프트(그림 탐지 객체 기반).
    - 아이 발화가 있으면: 다음 질문 프롬프트(마지막 발화 + 그 이전 이력).
    연령대는 아이 나이를 넘기고, 난이도별 길이·어휘·말투 규칙을 덧붙인다.

    purpose·target을 넘기면 그대로 쓴다(generate가 응답과 동일한 값을 프롬프트에 싣기 위함).
    안 넘기면 여기서 계산한다 — _build_messages를 직접 호출하는 테스트 편의용(S15P11B209-713).
    """
    if purpose is None:
        purpose = _pick_question_purpose(req)
        if purpose == "OBJECT_DESCRIPTION":
            target = _target_for_purpose(req, purpose)

    age_band = str(req.child_age)
    drawing = _drawing_analysis_text(req)
    activity_block = _activity_block(req, target, reask_candidates=reask_candidates)
    last_child = _last_child_index(req)

    if last_child is None:
        system = llm_client.render_first_question_prompt(
            drawing,
            age_band=age_band,
            activity_block=activity_block,
            activity_type=req.activity_type,
            difficulty=req.difficulty,
            drawing_subject=req.drawing_subject,
        )
        trigger = llm_client.FIRST_QUESTION_TRIGGER
    else:
        utterance = req.recent_messages[last_child].text or ""
        history = _history_dicts(req.recent_messages[:last_child])
        system = llm_client.render_next_question_prompt(
            utterance,
            drawing_analysis=drawing,
            history=history,
            age_band=age_band,
            activity_block=activity_block,
            activity_type=req.activity_type,
            difficulty=req.difficulty,
            drawing_subject=req.drawing_subject,
        )
        trigger = llm_client.NEXT_QUESTION_TRIGGER

    return [
        {"role": "system", "content": system},
        {"role": "user", "content": trigger},
    ]


# ── 질문 목적 ↔ 대상 객체 ↔ 선택 Chip 정합성 (S15P11B209-594) ────
# 세 값이 서로 어긋나면 아동 화면에 엉뚱한 칩·객체가 붙는다. 목적을 먼저 정하고
# 대상 객체·칩을 그 목적에 맞춰 파생시켜 항상 일관되게 만든다.
#   - OBJECT_DESCRIPTION: 특정 객체를 묻는다 → 대상 객체 있음, 예/아니오/더 말하기 칩.
#   - DRAWING_CONTEXT: 그림 전체 맥락을 묻는다 → 대상 객체 없음, 실제/상상 칩.
#   - EXPRESSION: 마음·느낌을 묻는다 → 대상 객체 없음, 감정 칩.
#   - FOLLOW_UP: 아이 발화에 이어 묻는다 → 대상 객체 없음, 예/아니오/더 말하기 칩.
VALID_PURPOSES = {"OBJECT_DESCRIPTION", "DRAWING_CONTEXT", "EXPRESSION", "FOLLOW_UP"}

# 목적별 선택 Chip. 아동 화면에 그대로 노출되므로 쉽고 따뜻한 말만. code는 응답 안에서 유일.
_OPTIONS_BY_PURPOSE: dict[str, list[QuestionOption]] = {
    "OBJECT_DESCRIPTION": [
        QuestionOption(code="CHIP_YES", label="응, 맞아!"),
        QuestionOption(code="CHIP_NO", label="음, 아니야"),
        QuestionOption(code="CHIP_TELL_MORE", label="더 이야기해 줄래"),
    ],
    "DRAWING_CONTEXT": [
        QuestionOption(code="CHIP_REAL", label="진짜 있었던 일이야"),
        QuestionOption(code="CHIP_IMAGINE", label="상상해서 그렸어"),
        QuestionOption(code="CHIP_TELL_MORE", label="더 이야기해 줄래"),
    ],
    "EXPRESSION": [
        QuestionOption(code="CHIP_GOOD", label="좋아!"),
        QuestionOption(code="CHIP_SOSO", label="그냥 그래"),
        QuestionOption(code="CHIP_NOT_SURE", label="잘 모르겠어"),
    ],
    "FOLLOW_UP": [
        QuestionOption(code="CHIP_YES", label="응, 맞아!"),
        QuestionOption(code="CHIP_NO", label="음, 아니야"),
        QuestionOption(code="CHIP_TELL_MORE", label="더 이야기해 줄래"),
    ],
}


def _pick_question_purpose(req: QuestionRequest) -> str:
    """질문 목적 결정.

    아이가 이미 말했으면 그 말에 이어가는 FOLLOW_UP, 첫 질문이면 탐지 객체가 있을 때
    그 객체를 묻는 OBJECT_DESCRIPTION, 없으면 그림 전체를 묻는 DRAWING_CONTEXT.
    (EXPRESSION은 질문 내용 기반 분류가 필요해 후속 프롬프트 구조화 과제로 둔다.)
    """
    if any((m.sender_type or "").upper() == "CHILD" for m in req.recent_messages):
        return "FOLLOW_UP"
    if req.detected_objects:
        return "OBJECT_DESCRIPTION"
    return "DRAWING_CONTEXT"


def _options_for_purpose(purpose: str) -> list[QuestionOption]:
    """목적에 맞는 선택 Chip. 모르는 목적이면 무난한 예/아니오/더 말하기."""
    return list(_OPTIONS_BY_PURPOSE.get(purpose, _OPTIONS_BY_PURPOSE["FOLLOW_UP"]))


# 마음·느낌을 묻는 질문 표시어 (S15P11B209-650). 이 말이 있으면 EXPRESSION으로 보고 감정 칩을 붙인다.
# 목적 분류(_pick_question_purpose)는 EXPRESSION을 고르지 못했다 — 그건 생성 전엔 알 수 없고
# 생성된 문장 내용을 봐야 알 수 있어서다. 그래서 생성 후 문장으로 판별한다. 감정 칩이 안 어울리는
# 객체 질문("이 색 좋아?")까지 잡지 않도록 표시어를 마음·감정에 좁게 둔다.
_EMOTION_QUESTION_MARKERS = (
    "기분",
    "느낌",
    "마음",
    "행복",
    "슬펐",
    "슬퍼",
    "무서웠",
    "속상",
    "즐거웠",
    "설레",
)


def _is_expression_question(text: str) -> bool:
    """생성된 질문이 아이의 마음·느낌을 묻는지 간단 분류한다(감정 칩 정합용)."""
    return any(marker in text for marker in _EMOTION_QUESTION_MARKERS)


def _is_htp_opening(req: QuestionRequest) -> bool:
    """HTP에서 이 주제 그림의 '첫마디'인가(S15P11B209-959).

    HTP는 주제(집·나무·사람)마다 그림을 마친 뒤 대화가 새로 열리므로, 질문 수가 0이라는
    것은 곧 '이 주제의 첫 질문'이라는 뜻이다. 질문 수는 921이 그림일기에 쓴 판정과 같은
    조건이라 BE·FE 계약을 건드리지 않는다.

    ⚠️ 아이 발화가 없다는 조건을 함께 본다. 이 판정은 프롬프트에 '첫마디' 지시를 넣을지를
       가르는데, 프롬프트 갈래 자체는 질문 수가 아니라 아이 발화 유무로 정해진다
       (_build_messages의 last_child). 질문 수만 보면 질문 수가 0인 채 아이가 먼저 말한
       경로(FE 복원)에서 '아이 말을 따라가'는 지시와 '이번이 첫마디야'가 함께 실린다.
    """
    return (
        req.activity_type == "HTP"
        and req.current_question_count == 0
        and _last_child_index(req) is None
    )


def _is_last_question(req: QuestionRequest) -> bool:
    """이번 차례가 이 대화의 마지막 질문인가(S15P11B209-976).

    max_question_count 는 계약에 오래 있었지만(internal_contracts) 페이싱에는 한 번도 쓰이지
    않았다 — 모델은 자기가 몇 번 더 물을 수 있는지 모른 채 매 턴 새 소재를 열었고, 상한에
    닿는 순간 대화가 문장 중간에서 끊기듯 끝났다.

    current_question_count 는 '이미 저장된 질문 수'라(BE QuestionPersistenceService),
    지금 만들 질문의 번호는 그 값 + 1 이다. 따라서 마지막 차례는 count == max - 1.

    ⚠️ 등호가 아니라 >= 로 본다. 상한을 넘긴 요청은 BE가 409로 막지만(ConversationSession
       .canAskQuestion), 그 방어가 무너져 들어온 요청까지 '마지막이 아닌 것'으로 취급하면
       대화가 끝없이 열린 채로 이어진다.
    """
    return req.current_question_count >= req.max_question_count - 1


def _target_for_purpose(req: QuestionRequest, purpose: str) -> DetectedObject | None:
    """대상 객체는 특정 객체를 묻는 OBJECT_DESCRIPTION일 때만 붙인다(목적과 정합).

    요청의 detectedObjects는 BE가 이미 검증(objectCode·confidence·정규화 bbox)한 값이라
    그대로 되돌려도 계약을 통과한다.

    선택 규칙(S15P11B209-713):
    - 이미 물어본 객체(askedObjectCodes)는 후보에서 뺀다 → 같은 것을 두 번 묻지 않는다.
    - HTP면 현재 주제 그룹 객체(집 단계=HOUSE·HOUSE_*)를 먼저 고른다. 주제 객체가 없을 때만
      배경(SCENERY) 등 나머지에서 고른다(결정: 주제 우선·소진 후 배경). 집 단계에서 배경 나무가
      대뜸 대상이 되어 "이 나무는?"이 나오던 709 경로가 이걸로 대부분 사라진다.
    - 남은 후보 중 신뢰도 최고를 고른다. 후보가 없으면 None(호출부가 그림 전체 질문으로 전환).

    선택 규칙 추가(S15P11B209-918):
    - 자유 그림은 서술이 뒷받침하는 이름만 후보가 된다(_nameable_objects). 근거 없는 이름을
      대상으로 못 박으면 오탐이 확정 사실로 아이에게 나간다.
    - HTP 사람은 전체(PERSON)를 부위(PERSON_*)보다 먼저 고른다. 사람 그림은 부위 라벨이
      열댓 개라 신뢰도만 보면 부위가 뽑히는데, 부위 하나로 좁힌 지시가 사람 질문 뱅크의
      "누구를 생각하면서 그렸어?" 방향과 만나 "이 머리는 누구의 머리야?"가 됐다.
      집·나무는 그대로 둔다 — 지붕·문·창문은 PDI 표준 문항의 대상이고, 소유격 문제를
      만드는 것은 신체 부위다.

    선택 규칙 추가(S15P11B209-999):
    - 그림일기에서 아이가 방금 이름을 바로잡았으면 그 말이 탐지보다 앞선다
      (_retarget_for_correction). HTP는 그대로 둔다 — 그쪽 부위 라벨은 신뢰도 상위라
      부위를 대상으로 두는 것이 맞고, PDI 문항도 부위를 실제로 묻는다.
    """
    # ⚠️ 정정 재선택도 목적 안에서만 한다. 밖으로 나가면 FOLLOW_UP 응답에 대상 객체가 붙어
    #    _is_consistent(계약 사전 방어)가 통째로 실패한다 — 아이는 폴백 템플릿을 받는다.
    if purpose != "OBJECT_DESCRIPTION":
        return None
    target = _select_target(req, purpose)
    if req.activity_type == "ART_DIARY":
        return _retarget_for_correction(req, target)
    return target


def _select_target(req: QuestionRequest, purpose: str) -> DetectedObject | None:
    """탐지 목록에서 대상 하나를 고른다(정정 반영 전의 원래 선택)."""
    if purpose != "OBJECT_DESCRIPTION" or not req.detected_objects:
        return None
    # 물어본 대상은 '그룹'으로 뺀다(S15P11B209-921) — 사람을 물어본 뒤 머리를 대상으로
    # 잡으면 아이에겐 같은 사람을 또 묻는 것으로 들린다. 집·나무 부위는 묶지 않는다.
    asked = {_object_group(code) for code in req.asked_object_codes}
    available = [
        o for o in _nameable_objects(req) if _object_group(o.object_code) not in asked
    ]
    if not available:
        return None
    if req.activity_type == "HTP" and req.drawing_subject:
        subject = req.drawing_subject
        subject_objs = [
            o
            for o in available
            if o.object_code == subject or o.object_code.startswith(f"{subject}_")
        ]
        if not subject_objs and _is_htp_opening(req):
            # 이 주제의 첫 질문은 주제 밖으로 내보내지 않는다(S15P11B209-959). 집 그림에
            # 배경 나무가 잡히면 폴백이 그 나무를 대상으로 삼고, TARGET_FIRST가 "이 하나에
            # 대해서만"을 강제해 첫 질문이 통째로 나무 질문이 됐다 — 아이는 방금 집을
            # 그렸는데 첫마디가 나무다. None을 돌려 주제 전체를 여는 질문으로 보낸다.
            #
            # 첫 질문에만 건다. 대화가 시작된 뒤에는 주제 객체가 떨어졌을 때 배경으로
            # 넓히는 편이 낫다(713의 '주제 우선·소진 후 배경'을 그대로 둔다).
            return None
        pool = subject_objs or available
        if subject == "PERSON":
            whole = [o for o in pool if o.object_code == "PERSON"]
            pool = whole or pool
    else:
        pool = available
    return max(pool, key=lambda o: o.confidence)


def _is_person_part(target: DetectedObject | None) -> bool:
    """대상이 사람 그림의 '부위'인가(전체 PERSON은 아니다). S15P11B209-918."""
    return target is not None and target.object_code.startswith("PERSON_")


# ── 탐지 부정 시 후보 칩 재질문 (S15P11B209-718) ──────────────────
# 아이가 "아니야"(CHIP_NO)로 탐지를 부정하면, 이미 탐지된 다른 객체를 후보 칩으로 다시 묻는다.
# 신뢰도 하한(YOLO_CONF_THRESHOLD)은 건드리지 않는다 — 후보는 '이미 탐지된' detectedObjects에서만 뽑는다.
_NEGATION_CODE = "CHIP_NO"
_ESCAPE_CODE = "CAND_NONE"  # "이 중에 없어" — 후보를 모두 거부하는 탈출 칩
_MAX_CANDIDATES = 3


def _last_child_selected_codes(req: QuestionRequest) -> list[str]:
    """가장 최근 아이 메시지의 선택 칩 코드(없으면 빈 목록)."""
    for message in reversed(req.recent_messages):
        if (message.sender_type or "").upper() == "CHILD":
            return list(message.selected_option_codes or [])
    return []


def _negation_count(req: QuestionRequest) -> int:
    """아이가 최근 문맥에서 CHIP_NO로 부정한 횟수(연속 부정 방지 판단용)."""
    return sum(
        1
        for m in req.recent_messages
        if (m.sender_type or "").upper() == "CHILD"
        and m.selected_option_codes
        and _NEGATION_CODE in m.selected_option_codes
    )


def _candidate_options(req: QuestionRequest) -> list[QuestionOption]:
    """부정 재질문용 후보 칩 — 이미 탐지된 객체 중 아직 안 물어본 상위 3개 + 탈출 칩.

    라벨은 표시명(object_name, S15P11B209-711)을 쓴다 — 내부 코드·영문을 아동 화면에 노출하지
    않는다. 표시명이 없는 객체는 후보에서 뺀다(코드 노출 금지). 후보가 하나도 없으면 빈 목록.
    """
    asked = set(req.asked_object_codes)
    pool = [
        o
        for o in req.detected_objects
        if o.object_code not in asked and (o.object_name or "").strip()
    ]
    pool.sort(key=lambda o: o.confidence, reverse=True)
    top = pool[:_MAX_CANDIDATES]
    if not top:
        return []
    options = [
        QuestionOption(code=f"CAND_{index}", label=o.object_name)
        for index, o in enumerate(top, start=1)
    ]
    options.append(QuestionOption(code=_ESCAPE_CODE, label="이 중에 없어"))
    return options


# ── 질문 내용 맞춤 답변 칩 (S15P11B209-747, 방향 D 혼합) ─────────
# 목적별 고정 칩(_OPTIONS_BY_PURPOSE)은 질문 내용과 안 맞는다("무슨 색?"에 응/아니야). 그래서
# 질문 유형(색·무엇·누구·어디)을 규칙으로 분류해 맞춤 칩을 주고(B), 규칙에 안 걸리는 wh-질문은
# LLM 2차 호출로 후보를 받는다(A). 둘 다 없으면 목적별 generic으로 폴백. 어느 경로든 마지막에
# 열린 탈출 '더 이야기해 줄래'를 붙여 아이가 선택지에 갇히지 않게 한다.
_TELL_MORE = QuestionOption(code="CHIP_TELL_MORE", label="더 이야기해 줄래")
_COLOR_CHIPS = ["빨간색", "노란색", "파란색"]  # 큐레이션 안전 라벨(우리 값이라 안전검증 불필요)
_WHO_CHIPS = ["엄마", "아빠", "나", "친구"]
_WHERE_CHIPS = ["집 안", "집 밖", "방 안"]

_RE_COLOR = re.compile(r"무슨\s*색|어떤\s*색|색깔|색이(?:야|니|에요|예요)")
_RE_WHO = re.compile(r"누구|누가")
_RE_WHERE = re.compile(r"어디")
_RE_WHAT = re.compile(r"뭐야|뭐를|무엇|무슨\s*그림|어떤\s*그림|뭘\s*그렸")
# wh-의문사 — 있으면 예/아니오형이 아니다(규칙 미분류 시 LLM으로 넘긴다).
_RE_WH = re.compile(r"무엇|뭐|무슨|어떤|누구|누가|어디|왜|어떻게|언제|몇")


def _labeled_chips(labels: list[str], *, escape: str | None) -> list[QuestionOption]:
    """라벨 목록 → code 유일한 QuestionOption. 항상 열린 탈출로 끝낸다(escape 있으면 그것 + 더 이야기)."""
    chips = [
        QuestionOption(code=f"CHIP_C{i}", label=label)
        for i, label in enumerate(labels, start=1)
    ]
    if escape:
        chips.append(QuestionOption(code="CHIP_OTHER", label=escape))
    chips.append(_TELL_MORE)
    return chips


def _content_chips(text: str, req: QuestionRequest) -> list[QuestionOption] | None:
    """질문 유형을 규칙으로 분류해 맞춤 칩(B). 못 맞추면 None.

    색·누구·어디는 큐레이션 라벨, '무엇'은 이미 탐지된 객체 후보(718 로직 재사용)를 쓴다.
    감정(기분/느낌)은 상위에서 EXPRESSION(650)으로 처리하므로 여기서 다루지 않는다.
    """
    if _RE_COLOR.search(text):
        return _labeled_chips(_COLOR_CHIPS, escape="다른 색이야")
    if _RE_WHO.search(text):
        return _labeled_chips(_WHO_CHIPS, escape="다른 사람이야")
    if _RE_WHERE.search(text):
        return _labeled_chips(_WHERE_CHIPS, escape="다른 데야")
    if _RE_WHAT.search(text):
        return _candidate_options(req) or None  # 탐지 후보 + '이 중에 없어'
    return None


def _safe_chip_labels(raw_lines: list[str]) -> list[str]:
    """LLM이 준 후보 줄을 아동 안전 라벨로 정화한다(747 · 안전 파이프라인 596/597 재사용).

    각 줄을 question_safety로 판정·정화하고 차단·빈값·너무 긴 것은 버린다. 아동 화면에 그대로
    나가는 텍스트라 통과한 것만 라벨로 쓴다(최대 3개, 중복 제거).
    """
    labels: list[str] = []
    seen: set[str] = set()
    for line in raw_lines:
        cand = line.strip().lstrip("-·•0123456789. ").strip()
        if not cand or len(cand) > 12:
            continue
        verdict = question_safety.evaluate(cand)
        if verdict.blocked:
            continue
        clean = (verdict.sanitized_text or "").strip()
        if not clean or clean in seen:
            continue
        seen.add(clean)
        labels.append(clean)
        if len(labels) == 3:
            break
    return labels


def _llm_answer_chips(
    text: str, req: QuestionRequest, request_id: str
) -> list[QuestionOption] | None:
    """규칙에 안 걸린 wh-질문의 답변 후보를 2차 GMS 호출로 받는다(747, 방향 A).

    질문 프롬프트와 분리된 짧은 best-effort 호출이다 — 재시도 없이 한 번만, 실패하면 None을
    돌려 상위에서 generic 칩으로 폴백한다(질문 응답을 지연·차단시키지 않는다).
    받은 후보는 _safe_chip_labels로 아동 안전 정화 후 쓴다.

    프롬프트 문구는 ai/prompts/answer_chips.txt에 있다(S15P11B209-788 부수). 코드 상수로
    두면 아동 화면에 나갈 칩을 만드는 프롬프트가 prompts_registry 버전 추적 밖에 남는다.
    """
    system = prompts_registry.load("answer_chips").format(
        age_band=req.child_age, question=text
    )
    try:
        client = get_client().with_options(
            timeout=config.QUESTION_LLM_TIMEOUT_SEC, max_retries=0
        )
        resp = client.chat.completions.create(
            model=config.LLM_MODEL,
            messages=[
                {"role": "system", "content": system},
                {"role": "user", "content": "답 3개를 줄바꿈으로 줘."},
            ],
            temperature=0.4,
        )
        raw = resp.choices[0].message.content or ""
    except OpenAIError as e:
        # 칩 생성 실패는 질문 응답을 막지 않는다 — 유형만 남기고 generic으로 폴백.
        logger.warning(
            "답변 칩 생성 실패(폴백): type=%s request_id=%s", type(e).__name__, request_id
        )
        return None
    labels = _safe_chip_labels(raw.splitlines())
    return _labeled_chips(labels, escape=None) if labels else None


def _is_consistent(
    purpose: str,
    target: DetectedObject | None,
    options: list[QuestionOption] | None,
    option_allowed: bool,
) -> bool:
    """목적·대상·칩·응답 방식이 서로 정합한지 검증한다(BE isContractValidFor 사전 방어).

    - 목적은 계약 허용값이어야 한다.
    - 대상 객체는 OBJECT_DESCRIPTION일 때만 허용(다른 목적엔 붙지 않는다).
    - OPTION 허용 시 칩은 비어 있지 않고 code가 유일해야 하며, 비허용 시 칩은 None.
    """
    if purpose not in VALID_PURPOSES:
        return False
    if target is not None and purpose != "OBJECT_DESCRIPTION":
        return False
    if option_allowed:
        if not options:
            return False
        codes = [o.code for o in options]
        if len(codes) != len(set(codes)):
            return False
    elif options is not None:
        return False
    return True


# 위기 신호 감지 시 아이에게 건네는 안전·지지형 응답(S15P11B209-593).
# 위기를 직접 언급·캐묻지 않고, 대화를 끊지 않으며, 아이에게 이야기할 여지를 부드럽게 준다.
CRISIS_SAFE_QUESTION = "이야기해줘서 고마워. 네 마음은 참 소중해. 지금 더 하고 싶은 이야기가 있어?"
_CRISIS_SAFE_OPTIONS = [
    QuestionOption(code="CHIP_YES", label="응, 더 이야기할래"),
    QuestionOption(code="CHIP_NO", label="아니, 괜찮아"),
    QuestionOption(code="CHIP_NOT_SURE", label="잘 모르겠어"),
]


def _crisis_safe_response(req: QuestionRequest, started: float) -> QuestionResponse:
    """위기 감지 시 대화를 끊지 않고 건네는 결정적 안전·지지형 응답.

    GMS를 호출하지 않는다 — 위기 상황에서 LLM이 위기를 캐묻거나 잘못된 조언을 하지 않도록
    사전에 검토된 고정 문구를 쓴다. safetyResult는 PASSED라 BE가 정상 저장하고 대화가 이어진다.
    """
    option_allowed = "OPTION" in req.allowed_response_modes
    return QuestionResponse(
        question_text=CRISIS_SAFE_QUESTION,
        question_purpose="EXPRESSION",
        options=list(_CRISIS_SAFE_OPTIONS) if option_allowed else None,
        target_object=None,
        fallback_used=False,
        safety_result=SafetyResult(
            status="PASSED", rule_version=req.safety_rule_version, block_reason_code=None
        ),
        model_name=config.LLM_MODEL,
        # GMS를 호출하지 않았으므로 파생 모델 ID가 없다 — 엔진명으로 대신 기록한다.
        model_version=config.LLM_MODEL,
        prompt_version=PROMPT_VERSION,
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )


# ── 그만하기 의사 되묻기 (S15P11B209-938) ───────────────────────
# 아이가 말로 "이제 그만할래"라고 해도 지금까지는 그 말이 그림에 대한 답으로 다뤄져 다음
# 질문이 만들어졌다. 건너뛰기 의사는 존중하면서(831) 그보다 분명한 '그만하기'는 듣지 않았다.
#
# ⚠️ 무엇을 그만할지 되묻는 이유: 그림일기는 그리면서 동시에 대화한다. 두 종료는 무게가
#    전혀 다르다 — 대화 종료는 그림을 계속 그릴 수 있어 가볍지만, 그림 활동 완료는 회고
#    저장과 다음 단계로 이어져 되돌릴 수 없다. 뭉뚱그리면 이야기만 그만하고 싶었던 아이의
#    그림이 통째로 끝난다.
#
# ⚠️ AI는 끝내지 않는다. 되묻기만 하고 실제 종료는 FE가 칩 선택을 보고 한다 — 786이 정한
#    "턴 제어는 AI 소유가 아니다"를 그대로 지킨다.
# ⚠️ 그림 갈래는 '묻기'가 아니라 '안내'다(S15P11B209-947). 그림 활동 완료는 회고 저장과
#    다음 단계로 이어져 되돌릴 수 없는데, 아이가 말로 답하면 칩 선택이 없어 아무 일도
#    일어나지 않는다. 그래서 화면 버튼을 누르라고 알려 준다 — 되돌릴 수 없는 동작을 아이가
#    직접 누르게 하는 편이 안전하기도 하다(938이 '기존 확인 흐름을 그대로 태운다'고 정한 것과
#    같은 판단). 칩은 그대로 두어 탭으로도 끝낼 수 있다.
#
# ⚠️ 버튼에 적힌 글자를 그대로 쓴다. 도담이 말하는 낱말과 화면 글자가 다르면 아이가 잇지
#    못한다. FE 라벨은 drawing_complete_cta.dart 의 '다 그렸어요!' 다 — 그쪽을 바꾸면
#    여기도 같이 고쳐야 한다.
COMPLETE_BUTTON_LABEL = "다 그렸어요!"

STOP_ASK_BOTH = (
    f"그래! 그림도 다 그렸으면 '{COMPLETE_BUTTON_LABEL}' 단추를 눌러 줘. "
    "이야기만 그만하고 싶으면 알려 줄래?"
)
STOP_ASK_DRAWING = (
    f"그림 다 그렸구나! 그럼 '{COMPLETE_BUTTON_LABEL}' 단추를 눌러 줄래?"
)
STOP_ASK_CONVERSATION = "그래, 이야기는 여기까지 할까?"

# FE가 이 코드를 보고 무엇을 끝낼지 정한다(activity_screens._selectQuestionOption).
_CHIP_END_ACTIVITY = QuestionOption(code="CHIP_END_ACTIVITY", label="그림 다 그렸어")
_CHIP_END_TALK = QuestionOption(code="CHIP_END_TALK", label="이야기만 그만할래")
_CHIP_KEEP_GOING = QuestionOption(code="CHIP_KEEP_GOING", label="아니, 더 할래")

# ── 말로 답한 확인 (S15P11B209-951) ────────────────────────────
# 938은 종료를 칩으로만 갈 수 있게 두어, 되묻기에 말로 "응"이라고 답하면 아무 일도 일어나지
# 않았다. 마이크로 대화하는 아이에게는 말로 답하는 쪽이 자연스럽다.
#
# ⚠️ AI는 여전히 끝내지 않는다. confirmedStopTarget은 "아이가 확인했다"는 관찰 보고이고
#    실제 종료는 FE가 한다 — 786 원칙 그대로다.
STOP_CLOSING_CONVERSATION = "그래, 오늘 이야기 재미있었어. 그림은 계속 그려도 돼!"
STOP_CLOSING_ACTIVITY = "그래, 오늘 그림 정말 멋졌어. 다음에 또 그리자!"

# 되묻기 갈래 → 확인됐을 때 FE에 알릴 종료 대상. STOP_ASK_BOTH는 여기 없다 —
# 대상이 불분명한 채로 되돌릴 수 없는 활동 완료를 추측해 실행하지 않는다.
_REASK_CONFIRMED_TARGET = {
    STOP_ASK_DRAWING: "ACTIVITY",
    STOP_ASK_CONVERSATION: "CONVERSATION",
}
_REASK_TEXTS = frozenset({STOP_ASK_BOTH, STOP_ASK_DRAWING, STOP_ASK_CONVERSATION})


def _detect_stop_intent(req: QuestionRequest) -> str | None:
    """가장 최근 아이 발화에서 그만하기 의사를 찾는다(없으면 None).

    ⚠️ 칩으로 답한 메시지는 스캔하지 않는다(S15P11B209-950). BE는 선택형 답변의 문맥
    텍스트로 **아이의 말이 아니라 칩 라벨**을 싣는데
    (ConversationNextQuestionService.resolveContextText), 되묻기 칩의 라벨 자체가
    그만하기 문구다 — "이야기만 그만할래"는 STOP_CONVERSATION으로, "그림 다 그렸어"는
    STOP_DRAWING으로 다시 걸린다. 그대로 스캔하면 AI가 **자기가 낸 문구**에 재감지되어
    같은 되묻기를 무한 반복한다. 그만두겠다고 고른 아이일수록 갇히는 구조였다.

    칩 코드를 열거해 막지 않는 이유: 새 칩이 생길 때마다 같은 사고가 되살아난다.
    원인 계층은 '칩 라벨은 아이가 한 말이 아니다'이므로 거기서 끊는다. 기존
    CHIP_KEEP_GOING 특례(718의 연속 부정 처리와 같은 결)도 이 검사에 흡수된다.

    칩 답변이면 **더 과거 발화로 거슬러 올라가지 않는다.** 올라가면 이미 되물어 응답까지
    받은 옛 발화가 되살아나 같은 루프가 다른 모양으로 난다.

    음성·직접입력 답변에는 선택 코드가 없다(BE loadSelectedOptionContexts는 선택형
    답변만 담는다). 그래서 말로 그만하겠다고 한 최초 감지 경로는 그대로다.

    혼합 답변("Label / directText")에서는 아이가 덧붙인 말의 그만하기 의사를 이 턴에
    놓친다. 감수하는 쪽을 골랐다 — 다음 턴에 다시 말하면 잡히지만, 루프는 아이가 스스로
    빠져나올 수 없다. 다만 이 판단은 **되반응 계열에만** 적용된다. 인젝션 검사는 놓쳤을
    때의 대가가 커서 혼합 답변도 계속 스캔한다(_detect_injection 참고).
    """
    index = _last_child_index(req)
    if index is None:
        return None
    message = req.recent_messages[index]
    if message.selected_option_codes:
        return None
    return conversation_stop_intent.scan(message.text or "")


def _stop_intent_offers(req: QuestionRequest, verdict: str) -> tuple[str, list[QuestionOption]]:
    """되물을 문장과 선택 칩을 고른다.

    HTP에서는 그림 갈래를 내지 않는다 — HTP는 주제 그림을 완료한 뒤에야 대화가 시작되므로
    (FE _handleObjectDetectionChanged가 isHtp이면 즉시 return) '그림을 그만 그린다'가
    성립하지 않는다. activityType이 없는 구 BE 요청도 같게 다룬다: 무엇을 하는 중인지
    모르면 되돌릴 수 없는 쪽(활동 완료)을 권하지 않는다.
    """
    can_end_activity = req.activity_type == "ART_DIARY"
    if verdict == conversation_stop_intent.STOP_DRAWING and can_end_activity:
        return STOP_ASK_DRAWING, [_CHIP_END_ACTIVITY, _CHIP_KEEP_GOING]
    if verdict == conversation_stop_intent.STOP_UNSPECIFIED and can_end_activity:
        return STOP_ASK_BOTH, [_CHIP_END_ACTIVITY, _CHIP_END_TALK, _CHIP_KEEP_GOING]
    # 대화를 지목했거나, 그림 갈래를 낼 수 없는 활동이면 대화 종료만 묻는다.
    return STOP_ASK_CONVERSATION, [_CHIP_END_TALK, _CHIP_KEEP_GOING]


def _stop_intent_response(
    req: QuestionRequest, started: float, verdict: str
) -> QuestionResponse:
    """그만하기 의사 되묻기 — GMS를 호출하지 않는 결정적 응답.

    목적은 FOLLOW_UP이다. 아이가 방금 한 말에 이어 묻는 것이고, 대상 객체는 붙지 않는다.

    OPTION이 허용되지 않으면 칩 없이 되묻기 문장만 나간다. 950에서는 이것이 막다른 길이라
    되묻기 자체를 막았지만, 951이 말로 답하는 길을 열어 다시 되물을 수 있게 됐다 —
    칩이 없어도 다음 턴의 _stop_confirmation_response가 받는다.

    ⚠️ 여기에는 종료 확인 신호를 싣지 않는다. 이 응답은 "그만할래?"라고 **묻는** 것이라
       아직 확인이 아니다. 확인은 다음 턴에 _stop_confirmation_response가 판정한다 —
       묻는 자리에서 끝내면 아이가 "아니, 더 할래"라고 답할 기회가 사라진다.
    """
    text, offers = _stop_intent_offers(req, verdict)
    option_allowed = "OPTION" in req.allowed_response_modes
    return QuestionResponse(
        question_text=text,
        question_purpose="FOLLOW_UP",
        options=list(offers) if option_allowed else None,
        target_object=None,
        fallback_used=False,
        safety_result=SafetyResult(
            status="PASSED", rule_version=req.safety_rule_version, block_reason_code=None
        ),
        model_name=config.LLM_MODEL,
        # GMS를 호출하지 않았으므로 파생 모델 ID가 없다 — 엔진명으로 대신 기록한다.
        model_version=config.LLM_MODEL,
        prompt_version=PROMPT_VERSION,
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )


def _last_reask_branch(req: QuestionRequest) -> str | None:
    """마지막 아이 발화 **직전**의 AI 메시지가 되묻기였으면 그 되묻기 문장(아니면 None).

    아무 때나 "응"을 종료로 읽지 않기 위한 자물쇠다(S15P11B209-951). 평범한 질문에 짧게
    긍정하는 일은 흔하고, 그것까지 종료로 읽으면 대화가 예고 없이 끊긴다. 되묻기 문장은
    우리가 낸 고정 문구라 문자열 대조로 충분하다.
    """
    index = _last_child_index(req)
    if index is None:
        return None
    for position in range(index - 1, -1, -1):
        message = req.recent_messages[position]
        if (message.sender_type or "").upper() != "AI":
            continue
        text = (message.text or "").strip()
        return text if text in _REASK_TEXTS else None
    return None


def _stop_confirmation_response(
    req: QuestionRequest, started: float, reask: str | None
) -> QuestionResponse | None:
    """되묻기에 **말로** 그만하겠다고 답했으면 확인 신호를 실어 보낸다(S15P11B209-951).

    해당하지 않으면 None을 돌려 평소 질문 흐름으로 넘긴다. 부정("아니, 더 할래")과 애매한
    답이 모두 여기에 포함된다 — 애매한 답으로 대화를 끝내지 않는다.

    칩으로 답한 경우는 여기서 다루지 않는다. FE가 칩 코드를 보고 이미 끝내며(938),
    그 라벨을 다시 읽지 않는 것이 950이 고친 지점이다.
    """
    if reask is None:
        return None
    index = _last_child_index(req)
    if index is None:
        return None
    message = req.recent_messages[index]
    if message.selected_option_codes:
        return None
    utterance = message.text or ""
    confirmation = conversation_stop_intent.scan_confirmation(utterance)
    if confirmation == conversation_stop_intent.CONFIRM_NO:
        return None

    if reask == STOP_ASK_BOTH:
        # 3지선다에 답한 경우다. "응"은 그만하겠다는 뜻이지만 **무엇을** 그만할지는 말하지
        # 않았다. 여기서 활동 완료를 추측하면 이야기만 그만하려던 아이의 그림이 통째로
        # 끝난다 — 되돌릴 수 없다. 그래서 대상을 말한 경우에만 그 갈래로 간다.
        #
        # 대상을 말했다면 그 자체가 답이므로 긍정 낱말을 따로 요구하지 않는다
        # ("그림 그만 그릴래"에는 '응'이 없다).
        named = conversation_stop_intent.scan(utterance)
        target = {
            conversation_stop_intent.STOP_DRAWING: "ACTIVITY",
            conversation_stop_intent.STOP_CONVERSATION: "CONVERSATION",
        }.get(named or "")
        if target is None:
            if confirmation != conversation_stop_intent.CONFIRM_YES:
                return None
            # 그만두겠다는 것은 분명한데 대상이 아직 불분명하다. 되돌릴 수 없는 쪽을
            # 추측하는 대신 가벼운 쪽으로 좁혀 한 번 더 묻는다. 갈래가 BOTH에서
            # CONVERSATION으로 바뀌므로 이 좁히기는 한 번만 일어나고 되풀이되지 않는다.
            return _stop_intent_response(
                req, started, conversation_stop_intent.STOP_CONVERSATION
            )
    else:
        if confirmation != conversation_stop_intent.CONFIRM_YES:
            return None
        target = _REASK_CONFIRMED_TARGET[reask]

    closing = STOP_CLOSING_ACTIVITY if target == "ACTIVITY" else STOP_CLOSING_CONVERSATION
    return QuestionResponse(
        question_text=closing,
        question_purpose="FOLLOW_UP",
        options=None,  # 질문이 아니라 맺음말이다 — 고를 것이 없다.
        confirmed_stop_target=target,
        # 대화만 끝내는 확인은 BE가 실행할 수 있다(세션 상태의 주인이 BE다). 활동 종료는
        # 회고 저장·다음 단계가 FE에 있어 BE가 대신할 수 없으므로 신호만 보내고 FE가 끝낸다.
        # 둘 다 "아이가 확인했다"는 관찰 보고이고, AI는 어느 쪽도 직접 끝내지 않는다(786).
        conversation_end_confirmed=target == "CONVERSATION",
        target_object=None,
        fallback_used=False,
        safety_result=SafetyResult(
            status="PASSED", rule_version=req.safety_rule_version, block_reason_code=None
        ),
        model_name=config.LLM_MODEL,
        model_version=config.LLM_MODEL,
        prompt_version=PROMPT_VERSION,
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )


# ── 그림일기 완전 첫 질문 고정 (S15P11B209-921) ─────────────────
# 자유 그림은 무엇을 그렸는지 아는 사람이 아이뿐이다. 자동 탐지는 이 영역에서 가장 약하고
# (sketch 오탐 — 918), VLM 서술도 확신이 없으면 "네모난 무언가"에 머문다. 모르는 상태에서
# AI가 실마리를 골라 대화를 열면 918의 오탐 단정("그림 속 덤불은 어떤 모습이야?")이 된다.
# 그래서 첫 질문은 추측하지 않고 아이에게 직접 묻고, 그 대답으로 대화를 시작한다.
#
# ⚠️ 786이 없앤 '첫 질문 고정 현상'을 그림일기에 한해 의도적으로 되살리는 것이다. 786이
#    틀렸던 게 아니라 조건이 다르다 — HTP는 활동이 주제를 정해 두어 무엇을 그렸는지 알고
#    시작하지만, 자유 그림은 모른다. 모르는 채로 여는 질문을 다양화하면 다양하게 틀린다.
#
# ⚠️ 판정에 currentQuestionCount를 쓰는 이유: 아이 발화 유무는 그림일기에서 '완전 첫 질문'과
#    1:1이 아니다. 그림일기는 그리기를 멈출 때마다 질문을 새로 요청하므로(922), 아이가 답하지
#    않은 채 두 번째 요청이 오면 발화는 여전히 없다. questionCount는 질문이 저장될 때만 오르니
#    (BE QuestionPersistenceService) 0이 곧 '아직 아무 질문도 안 함'이다.
_DIARY_OPENING_SIMPLE = "오늘 뭐 그렸는지 이야기해 줄래?"
_DIARY_OPENING_STANDARD = "오늘 뭐 그린 건지 설명해줄래?"

# 난이도 2종. '설명'은 유아에게 어려운 말이라 유아·배려형에는 '이야기해 줄래'를 쓴다.
# 네 구간을 다 가르지 않은 것은 의도다 — 895에서 확인했듯 길이 축은 이미 사실상 둘로
# 붕괴해 있고, 한 문장짜리 고정 문구를 넷으로 나누면 관리할 것만 늘어난다.
_DIARY_OPENING_BY_DIFFICULTY = {
    "PRESCHOOL": _DIARY_OPENING_SIMPLE,
    "SUPPORT": _DIARY_OPENING_SIMPLE,
}

# 이 질문 전용 칩. 목적별 generic(DRAWING_CONTEXT = 진짜/상상)을 쓰지 않는 이유:
# 첫 질문에서 실제 경험인지 상상인지 먼저 정하지 말라는 규칙(first_question_diary)과
# 정면으로 어긋난다. 칩도 아이 화면에 나가는 질문의 일부다.
_DIARY_OPENING_OPTIONS = [
    QuestionOption(code="CHIP_YES", label="응, 말해줄게"),
    QuestionOption(code="CHIP_NOT_SURE", label="음… 잘 모르겠어"),
    QuestionOption(code="CHIP_JUST_WANTED", label="그냥 그리고 싶었어"),
]


def _is_diary_opening(req: QuestionRequest) -> bool:
    """그림일기의 '완전 첫 질문'인가(아직 아무 질문도 저장되지 않았는가)."""
    return req.activity_type == "ART_DIARY" and req.current_question_count == 0


def _diary_opening_question(difficulty: str | None) -> str:
    return _DIARY_OPENING_BY_DIFFICULTY.get(difficulty or "", _DIARY_OPENING_STANDARD)


def _diary_opening_response(req: QuestionRequest, started: float) -> QuestionResponse:
    """그림일기 첫 질문 — GMS를 호출하지 않는 결정적 응답.

    위기 응답·인젝션 재질문과 같은 패턴이다. 고정 문구를 LLM에 만들게 할 이유가 없고,
    호출을 아끼면 아이가 기다리는 시간도 줄어든다.
    """
    option_allowed = "OPTION" in req.allowed_response_modes
    return QuestionResponse(
        question_text=_diary_opening_question(req.difficulty),
        question_purpose="DRAWING_CONTEXT",
        options=list(_DIARY_OPENING_OPTIONS) if option_allowed else None,
        target_object=None,
        fallback_used=False,  # AI가 정한 질문이다 — BE 폴백 템플릿이 아니다
        safety_result=SafetyResult(
            status="PASSED", rule_version=req.safety_rule_version, block_reason_code=None
        ),
        model_name=config.LLM_MODEL,
        # GMS를 호출하지 않았으므로 파생 모델 ID가 없다 — 엔진명으로 대신 기록한다.
        model_version=config.LLM_MODEL,
        prompt_version=PROMPT_VERSION,
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )


# ── 프롬프트 인젝션 차단 (S15P11B209-742) ───────────────────────
# 아이 발화가 프롬프트를 조작하려 하면(예: "지금까지의 모든 지시를 잊고~") LLM에 전달하지 않고
# 결정적 재질문으로 되묻는다. 위기 차단과 달리 대화는 끊지 않는다(정상적인 되묻기).
REASK_QUESTION = "미안, 잘 못 들었어. 그림에서 뭘 그렸는지 다시 이야기해줄래?"


def _detect_injection(req: QuestionRequest) -> str | None:
    """가장 최근 아이 발화(프롬프트의 {child_utterance}가 될 것)에서 인젝션 신호를 찾는다."""
    index = _last_child_index(req)
    if index is None:
        return None
    return prompt_injection.scan(req.recent_messages[index].text or "")


def _reask_response(req: QuestionRequest, started: float) -> QuestionResponse:
    """인젝션 감지 시 GMS 호출 없이 돌려주는 결정적 재질문 응답.

    조작 입력이 출력에 절대 영향 못 주도록 검토된 고정 문구를 쓴다. safetyResult는 PASSED라
    BE가 정상 저장하고 대화가 이어진다. 목적은 그림 전체를 다시 여는 DRAWING_CONTEXT.
    """
    option_allowed = "OPTION" in req.allowed_response_modes
    return QuestionResponse(
        question_text=REASK_QUESTION,
        question_purpose="DRAWING_CONTEXT",
        options=(
            list(_OPTIONS_BY_PURPOSE["DRAWING_CONTEXT"]) if option_allowed else None
        ),
        target_object=None,
        fallback_used=False,
        safety_result=SafetyResult(
            status="PASSED", rule_version=req.safety_rule_version, block_reason_code=None
        ),
        model_name=config.LLM_MODEL,
        # GMS를 호출하지 않았으므로 파생 모델 ID가 없다 — 엔진명으로 대신 기록한다.
        model_version=config.LLM_MODEL,
        prompt_version=PROMPT_VERSION,
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )


# ── 문맥상 어색한 질문 교체 (S15P11B209-918) ────────────────────
# 안전 위반이 아니라 품질 결함이다 — 차단(422)하면 BE 폴백 템플릿("오늘은 뭘 그렸어?")으로
# 대체되어 대화가 더 나빠진다. 그래서 같은 대상을 유지한 채 물어볼 각도만 바꿔 준다.
QUALITY_OPEN_QUESTION = "그림에서 더 이야기해 주고 싶은 건 뭐야?"


def _quality_replacement(
    req: QuestionRequest, purpose: str, target: DetectedObject | None
) -> tuple[str, str, DetectedObject | None]:
    """어색한 질문을 대신할 (질문, 목적, 대상)을 만든다.

    HTP는 대상이 살아 있으면 그 대상의 '보이는 것'을 묻는 질문으로 바꾼다 — 대상을 버리면
    아이 입장에서 화제가 통째로 사라지고, 지붕 모양·나무 크기는 PDI가 실제로 묻는 항목이다.
    그림일기는 그 교체 문장이 곧 954가 없애려는 버그라, 그림만 보고는 알 수 없는 축으로 옮긴다.
    대상이 없으면 그림 전체를 여는 질문으로 간다.
    """
    name = (target.object_name or "").strip() if target is not None else ""
    if name and purpose == "OBJECT_DESCRIPTION":
        if req.activity_type == "ART_DIARY":
            return _diary_axis_replacement(req, target)
        return f"그림 속 {name}{question_quality.eun_neun(name)} 어떤 모양이야?", purpose, target
    return QUALITY_OPEN_QUESTION, "DRAWING_CONTEXT", None


# ── 이미 아는 것을 되묻는 질문의 교체 (S15P11B209-954) ────────────
# 그림만 보고는 알 수 없는 축을 우선순위대로 둔다. 위에서부터 **이 대화에서 아직 다루지
# 않은** 첫 축을 고른다. 색·모양·크기·위치는 여기 없다 — 그림에 이미 보이는 것이라
# 물어볼 것이 없기 때문이다(이슈의 핵심).
#
# (축 이름, 이미 다뤘는지 알아볼 표지어, 건넬 질문, 사람 대상일 때만 쓸 것인가)
#
# ⚠️ 표지어는 우리가 물어본 말투와 **아이가 답한 말투를 함께** 담는다. 우리 질문 어투만
#    보면("누구"), 아이가 먼저 "내 동생이야"라고 말해 준 경우를 놓쳐 정체를 또 묻게 된다.
#
# ⚠️ 순서가 정책이다(S15P11B209-999). 원래 IDENTITY가 1순위였는데, 그건 프롬프트에서 걷어낸
#    옛 6축 우선순위를 코드가 그대로 들고 있던 것이다. 실호출에서 건너뛰기 직후 교체가
#    걸리자 이 표가 "그림 속 이 사람은 누구야?"를 골라, 프롬프트가 금지한 정체 질문이
#    가드를 통해 되살아났다. 이제 사건이 먼저고 정체는 마지막이다 — 정체는 대상을 뭐라
#    불러야 할지 몰라 이야기를 못 이을 때 쓰는 확인 질문이지 기본 탐색 질문이 아니다.
_DIARY_AXES = (
    (
        "EVENT",
        ("무슨 일", "뭐 하", "뭐 했", "놀았", "갔어", "했어", "먹었", "봤어"),
        "여기서 무슨 일이 있었어?",
        False,
    ),
    ("MEMORY", ("기억",), "이 장면에서 가장 기억나는 건 뭐야?", False),
    ("RELATION", ("사이", "누구랑", "함께", "같이"), "이 사람은 너와 어떤 사이야?", True),
    (
        "IDENTITY",
        (
            "누구", "누가", "엄마", "아빠", "동생", "친구", "누나", "형",
            "언니", "오빠", "선생님", "할머니", "할아버지",
        ),
        "그림 속 이 사람은 누구야?",
        True,
    ),
)

# 아이가 "이건 말하기 싫어"·"다른 질문 해줘"처럼 지금 질문을 넘기겠다고 한 말.
#   ⚠️ conversation_stop_intent(그만하기)와 다르다 — 그쪽은 대화를 끝내는 의사다.
_SKIP_INTENT = re.compile(
    r"(?:말하기\s*싫|말\s*안\s*할|다른\s*(?:질문|거|것)|건너뛸래|넘어갈래|패스"
    r"|그건\s*싫|묻지\s*마)"
)

# ── 아이가 우리 이름을 바로잡는 말 (S15P11B209-999) ──────────────
# "덤불 아니고 내 머리야" 처럼 소유 표현이 붙으면 이름만 떼어 내야 한다. 실측에서 '내 머리'를
# 통째로 잡아 정정 자체를 놓쳤다 — 그러면 아이가 고쳐 준 이름을 다음 질문에 쓰지 못한다.
_CORRECTION = re.compile(
    r"(?:아니고|아니라|아니야|아냐|말고)\s*(?P<rest>.+?)[\s.!?]*$"
    r"|^(?:이건|이거|저건|저거|그건|그거)\s*(?P<rest2>.+?)[\s.!?]*$"
)

# 정정으로 볼 수 없는 꼬리말. "그거 아니야"의 '아니야'를 이름으로 잡으면 없는 대상이 생긴다.
_NOT_A_LABEL = re.compile(r"^(?:아니|아냐|아니야|안|몰라|없어|맞아|응|아직|그냥|거|것|꺼)$")

# 아이가 자신을 가리킨 말. 그대로 두면 복구 문장이 "아, 나였구나"가 되어 도담이 자기 이야기를
#   하는 꼴이 된다 — 아이에게 되돌려 부를 말로 바꾼다.
_SELF_WORDS = ("나", "저", "내", "제")

# 이름이 아니라 서술인 꼬리말. "그거 아니고 밖에서 놀았어"의 '놀았어'는 대상 이름이 아니다.
_PREDICATE_TAIL = re.compile(r"(?:았어|었어|했어|했다|해요|어요|았다|었다|자|줘|봐|네)$")

# 소유를 나타내는 말 → (코드, 아이에게 부를 때 쓸 말). 부위를 고쳐 준 뒤 '누구의 것인가'가
#   정해지면 다음 이야기는 부위가 아니라 그 사람으로 옮겨 간다.
#   ⚠️ 순서가 의미를 가른다. "우리 엄마 머리야"는 엄마 이야기지 아이 이야기가 아니라서,
#      '나·우리' 계열을 맨 뒤에 둔다 — 앞에 두면 '우리'가 먼저 걸려 소유자가 뒤바뀐다.
_OWNERS = (
    ("엄마", "MOTHER", "엄마"),
    ("어머니", "MOTHER", "엄마"),
    ("아빠", "FATHER", "아빠"),
    ("아버지", "FATHER", "아빠"),
    ("동생", "SIBLING", "동생"),
    ("형", "SIBLING", "형"),
    ("누나", "SIBLING", "누나"),
    ("언니", "SIBLING", "언니"),
    ("오빠", "SIBLING", "오빠"),
    ("할머니", "GRANDPARENT", "할머니"),
    ("할아버지", "GRANDPARENT", "할아버지"),
    ("선생님", "TEACHER", "선생님"),
    ("친구", "FRIEND", "친구"),
    ("내", "CHILD", "너"),
    ("나", "CHILD", "너"),
    ("나의", "CHILD", "너"),
    ("제", "CHILD", "너"),
    ("우리", "CHILD", "너"),
)

# 그림 속 사람의 부위. question_quality 와 같은 어휘를 쓴다 — 두 곳이 갈리면 한쪽만 고쳐진다.
_BODY_PARTS = question_quality.BODY_PARTS

BODY_PART = "BODY_PART"
OBJECT = "OBJECT"


@dataclass(frozen=True)
class Correction:
    """아이가 바로잡아 준 대상 (S15P11B209-999).

    label 은 아이가 말한 이름 그대로다. owner 는 그 대상이 누구의 것인지이며 모르면 None.
    semantic_type 이 BODY_PART 면 그 부위 자체를 다음 이야기의 중심으로 삼지 않는다 —
    "그 머리에서는 무슨 일이 있어?"는 아이가 답할 수 없는 질문이다.
    """

    label: str
    owner: str | None
    owner_label: str | None
    semantic_type: str


def _owner_of(words: list[str]) -> tuple[str | None, str | None]:
    """이름 앞에 붙은 말에서 소유자를 읽는다. 못 찾으면 (None, None)."""
    stems = [re.sub(r"(?:의|가|는|은|이|도)$", "", w) for w in words]
    for marker, code, display in _OWNERS:
        if marker in stems:
            return code, display
    return None, None


def _correction(req: QuestionRequest) -> Correction | None:
    """아이가 방금 바로잡아 준 대상. 이름이 없는 부정("아니야")은 정정이 아니다."""
    index = _last_child_index(req)
    if index is None:
        return None
    match = _CORRECTION.search((req.recent_messages[index].text or "").strip())
    if match is None:
        return None
    rest = (match.group("rest") or match.group("rest2") or "").strip()
    if not rest:
        return None
    # 조사·종결어미를 떼고 마지막 낱말을 이름으로 본다. "내 머리야" → 소유 '내' + 이름 '머리'.
    words = [w for w in re.split(r"\s+", rest) if w]
    if not words:
        return None
    tail = words[-1]
    if _PREDICATE_TAIL.search(tail):
        # 이름을 대는 말이 아니라 사건을 잇는 말이다. 여기서 이름을 뽑으면 없는 대상이 생긴다.
        return None
    label = re.sub(r"(?:이야|이에요|예요|야|인데|이다|다|요)$", "", tail).strip()
    if not label or len(label) > 10 or _NOT_A_LABEL.match(label):
        return None
    if label in _SELF_WORDS:
        return Correction(
            label="너", owner="CHILD", owner_label="너", semantic_type=OBJECT
        )
    owner, owner_label = _owner_of(words[:-1])
    semantic = BODY_PART if any(part in label for part in _BODY_PARTS) else OBJECT
    return Correction(
        label=label, owner=owner, owner_label=owner_label, semantic_type=semantic
    )


def _corrected_label(req: QuestionRequest) -> str | None:
    """아이가 방금 바로잡아 준 이름. 없으면 None."""
    correction = _correction(req)
    return correction.label if correction else None


def _corrected_detection(
    req: QuestionRequest, correction: Correction
) -> DetectedObject | None:
    """아이가 방금 바로잡은 그 탐지. 아이 말 안에 탐지 이름이 그대로 들어 있을 때만 짚는다."""
    index = _last_child_index(req)
    if index is None:
        return None
    said = req.recent_messages[index].text or ""
    for obj in req.detected_objects or []:
        name = (obj.object_name or "").strip()
        if name and name != correction.label and name in said:
            return obj
    return None


def _retarget_for_correction(
    req: QuestionRequest, target: DetectedObject | None
) -> DetectedObject | None:
    """아이가 이름을 바로잡았으면 다음 대화 대상을 다시 고른다(S15P11B209-999).

    부위는 대상으로 두지 않는다. '머리'가 대상인 채로 남으면 [[TARGET_FOLLOW_UP]]이 그 부위
    하나를 가리키고, 부위에는 물을 것이 겉모습밖에 없어 "머리 무슨 색이야?"로 되돌아간다.

    - 부위 + 소유자를 알겠다 → 그 사람 전체(PERSON 탐지)로 옮긴다. 이야기는 부위가 아니라
      사람에게 붙는다("엄마는 그때 뭐 하고 있었어?").
    - 부위 + 소유자를 모르겠다 → 대상을 떼고 그림 전체 이야기로 돌아간다. 사람을 지어내는
      것보다 낫다.
    - 부위가 아닌 일반 객체 → 아이가 고쳐 준 **그 탐지**를 대상으로 삼고 아이가 말한 이름으로
      부른다. 탐지 이름은 이미 틀린 것으로 확인됐다(objectCode는 그대로라 BE의 중복 방지는
      어긋나지 않는다). 어느 탐지를 고친 것인지 못 짚으면 그림 전체로 돌아간다 — 그때 원래
      대상을 그냥 새 이름으로 부르면 엉뚱한 탐지에 아이 말이 얹힌다("사람"을 "여우"로 부른다).
    """
    correction = _correction(req)
    if correction is None:
        return target
    if correction.semantic_type == OBJECT:
        corrected = _corrected_detection(req, correction)
        if corrected is None:
            return None
        return corrected.model_copy(update={"object_name": correction.label})
    if correction.owner_label is None:
        return None
    person = next(
        (o for o in (req.detected_objects or []) if o.object_code == "PERSON"), None
    )
    if person is None:
        # 부위만 잡혔고 사람 전체는 탐지되지 않았다 — 없는 대상을 지어내지 않고 전체로 돌아간다.
        return None
    return person.model_copy(update={"object_name": correction.owner_label})


# 스스로 움직일 수 있는 대상인지. 정정 뒤 "무엇을 하고 있어?"를 붙여도 되는지 가른다 —
#   덤불·별처럼 움직이지 않는 것에 행동을 물으면 없는 사건을 지어내라는 말이 된다.
_ACTOR_WORDS = (
    "사람", "아이", "엄마", "아빠", "동생", "형", "누나", "언니", "오빠", "친구",
    "선생님", "할머니", "할아버지", "강아지", "고양이", "여우", "토끼", "곰", "새",
    "물고기", "다람쥐", "공룡", "말", "소", "돼지", "오리", "나비",
)


def _skip_intent(req: QuestionRequest) -> bool:
    """아이가 방금 이 질문을 건너뛰겠다고 말했는가."""
    index = _last_child_index(req)
    if index is None:
        return False
    return bool(_SKIP_INTENT.search(req.recent_messages[index].text or ""))


def _yeotguna(word: str) -> str:
    """'였구나'/'이었구나' — 받침에 맞춘 과거 인정 어미. "손였구나"가 나가지 않게 한다."""
    return "이었구나" if question_quality.eun_neun(word) == "은" else "였구나"


def _stale_labels(req: QuestionRequest) -> list[str]:
    """아이가 아니라고 한 뒤로는 쓰면 안 되는 탐지 이름들."""
    if _corrected_label(req) is None:
        return []
    return [o.object_name for o in (req.detected_objects or []) if o.object_name]


# 사람 축(정체·관계)을 쓸 수 있는지 판단할 어휘. 사람이 아닌 그림에 "이 사람은 누구야?"를
# 얹으면 918이 막으려던 '없는 것 단정'을 우리가 직접 저지르는 셈이 된다.
_PERSON_WORDS = (
    "사람", "얼굴", "머리", "몸", "팔", "다리", "손", "발", "아이",
    "엄마", "아빠", "친구", "동생", "형", "누나", "언니", "오빠", "선생님",
)


def _child_texts(req: QuestionRequest) -> list[str]:
    """이 대화에서 아이가 한 말(텍스트 있는 것만)."""
    return [
        (m.text or "").strip()
        for m in req.recent_messages
        if (m.sender_type or "").upper() == "CHILD" and (m.text or "").strip()
    ]


def _is_person_drawing(req: QuestionRequest, target: DetectedObject | None) -> bool:
    """사람에 대해 물어도 되는 그림인가 — 탐지 대상·그림 서술·아이 말을 함께 본다."""
    if target is not None and target.object_code.startswith("PERSON"):
        return True
    material = " ".join(
        [_truncate_description(req.drawing_description) or "", *_child_texts(req)]
    )
    return any(word in material for word in _PERSON_WORDS)


# 그림일기 전용 사유들 — 복구는 상태별 문장(_diary_situational_replacement)이 맡는다.
_DIARY_QUALITY_REASONS = frozenset(
    {
        question_quality.REDUNDANT_VISUAL,
        question_quality.VISUAL_EVALUATION,
        question_quality.CORRECTION_IGNORED,
        question_quality.UNGROUNDED_EMOTION,
        question_quality.IDENTITY_FALLBACK,
        question_quality.BODY_PART_ACTOR,
    }
)


def _diary_situational_replacement(
    req: QuestionRequest,
) -> tuple[str, str, DetectedObject | None] | None:
    """지금 대화 상태에 맞는 복구 문장을 고른다(S15P11B209-999). 해당 없으면 None.

    가드는 질문을 새로 창작하는 두 번째 모델이 아니다. 상태별로 미리 정해 둔 안전한 문장을
    고르기만 한다 — 하나의 범용 문장으로 수렴시키면 그 문장이 곧 정책이 되어, 프롬프트에서
    걷어낸 규칙이 가드를 통해 되살아난다(정체 질문이 실제로 그랬다).
    """
    # ① 아이가 건너뛰겠다고 했다 — 다른 대상을 우리가 골라 캐묻지 않고 선택권을 돌려준다.
    if _skip_intent(req):
        return "좋아, 그건 건너뛸게. 다른 이야기를 해줄래?", "DRAWING_CONTEXT", None
    # ② 아이가 이름을 바로잡았다 — 그 이름을 그대로 쓰고 사건으로 잇는다.
    correction = _correction(req)
    if correction is not None:
        label = correction.label
        if correction.semantic_type == BODY_PART:
            # 부위에는 물을 것이 겉모습밖에 없다. 소유자를 알면 그 사람의 이야기로 옮기고,
            #   모르면 사람을 지어내지 말고 그림 전체로 돌아간다(_retarget_for_correction과 같은 판단).
            owner = correction.owner_label
            if owner:
                possessive = "네" if correction.owner == "CHILD" else owner
                return (
                    f"아, {possessive} {label}{_yeotguna(label)}. "
                    f"그때 {owner}{question_quality.eun_neun(owner)} 뭐 하고 있었어?",
                    "FOLLOW_UP",
                    None,
                )
            return f"아, {label}{_yeotguna(label)}. 이 그림 이야기를 더 들려줄래?", "FOLLOW_UP", None
        if any(word in label for word in _ACTOR_WORDS):
            return (
                f"아, {label}{question_quality.eun_neun(label)} 여기서 뭐 하고 있어?",
                "FOLLOW_UP",
                None,
            )
        return f"아, {label}{_yeotguna(label)}. 이 그림 이야기를 더 들려줄래?", "FOLLOW_UP", None
    # ③ 첫마디다 — 장면을 연다.
    if _last_child_index(req) is None:
        return "이 그림에서는 무슨 일이 일어나고 있어?", "DRAWING_CONTEXT", None
    # ④ 아이가 방금 행동·사건을 말했다 — 그 줄기를 잇는다.
    last = (req.recent_messages[_last_child_index(req)].text or "").strip()
    if any(marker in last for marker in ("했어", "갔어", "먹었", "놀았", "봤어", "탔어")):
        return "그러고 나서는 뭐 했어?", "FOLLOW_UP", None
    if any(marker in last for marker in ("있었", "생겼", "왔어", "됐어", "뒤집")):
        return "그다음에는 어떻게 됐어?", "FOLLOW_UP", None
    return None


def _diary_axis_replacement(
    req: QuestionRequest, target: DetectedObject | None
) -> tuple[str, str, DetectedObject | None]:
    """이미 아는 것을 되묻는 질문을 '아직 안 나온 축'의 질문 하나로 바꾼다.

    이미 다뤘는지는 우리가 건넨 질문(_asked_questions)과 아이가 한 말을 함께 본다 —
    아이가 먼저 "동생이야"라고 말했으면 정체는 이미 나온 것이라 다시 물을 이유가 없다.

    대상 객체는 떼고 돌려준다. 축을 옮긴 질문이라 그 대상 하나를 가리키지 않고, 붙여 두면
    918이 억눌러 둔 오탐 이름이 targetObject·칩으로 다시 아이 화면에 올라온다.
    """
    situational = _diary_situational_replacement(req)
    if situational is not None:
        return situational
    covered = " ".join([*_asked_questions(req), *_child_texts(req)])
    person = _is_person_drawing(req, target)
    purpose = "FOLLOW_UP" if _last_child_index(req) is not None else "DRAWING_CONTEXT"
    for _axis, markers, question, person_only in _DIARY_AXES:
        if person_only and not person:
            continue
        if any(marker in covered for marker in markers):
            continue
        return question, purpose, None
    # 축을 다 썼으면 아이가 고르게 열어 둔다.
    return QUALITY_OPEN_QUESTION, "DRAWING_CONTEXT", None


def _detect_crisis(req: QuestionRequest) -> str | None:
    """아이 발화에서 자해·학대·위기 신호를 탐지한다(S15P11B209-593).

    곰돌이(AI) 발화는 우리가 만든 것이라 검사하지 않고, senderType이 CHILD인 발화만 본다.
    신호가 있으면 사유 코드를 반환한다(없으면 None).
    """
    child_texts = [
        m.text
        for m in req.recent_messages
        if (m.sender_type or "").upper() == "CHILD" and m.text
    ]
    return crisis_detection.scan(child_texts)


def _evaluate_safety(
    question_text: str, rule_version: str, request_id: str
) -> tuple[SafetyResult, str]:
    """생성된 질문을 안전 판정 파이프라인에 통과시킨다(S15P11B209-596).

    question_safety.evaluate가 형식 정화 + 진단표현·위기 소재 차단을 순서대로 판정한다.
    - 차단이면 SafetyBlockedError를 던진다 → 엔드포인트가 422 AI_SAFETY_POLICY_BLOCKED로
      매핑(BE는 저장 없이 폴백 템플릿으로 대체).
    - 통과면 (PASSED SafetyResult, 정화된 질문 텍스트)를 돌려준다 — 정화본을 아동 화면에 쓴다.

    ⚠️ 차단 시에도 질문 원문은 로그에 남기지 않는다 — 사유 코드만.
    """
    verdict = question_safety.evaluate(question_text)
    if verdict.blocked:
        logger.warning(
            "생성 질문 안전 차단: reason=%s request_id=%s",
            verdict.block_reason_code,
            request_id,
        )
        raise SafetyBlockedError(
            verdict.block_reason_code or "UNSPECIFIED", rule_version
        )
    safety = SafetyResult(
        status="PASSED", rule_version=rule_version, block_reason_code=None
    )
    return safety, verdict.sanitized_text


# ── GMS 호출 + 제한적 재시도 ────────────────────────────────────
def _is_retryable(error: OpenAIError) -> bool:
    """일시 오류(재시도 가치 있음)인지 분류.

    - APIConnectionError: 연결 실패·타임아웃(APITimeoutError는 하위 클래스) → 재시도
    - APIStatusError 5xx: 게이트웨이/서버 일시 장애 → 재시도
    - 그 외(4xx: 인증·요청 오류·429 포함): 재시도해도 같은 결과 → 즉시 실패
    """
    if isinstance(error, APIConnectionError):
        return True
    if isinstance(error, APIStatusError):
        return error.status_code >= 500
    return False


def _call_gms_with_retry(messages: list[dict], request_id: str) -> tuple[str, str]:
    """GMS 질문 생성 호출. 성공 시 (질문 텍스트, 실제 서빙 모델명)을 반환한다.

    - with_options(timeout=4s, max_retries=0):
      공용 클라이언트의 60s timeout과 SDK 자체 재시도(기본 2회)를 이 경로에서만 끈다.
      reason: SDK 내부 재시도가 살아 있으면 우리 백오프와 겹쳐 BE 15s 예산을 넘는다.
    - 백오프: base × 2^(재시도 차수-1) → 0.5s, 1.0s.
    """
    client = get_client().with_options(
        timeout=config.QUESTION_LLM_TIMEOUT_SEC,
        max_retries=0,
    )
    total_attempts = config.QUESTION_LLM_MAX_RETRIES + 1
    last_error: OpenAIError | None = None
    for attempt in range(1, total_attempts + 1):
        if attempt > 1:
            time.sleep(config.QUESTION_LLM_BACKOFF_BASE_SEC * (2 ** (attempt - 2)))
        try:
            resp = client.chat.completions.create(
                model=config.LLM_MODEL,
                messages=messages,
                temperature=0.6,  # 아동 대화는 튀지 않게 다소 낮게(llm_client와 동일 기준)
            )
            text = resp.choices[0].message.content or ""
            served_model = getattr(resp, "model", "") or ""
            return text, served_model
        except OpenAIError as e:
            # ⚠️ messages(아이 발화 포함 가능)는 로그 금지 — 유형·시도 횟수·request_id만.
            logger.warning(
                "GMS 질문 생성 실패: type=%s attempt=%d/%d request_id=%s",
                type(e).__name__,
                attempt,
                total_attempts,
                request_id,
            )
            if not _is_retryable(e):
                raise UpstreamError("AI_UPSTREAM_REJECTED", type(e).__name__) from e
            last_error = e
    raise UpstreamError(
        "AI_UPSTREAM_UNAVAILABLE",
        type(last_error).__name__ if last_error else "Unknown",
    ) from last_error


# ── 진입점 ──────────────────────────────────────────────────────
def generate(req: QuestionRequest, request_id: str) -> QuestionResponse:
    """질문 1건 생성 — BE isContractValidFor를 통과하는 응답을 조립한다.

    Raises:
        UpstreamError: GMS 최종 실패(→ 502, BE 폴백 템플릿 경로).
        SafetyBlockedError: 안전 정책 차단(→ 422, BE 사용자 422 경로).
    """
    started = time.monotonic()

    # 위기 신호(자해·학대·위기 의도)는 대화를 끊지 않고 안전·지지형 응답으로 이어간다
    # (S15P11B209-593). 아이에게 dead-end(422)를 주는 대신, 위기를 캐묻지 않는 결정적
    # 안전 응답을 돌려주고 위기 사실은 서버 경보 로그(사유 코드)로 남긴다.
    crisis_reason = _detect_crisis(req)
    if crisis_reason:
        # ⚠️ 아이 발화 원문은 남기지 않는다 — 사유 코드·request_id만.
        logger.warning(
            "위기 신호 감지 — 안전 응답으로 지속: reason=%s request_id=%s",
            crisis_reason,
            request_id,
        )
        # 같은 위기라도 보호자에게는 제대로 된 안내를 전한다(S15P11B209-598). 문구 생성 규칙은
        # crisis_guidance가 검토된 템플릿으로 만든다. 보호자에게 '띄우는' BE 배선(알림/화면 필드)은
        # 계약 확장이 필요한 공동 후속이라, 지금은 안내 준비 사실만 서버 신호로 남긴다(원문 없음).
        alert = crisis_guidance.guidance_for(crisis_reason)
        if alert is not None:
            logger.warning(
                "보호자 위기 안내 준비: severity=%s reason=%s request_id=%s",
                alert.severity,
                alert.reason_code,
                request_id,
            )
        else:
            # 보호자에게 자동 전달하지 않는 사유(학대 진술 등)는 안내가 없다 — 그렇다고 신호를
            # 조용히 흘리면 아무도 모른다. 전문가 검토 경로로 남긴다는 사실을 로그에 남긴다
            # (S15P11B209-890). 여기서도 아이 발화 원문은 남기지 않는다.
            note = crisis_guidance.expert_note_for(crisis_reason)
            if note is not None:
                logger.warning(
                    "보호자 자동 안내 보류 — 전문가 검토 경로: severity=%s reason=%s "
                    "expert_review=%s request_id=%s",
                    note.severity,
                    note.reason_code,
                    note.requires_expert_review,
                    request_id,
                )
        return _crisis_safe_response(req, started)

    # 프롬프트 인젝션(맥락 파괴 시도)은 LLM에 전달하지 않고 결정적 재질문으로 되묻는다
    # (S15P11B209-742). 위기와 달리 대화를 끊지 않는다 — 정상적인 "다시 말해줄래?"로 이어간다.
    injection_reason = _detect_injection(req)
    if injection_reason:
        # ⚠️ 아이 발화 원문은 남기지 않는다 — 사유 코드·request_id만.
        logger.warning(
            "프롬프트 인젝션 차단 — 재질문: reason=%s request_id=%s",
            injection_reason,
            request_id,
        )
        return _reask_response(req, started)

    # 아이가 그만하고 싶다고 말했으면 다음 질문을 만들지 않고 무엇을 그만할지 되묻는다
    # (S15P11B209-938). 위기·인젝션 뒤에 두는 이유: "다 싫어, 그만할래"는 그만하기 의사일
    # 수도 위기 신호일 수도 있다. 이 분기를 위기 검사 앞에 두면 위기 신호를 조용히 삼킨다.
    # 되묻기에 말로 답한 확인이 먼저다(S15P11B209-951). 뒤에 두면 "응, 그만할래"가 아래
    # _detect_stop_intent에 다시 걸려 같은 되묻기를 반복한다 — 950이 칩에서 고친 자가 트리거가
    # 음성 경로로 되살아난다. 위기·인젝션보다는 뒤다(938과 같은 이유).
    just_reasked = _last_reask_branch(req)
    confirmed = _stop_confirmation_response(req, started, just_reasked)
    if confirmed is not None:
        # ⚠️ 아이 발화 원문은 남기지 않는다 — 대상 코드만.
        logger.info(
            "그만하기 확인(음성) — target=%s request_id=%s",
            confirmed.confirmed_stop_target or "NARROWED",
            request_id,
        )
        return confirmed

    # 방금 되물었는데 확인도 부정도 아닌 답이 왔으면 **같은 되묻기를 반복하지 않는다.**
    # 반복하면 950이 칩에서 고친 자가 트리거가 음성 경로로 되살아나고, 계속 물으면
    # 그만두라고 떠미는 것처럼 들린다(718과 같은 결). 평소 흐름으로 돌아가고, 아이가
    # 다시 그만하겠다고 말하면 그때 새로 되묻는다.
    stop_verdict = None if just_reasked else _detect_stop_intent(req)
    if stop_verdict:
        # ⚠️ 아이 발화 원문은 남기지 않는다 — 판정 코드만.
        logger.info(
            "그만하기 의사 감지 — 되묻기: verdict=%s activityType=%s request_id=%s",
            stop_verdict or "-",
            req.activity_type or "-",
            request_id,
        )
        return _stop_intent_response(
            req, started, stop_verdict or conversation_stop_intent.STOP_CONVERSATION
        )

    # 그림일기 완전 첫 질문은 GMS 없이 고정 문구로 연다(S15P11B209-921). 무엇을 그렸는지는
    # 아이만 아는 정보라 AI가 추측하지 않고 직접 묻는다. 위기·인젝션 검사 뒤에 두는 이유:
    # 질문 수가 0이어도 아이 발화가 이력에 있을 수 있는 경로(FE 복원)가 그 검사를 우회하면
    # 안 된다.
    if _is_diary_opening(req):
        logger.info(
            "[질문] request_id=%s drawingSessionId=%s activityType=ART_DIARY "
            "purpose=DRAWING_CONTEXT | 고정 첫 질문(GMS 미호출)",
            request_id,
            req.drawing_session_id,
        )
        return _diary_opening_response(req, started)

    # 목적·대상을 GMS 호출 전에 정해 프롬프트에 그대로 싣는다(S15P11B209-713) — 질문 문장과
    # 응답 targetObject가 같은 객체를 가리키게 하고, HTP면 주제를 벗어난 명사가 안 나오게 한다.
    option_allowed = "OPTION" in req.allowed_response_modes
    purpose = _pick_question_purpose(req)
    target = _target_for_purpose(req, purpose)
    if purpose == "OBJECT_DESCRIPTION" and target is None:
        # 주제 객체가 없거나 후보를 모두 물어봤으면 특정 객체 대신 그림 전체를 묻는다.
        purpose = "DRAWING_CONTEXT"

    # 탐지 부정 처리(S15P11B209-718). 아이가 방금 고른 칩으로 분기한다.
    #   - 탈출 칩("이 중에 없어") → 그림 전체를 다시 여는 질문.
    #   - 부정("아니야") → 이미 탐지된 다른 객체를 후보 칩으로 재질문. 단 연속 부정(2회 이상)이면
    #     후보를 또 들이밀지 않고 열린 질문으로 넘어간다(아이가 계속 부정당하는 경험 방지, 9절).
    candidate_options: list[QuestionOption] | None = None
    reask_candidates = False
    selected_codes = _last_child_selected_codes(req)
    if _ESCAPE_CODE in selected_codes:
        purpose, target = "DRAWING_CONTEXT", None
    elif _NEGATION_CODE in selected_codes:
        cand = (
            _candidate_options(req)
            if option_allowed and _negation_count(req) < 2
            else []
        )
        if cand:
            purpose, target = "FOLLOW_UP", None
            candidate_options = cand
            reask_candidates = True
        else:
            purpose, target = "DRAWING_CONTEXT", None

    messages = _build_messages(
        req, purpose=purpose, target=target, reask_candidates=reask_candidates
    )
    text, served_model = _call_gms_with_retry(messages, request_id)
    text = text.strip()
    if not text:
        # 빈 질문은 아동 화면에 내보낼 수 없다 → 실패로 취급해 BE 폴백 템플릿에 맡긴다.
        raise UpstreamError("AI_EMPTY_COMPLETION", "EmptyCompletion")

    # 안전 판정 파이프라인 통과 후 정화된 질문을 쓴다(차단이면 여기서 422로 올린다).
    safety, text = _evaluate_safety(text, req.safety_rule_version, request_id)
    if not text:
        # 정화 후 남는 게 없으면(기호뿐이었으면) 빈 출력 — 폴백 템플릿에 맡긴다.
        raise UpstreamError("AI_EMPTY_COMPLETION", "EmptyCompletion")

    # 한 응답에 질문이 둘이면 아이가 무엇에 답할지 고르지 못한다 — 앞의 반응과 첫 질문만
    # 남긴다(S15P11B209-954). 교체가 아니라 잘라내기라 활동유형과 무관하게 적용한다.
    if question_quality.find_multiple_questions(text):
        # ⚠️ 질문 원문은 남기지 않는다 — 사유 코드만.
        logger.warning(
            "질문 여러 개 — 하나로 축소: reason=%s request_id=%s",
            question_quality.MULTIPLE_QUESTIONS,
            request_id,
        )
        text = question_quality.to_single_question(
            text,
            drawing_description=_truncate_description(req.drawing_description),
            child_texts=_child_texts(req),
        )

    # 문맥상 어색한 질문(그림 속 부위의 소유자를 묻는 등)은 차단하지 않고 교체한다
    # (S15P11B209-918). 안전 판정 뒤에 두는 이유: 교체 문장은 우리가 쓴 것이라 다시
    # 판정할 필요가 없고, 안전 차단이 먼저 걸리는 문장은 애초에 여기 오지 않는다.
    quality_replaced = False
    quality_reason = question_quality.find_awkward(text)
    # 그림·아이 말로 이미 답을 아는 질문도 같은 방식으로 교체한다(S15P11B209-954).
    # ⚠️ 그림일기에서만 본다. HTP는 지붕 모양·나무 크기가 PDI 표준 문항이라, 여기서 걸러
    #    내면 htp_question_bank가 통째로 죽는다.
    if not quality_reason and req.activity_type == "ART_DIARY":
        quality_reason = question_quality.find_redundant(
            text,
            drawing_description=_truncate_description(req.drawing_description),
            child_texts=_child_texts(req),
        )
    # 그림일기에서만 보는 위반을 사유별로 가른다(S15P11B209-999). HTP는 제외한다 —
    #   부위·색·형태 질문이 PDI 표준 문항이고, 감정 질문도 그 축의 정식 항목이다.
    if not quality_reason and req.activity_type == "ART_DIARY":
        correction = _correction(req)
        corrected = correction.label if correction else None
        # 부위를 바로잡은 턴에서만 '부위가 사건의 주인공'인 문장을 본다(999).
        part = (
            corrected
            if correction is not None and correction.semantic_type == BODY_PART
            else None
        )
        quality_reason = (
            question_quality.find_visual_evaluation(text)
            or question_quality.find_asserted_emotion(text)
            or question_quality.find_stale_label(text, _stale_labels(req))
            or question_quality.find_body_part_actor(text, part)
        )
        # 아이가 방금 이름을 바로잡았거나 건너뛰겠다고 한 직후에는, 마음을 묻거나 정체를
        #   되묻는 쪽으로 건너뛰지 않는다. 두 자리 모두 이어 갈 이야기가 이미 있다.
        if not quality_reason and (corrected or _skip_intent(req)):
            if question_quality.is_emotion_question(text):
                quality_reason = question_quality.UNGROUNDED_EMOTION
            elif question_quality.is_identity_question(text):
                quality_reason = question_quality.IDENTITY_FALLBACK
    if quality_reason:
        # ⚠️ 질문 원문은 남기지 않는다 — 사유 코드만(안전 차단 로그와 같은 규칙).
        logger.warning(
            "질문 품질 교체: reason=%s request_id=%s", quality_reason, request_id
        )
        # 999에서 추가한 그림일기 사유들도 같은 복구 경로를 쓴다 — 상태별 문장을 먼저 고르고,
        #   해당하는 상태가 없을 때만 축 표로 내려간다.
        if quality_reason in _DIARY_QUALITY_REASONS:
            text, purpose, target = _diary_axis_replacement(req, target)
        else:
            text, purpose, target = _quality_replacement(req, purpose, target)
        quality_replaced = True
        candidate_options = None

    # 생성된 질문이 마음·느낌을 묻는 문장이면 EXPRESSION으로 재분류해 감정 칩을 붙인다
    # (S15P11B209-650: 칩을 '질문 내용'과 맞춘다). 목적은 생성 전에 정하지만 감정 질문 여부는
    # 문장을 봐야 알 수 있어 여기서 보정한다. 부정 후보 재질문(718) 중에는 그 칩을 유지한다.
    if candidate_options is None and _is_expression_question(text):
        purpose, target = "EXPRESSION", None

    # 칩·정합성은 위(프롬프트 조립 전)에서 정한 목적·대상을 그대로 쓴다 — 프롬프트에 실은 것과
    # 응답 targetObject가 어긋나지 않게 한다(S15P11B209-713). 부정 재질문이면 후보 칩(718)을 쓴다.
    # OPTION 비허용이면 반드시 null — 빈 배열도 계약 위반이다(isContractValidFor).
    if not option_allowed:
        options = None  # OPTION 비허용 → 칩 없음(빈 배열도 계약 위반)
    elif quality_replaced and target is None:
        # 교체된 열린 질문에 탐지 후보 칩(747의 '무엇→후보' 규칙)을 붙이면, 방금 억누른
        # 오탐 이름이 칩으로 아이 화면에 다시 올라온다(S15P11B209-918). 우리가 쥔 큐레이션
        # 라벨만 쓴다 — 정체를 묻는 교체 질문(954)에는 사람 칩이, 그 밖에는 목적별 generic이
        # 붙는다. 어느 쪽도 탐지 이름을 화면에 올리지 않는다.
        options = (
            _labeled_chips(_WHO_CHIPS, escape="다른 사람이야")
            if _RE_WHO.search(text)
            else _options_for_purpose(purpose)
        )
    elif candidate_options is not None:
        options = candidate_options  # 부정 재질문 후보(718)
    elif _NEGATION_CODE in selected_codes or _ESCAPE_CODE in selected_codes:
        # 부정/탈출 뒤 열린 질문(718) — 아이가 거부·탈출한 뒤라 후보를 다시 들이밀지 않고
        # 목적별 generic 칩을 쓴다(747의 '무엇→후보' 규칙이 재제시하는 것을 막는다).
        options = _options_for_purpose(purpose)
    elif purpose == "EXPRESSION":
        options = _options_for_purpose(purpose)  # 감정 칩(650)
    else:
        # 질문 내용 맞춤 칩(747, 방향 D): 규칙(B) → LLM 2차(A) → 목적별 generic 폴백.
        options = _content_chips(text, req)
        if options is None and _RE_WH.search(text):
            # 2차 GMS 호출은 BE 15s 예산 안에서만 — 이미 많이 썼으면 건너뛰고 generic으로.
            if time.monotonic() - started < config.QUESTION_LLM_TIMEOUT_SEC * 2:
                options = _llm_answer_chips(text, req, request_id)
        if options is None:
            options = _options_for_purpose(purpose)
    if not _is_consistent(purpose, target, options, option_allowed):
        # 정합성이 깨진 조합은 아동 화면에 내보내지 않는다 → 실패로 돌려 BE 폴백에 맡긴다.
        raise UpstreamError("AI_INCONSISTENT_RESPONSE", "Consistency")

    # 생성된 질문 원문은 남기지 않는다(가드레일). 대신 "어떤 재료로 만들었는가"를 남겨
    # 분석 로그의 [필터] 줄과 drawingSessionId로 이어붙일 수 있게 한다.
    # activityType·drawingSubject를 함께 남겨 어느 HTP 단계였는지 로그만으로 판별한다
    # (S15P11B209-712). 값이 없으면(그림일기·주제 미전달 요청) "-"로 남긴다.
    # unnamed: 서술이 뒷받침하지 못해 프롬프트에서 뺀 탐지 이름의 수(S15P11B209-918).
    # 개수만 남긴다 — 이름 자체는 아동 그림 내용이라 상세 로그 규칙을 따른다. 이 값이 크면
    # 탐지와 서술이 크게 어긋난 그림이라, 나중에 오탐 경향을 코드 없이 되짚을 수 있다.
    logger.info(
        "[질문] request_id=%s drawingSessionId=%s basisAnalysisId=%s "
        "activityType=%s drawingSubject=%s purpose=%s target=%s unnamed=%d | %s",
        request_id,
        req.drawing_session_id,
        req.basis_analysis_id if req.basis_analysis_id is not None else "-",
        req.activity_type or "-",
        req.drawing_subject or "-",
        purpose,
        _format_target_for_log(target),
        len(req.detected_objects) - len(_nameable_objects(req)),
        _format_objects_for_log(req),
    )

    return QuestionResponse(
        question_text=text,
        question_purpose=purpose,
        options=options,
        target_object=target,
        fallback_used=False,  # AI 서버 자체 폴백 없음 — 폴백 템플릿은 BE 소유
        safety_result=safety,
        model_name=config.LLM_MODEL,
        # modelVersion: GMS가 실제 서빙한 모델 ID(예: gpt-4o-mini-2024-07-18) — 재현성 기록.
        model_version=served_model or config.LLM_MODEL,
        # 이번 생성이 '실제로 쓴' 활동 변형만 담는다(S15P11B209-786).
        prompt_version=llm_client.prompt_version_for(req.activity_type),
        processing_time_ms=int((time.monotonic() - started) * 1000),
    )
