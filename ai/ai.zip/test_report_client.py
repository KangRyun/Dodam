"""report_client 단위 테스트 — GMS 호출을 가짜로 대체해 조립·에러 매핑만 검증.

실제 네트워크·모델 없이 돈다. get_client 를 monkeypatch 해 chat.completions.create
호출 인자(프롬프트)를 가로채고, LLM JSON → 계약 결과 조립, 서버 고정 필드(안전 문구·상태),
emotion_source 규칙, visibility_scope 강제, OpenAIError → RuntimeError 변환을 확인한다.
"""

from __future__ import annotations

import json
import types
import unittest
from unittest import mock

from openai import OpenAIError

import config
import internal_contracts as contracts
import prompts_registry
import report_client


def _fake_response(text: str, *, model: str | None = None):
    message = types.SimpleNamespace(content=text)
    choice = types.SimpleNamespace(message=message)
    resp = types.SimpleNamespace(choices=[choice])
    if model is not None:
        resp.model = model  # GMS가 실제 서빙한 모델 ID
    return resp


def _llm_json(**overrides) -> str:
    """LLM이 돌려줄 법한 JSON 문자열(정성 필드만). overrides로 일부 키 교체."""
    payload = {
        "overallSummary": "아이는 그림 활동에 즐겁게 참여했어요.",
        "positiveSignals": "자기 생각을 적극적으로 표현했어요.",
        "attentionPoints": "특이 관찰 사항 없음",
        "evidenceSummary": "집을 크게 그리고 가족을 함께 그린 점에서 관찰됨.",
        "guardianGuidance": "아이의 이야기를 편안하게 들어주세요.",
        "followUpQuestion": "이 집에는 누가 살고 있어?",
        "expertReviewRequired": False,
        "features": [
            {
                "featureCode": "HOUSE_CENTER",
                "title": "가운데 큰 집",
                "description": "집을 화면 가운데에 크게 그렸어요.",
                "evidenceSummary": "그림 관찰 서술 근거",
                "visibilityScope": "REVIEWED_GUARDIAN",
            }
        ],
        "conversationSummary": {
            "summaryText": "우리 집과 가족 이야기를 나눴어요.",
            "mainTopic": "우리 집",
            "expressedEmotion": "즐거움",
        },
        "activityNotes": ["활동 내내 집중했어요."],
        "followUpGuides": [
            {"guidance": "개방형 질문으로 이야기해 보세요.", "detailText": "정답을 요구하지 않는 질문이 표현을 돕습니다."}
        ],
        "guardianQuestions": [
            {"questionText": "가장 마음에 드는 부분은 어디야?", "questionPurpose": "표현 확장"}
        ],
    }
    payload.update(overrides)
    return json.dumps(payload, ensure_ascii=False)


# 자체검토(2-pass)가 '지적 없음'으로 통과하는 응답. 2026-08-05부터 generate()는 GMS를
# 두 번 부른다(생성 → 자체검토).
_REVIEW_PASS = json.dumps({"findings": []}, ensure_ascii=False)


def _review_findings(*findings: dict) -> str:
    """자체검토가 지적을 낸 응답 JSON."""
    return json.dumps({"findings": list(findings)}, ensure_ascii=False)


def _capture_generation(
    captured: dict, generation: str | None = None, review: str = _REVIEW_PASS, *, model=None
):
    """생성 → 자체검토 순서로 응답하는 side_effect. **첫 호출(생성) 인자만** captured 에 남긴다.

    덮어쓰면 검토 프롬프트가 잡혀 "생성 프롬프트에 이 블록이 실렸나"를 보는 검증이 헛돈다.
    검토 호출 인자는 별도 키(review_messages)로 남긴다.
    """
    payloads = [generation if generation is not None else _llm_json(), review]
    calls = {"n": 0}

    def create(**kwargs):
        index = calls["n"]
        calls["n"] += 1
        if index == 0:
            captured["model"] = kwargs.get("model")
            captured["messages"] = kwargs["messages"]
        else:
            # 검토 호출의 모델도 남긴다 — 생성과 같아야 한다(S15P11B209-972).
            captured["review_model"] = kwargs.get("model")
            captured["review_messages"] = kwargs["messages"]
        return _fake_response(payloads[min(index, len(payloads) - 1)], model=model)

    return create


def _fake_client(generation: str | None = None, review: str = _REVIEW_PASS, *, model=None):
    """generate() 한 번을 온전히 흉내 내는 가짜 GMS 클라이언트(captured 불필요할 때)."""
    client = mock.Mock()
    client.chat.completions.create.side_effect = _capture_generation(
        {}, generation, review, model=model
    )
    return client


def _sample_request(**overrides) -> contracts.ObservationGenerationRequest:
    base = {
        "request_id": "req-1",
        "analysis_id": 10,
        "drawing_session_id": 20,
        "analysis_type": "FINAL",
        "question_difficulty": "PRESCHOOL",
        "question_count": 5,
        "answered_count": 4,
        "skipped_count": 1,
        "unrecognized_speech_count": 0,
        "selected_emotions": ["JOY"],
        "expressed_emotion_text": None,
        "representative_utterance": "이건 우리 집이야.",
    }
    base.update(overrides)
    return contracts.ObservationGenerationRequest(**base)


def _htp_request(**overrides) -> contracts.ObservationGenerationRequest:
    """HTP 활동 요청 — drawingSubject가 채워진 subject_summaries가 HTP 판별 근거다.

    RAG는 HTP 리포트에서만 검색한다. 그림일기(subject 없음)·구 BE(빈 목록)는
    검색을 건너뛰고 RAG_NOT_APPLICABLE로 표시된다.
    """
    overrides.setdefault(
        "subject_summaries",
        [
            contracts.SubjectSummary(
                drawing_subject="HOUSE",
                drawing_description="집이 가운데에 크게 그려져 있어요.",
                detected_object_codes=["HOUSE"],
            )
        ],
    )
    return _sample_request(**overrides)


class GenerateTest(unittest.TestCase):
    def test_assembles_contract_result_with_server_owned_fields(self):
        captured = {}

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        req = _sample_request()
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(
                req,
                drawing_description="가운데에 집이 크게, 왼쪽에 나무가 있어요.",
                model="test-model",
            )

        # 서버가 고정으로 채우는 필드
        self.assertEqual(result.request_id, "req-1")  # 요청 에코
        self.assertEqual(result.model_name, "test-model")
        # model_version은 프롬프트+파이프라인 복합 버전(S15P11B209-602).
        # _sample_request()는 subject_summaries가 없어 그림일기(비 HTP) 경로다.
        self.assertEqual(result.model_version, report_client._generation_version(False))
        self.assertIsNone(result.confidence)
        # 자체검토가 지적 없이 통과한 리포트라 AI_REVIEWED(2026-08-05).
        self.assertEqual(result.observation_draft.status, "AI_REVIEWED")
        self.assertEqual(result.observation_draft.disclaimer, report_client.DISCLAIMER)
        self.assertEqual(result.limitations_text, report_client.LIMITATIONS)

        # LLM 정성 필드가 그대로 실렸는지
        self.assertIn("즐겁게", result.observation_draft.overall_summary)
        self.assertEqual(len(result.observation_draft.features), 1)
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )
        self.assertEqual(result.conversation_summary.main_topic, "우리 집")

        # emotion_source 는 요청으로 결정(선택 감정 있음 → SELECTED)
        self.assertEqual(result.conversation_summary.emotion_source, "SELECTED")
        # 대표 발화는 요청 값 에코
        self.assertEqual(
            result.conversation_summary.representative_utterance, "이건 우리 집이야."
        )

        # 그림 서술이 프롬프트(user 메시지)에 근거로 들어갔는지
        user_msg = captured["messages"][1]["content"]
        self.assertIn("가운데에 집이 크게", user_msg)
        self.assertIn("[그림 관찰 서술]", user_msg)

    def test_absent_utterance_stays_none_and_is_not_invented(self):
        """대표 발화가 없으면 None 이다 — 무난한 문장으로 채우지 않는다.

        아이가 한 말이 없는데 "재미있었어요." 같은 기본값을 넣으면, 아이가 한 적 없는 말이
        대표 발화로 저장된다. 폐지 시점 운영 실측으로 analysis_conversation_summaries
        51건 중 34건(67%)이 그 기본값이었다. 지금은 아무도 읽지 않는 컬럼이지만 읽는 기능이
        생기면 그대로 가짜 인용이 되므로, 없는 것은 없는 대로 둔다(confidence=None 과 같은 원칙).
        """
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        req = _sample_request(representative_utterance=None)
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(
                req,
                drawing_description="가운데에 집이 크게 그려져 있어요.",
                model="test-model",
            )

        self.assertIsNone(result.conversation_summary.representative_utterance)
        self.assertNotIn(
            "재미있었어요",
            json.dumps(result.model_dump(by_alias=True), ensure_ascii=False),
        )

    def test_behavior_metrics_injected_into_prompt(self):
        captured = {}

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        behavior = contracts.BehaviorMetrics(
            drawing_duration_ms=600_000,
            pause_count=4,
            erase_count=3,
            pressure_available=True,
            average_pressure=0.62,
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(_sample_request(), behavior=behavior, model="m")

        user_msg = captured["messages"][1]["content"]
        self.assertIn("[형식적 분석]", user_msg)
        self.assertIn("약 10분", user_msg)  # 600_000ms → 10분
        self.assertIn("지우기 횟수: 3회", user_msg)
        self.assertIn("평균 0.62", user_msg)

    def test_pressure_line_is_omitted_without_a_value(self):
        """필압 강약 값이 없으면 필압 줄을 아예 내지 않는다 (S15P11B209-838).

        pressure_available 은 기기가 측정할 수 있는지일 뿐 아이에 대한 관찰이 아니다 —
        "측정됨"·"측정 불가"를 적으면 관찰 내용이 0인 줄이 해석 재료처럼 놓인다.
        """
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        behavior = contracts.BehaviorMetrics(
            pressure_available=True, average_pressure=None, erase_count=1
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(_sample_request(), behavior=behavior, model="m")

        user_msg = captured["messages"][1]["content"]
        self.assertNotIn("필압", user_msg)
        self.assertIn("지우기 횟수: 1회", user_msg)  # 다른 항목은 그대로 실린다


class BehaviorMetricsContractTest(unittest.TestCase):
    """요청 계약으로 들어온 형식 지표가 프롬프트까지 도달하는지 (S15P11B209-836).

    확장 전에는 behavior 를 넘길 수단이 계약에 없어 [형식적 분석] 블록이 운영 경로에서
    한 번도 실리지 않았다 — 이 테스트가 그 배선을 고정한다.
    """

    def _capture_prompt(self, req) -> str:
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(req, model="m")
        return captured["messages"][1]["content"]

    def test_request_behavior_metrics_reach_the_prompt(self):
        req = _sample_request()
        req.behavior_metrics = contracts.BehaviorMetrics(
            drawing_duration_ms=720_000, erase_count=3, pressure_available=False
        )

        user_msg = self._capture_prompt(req)

        self.assertIn("[형식적 분석]", user_msg)
        self.assertIn("약 12분", user_msg)
        self.assertIn("지우기 횟수: 3회", user_msg)

    def test_absent_behavior_metrics_keeps_legacy_behaviour(self):
        """구 BE(behaviorMetrics 미전달) 요청은 확장 전과 똑같이 동작한다."""
        user_msg = self._capture_prompt(_sample_request())

        self.assertNotIn("[형식적 분석]", user_msg)

    def test_zero_and_none_are_distinguished(self):
        """0은 '0회'라는 관찰 사실, None은 '집계 못 함' — 같은 문장이 되면 안 된다."""
        req = _sample_request()
        req.behavior_metrics = contracts.BehaviorMetrics(
            pause_count=0, erase_count=None, pressure_available=False
        )

        user_msg = self._capture_prompt(req)

        self.assertIn("멈춤 횟수: 0번", user_msg)
        self.assertNotIn("지우기 횟수", user_msg)

    def test_explicit_argument_overrides_contract_value(self):
        """draft·스모크가 계약 밖 값을 넣어 볼 수 있어야 한다."""
        req = _sample_request()
        req.behavior_metrics = contracts.BehaviorMetrics(drawing_duration_ms=60_000)
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(
                req,
                behavior=contracts.BehaviorMetrics(drawing_duration_ms=600_000),
                model="m",
            )

        self.assertIn("약 10분", captured["messages"][1]["content"])

    def test_camel_case_payload_parses(self):
        """BE가 보내는 camelCase JSON이 계약 모델로 그대로 들어온다."""
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "behaviorMetrics": {
                    "drawingDurationMs": 720000,
                    "activeDrawingMs": 480000,
                    "pauseCount": 4,
                    "undoCount": 2,
                    "eraseCount": 3,
                    "toolChangeCount": 1,
                    "colorChangeCount": 5,
                    "pressureAvailable": True,
                    "averagePressure": None,
                    "truncated": False,
                },
            }
        )

        self.assertEqual(720000, req.behavior_metrics.drawing_duration_ms)
        self.assertEqual(480000, req.behavior_metrics.active_drawing_ms)
        self.assertIsNone(req.behavior_metrics.average_pressure)
        self.assertFalse(req.behavior_metrics.truncated)


class ChipAnswerRefsTest(unittest.TestCase):
    """선택형 답변의 근거 참조 수집 (S15P11B209-994).

    이 집합이 게이트로 넘어가 OPTION 답변을 발화가 아니라 '고른 것'으로 등급 매기게 한다.
    수집이 조용히 비면 재분류 전체가 무효가 된다 — 배선을 못 박는다.
    """

    def test_only_option_answers_are_collected(self):
        req = _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject="HOUSE",
                    drawing_description="집이 있어요.",
                    qa_pairs=[
                        contracts.SubjectQaPair(
                            question="이 집에서는 무슨 일이 있었어?",
                            answer_text="생일잔치를 했어",
                            answer_type="VOICE",
                            answer_message_id=201,
                        ),
                        contracts.SubjectQaPair(
                            question="이 집 안은 어떤 느낌이야?",
                            answer_text="따뜻해요",
                            answer_type="OPTION",
                            answer_message_id=202,
                        ),
                        contracts.SubjectQaPair(
                            question="답 없는 질문",
                            answer_type="OPTION",
                            answer_message_id=None,
                        ),
                    ],
                )
            ]
        )
        self.assertEqual(
            report_client._chip_answer_refs(req),
            frozenset({("QA_ANSWER", "202")}),
        )

    def test_chip_marker_is_rendered_in_qa_block(self):
        """칩 답변은 재료 단계에서 '(선택지에서 고른 답이에요)'로 표시된다 — 프롬프트 규칙과 한 쌍."""
        req = _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject="HOUSE",
                    drawing_description="집이 있어요.",
                    qa_pairs=[
                        contracts.SubjectQaPair(
                            question="이 집 안은 어떤 느낌이야?",
                            answer_text="따뜻해요",
                            answer_type="OPTION",
                            answer_message_id=202,
                        ),
                    ],
                )
            ]
        )
        message = report_client._format_activity(req, None, None, None)
        self.assertIn("따뜻해요 (선택지에서 고른 답이에요)", message)


class ChildAgeBlockTest(unittest.TestCase):
    """연령 규준 축의 재료 — [활동 데이터]의 나이 줄 (S15P11B209-1001).

    나이가 있으면 "만 N세"로 실리고, 없으면 **줄 자체가 빠진다** — "없음"으로 적으면
    모델이 나이를 짐작해 채우는 압력이 된다. 프롬프트의 연령 지시(발달 문맥은 안심용,
    근거 아님, 또래 비교 금지)와 한 쌍이다.
    """

    def test_child_age_line_is_included_when_present(self):
        req = _sample_request(child_age=7)
        message = report_client._format_activity(req, None, None, None)
        self.assertIn("- 아이 나이: 만 7세", message)

    def test_child_age_line_is_absent_when_missing(self):
        req = _sample_request()
        message = report_client._format_activity(req, None, None, None)
        self.assertNotIn("아이 나이", message)

    def test_prompts_state_age_is_context_not_evidence(self):
        """연령 문맥이 근거 게이트를 우회하면 나이 하나로 카드가 만들어진다 — 못 박는다."""
        for name in ("report_htp", "report_diary"):
            text = prompts_registry.load(name)
            with self.subTest(name=name):
                self.assertIn("발달 문맥으로 설명해도 좋다", text)
                self.assertIn("연령 문맥은 근거가 아니다", text)
                self.assertIn("또래보다 늦다·빠르다", text)
                self.assertIn("나이가 없으면 연령 이야기를 아예 꺼내지 마라", text)


class BehaviorBlockWordingTest(unittest.TestCase):
    """[형식적 분석] 블록의 표현 규칙 (S15P11B209-838).

    블록 생성만 검증하므로 LLM 호출 없이 _format_behavior 를 직접 부른다.
    """

    def test_truncated_marks_partial_aggregation(self):
        """부분 집계를 활동 전체처럼 읽히게 두면 안 된다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=720_000, truncated=True)
        )

        self.assertIn("저장된 캔버스 입력 구간까지만 집계", block)
        self.assertIn("활동 전체가 아닐 수 있어요", block)

    def test_complete_aggregation_has_no_partial_note(self):
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=720_000, truncated=False)
        )

        self.assertNotIn("저장된 캔버스 입력 구간", block)

    def test_htp_block_states_three_drawing_scope(self):
        """HTP는 BE가 세 단계를 합산해 보낸다 — 한 장 기준으로 읽히면 안 된다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=720_000), is_htp=True
        )

        self.assertIn("집·나무·사람 세 장을 합친 활동 전체 기준", block)

    def test_diary_block_has_no_htp_scope_note(self):
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=720_000), is_htp=False
        )

        self.assertNotIn("세 장", block)

    def test_pause_count_is_hedged_as_an_estimate(self):
        """배치 경계 기반 추정값이라 단정 표기를 피한다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(pause_count=4)
        )

        self.assertIn("약 4번", block)
        self.assertIn("추정값", block)

    def test_zero_pauses_avoid_the_approximation_word(self):
        """'약 0번'은 문장이 이상하다 — 0일 때만 숫자를 그대로 쓴다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(pause_count=0)
        )

        self.assertIn("멈춤 횟수: 0번", block)
        self.assertNotIn("약 0번", block)

    def test_minutes_are_rounded_to_whole_minutes(self):
        """0.1분 자리는 집계가 갖지 않은 정밀도다(구 구현의 '약 10.0분')."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                drawing_duration_ms=600_000, active_drawing_ms=410_000
            )
        )

        self.assertIn("총 소요시간: 약 10분", block)
        self.assertIn("실제 그린 시간: 약 7분", block)  # 410_000ms ≈ 6.83분 → 7분
        self.assertNotIn(".", block)

    def test_under_a_minute_is_not_rounded_to_zero(self):
        """'약 0분'은 아예 안 그린 것처럼 읽힌다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=30_000)
        )

        self.assertIn("1분 미만", block)
        self.assertNotIn("약 0분", block)

    def test_block_is_dropped_when_nothing_is_measurable(self):
        """적을 관찰이 하나도 없으면 빈 블록을 싣지 않는다 — 모델이 채우려 든다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(pressure_available=True, truncated=True)
        )

        self.assertEqual("", block)

    def test_tool_and_color_changes_are_rendered(self):
        """계약으로 받아 놓고 버리던 두 값을 싣는다 (2026-08-05).

        받고도 안 실으면 프롬프트 1행이 약속한 지표 목록과 실제 블록이 계속 어긋난다.
        """
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                erase_count=1, tool_change_count=3, color_change_count=5
            )
        )

        self.assertIn("지우기 횟수: 1회", block)
        self.assertIn("도구 바꾼 횟수: 3회", block)
        self.assertIn("색 바꾼 횟수: 5회", block)

    def test_tool_and_color_changes_keep_the_zero_none_split(self):
        """None은 '집계 못 함'이라 줄을 빼고, 0은 '0회'라는 관찰 사실이라 적는다."""
        none_block = report_client._format_behavior(
            contracts.BehaviorMetrics(erase_count=1)
        )
        self.assertNotIn("도구 바꾼 횟수", none_block)
        self.assertNotIn("색 바꾼 횟수", none_block)

        zero_block = report_client._format_behavior(
            contracts.BehaviorMetrics(tool_change_count=0, color_change_count=0)
        )
        self.assertIn("도구 바꾼 횟수: 0회", zero_block)
        self.assertIn("색 바꾼 횟수: 0회", zero_block)


class StrokeBehaviorBlockTest(unittest.TestCase):
    """획 수·색 가짓수·주제별 시간 (S15P11B209-975).

    strokes 에 과정 데이터가 쌓여 있는데도 리포트에 닿지 않던 지표들이다.
    """

    def test_stroke_count_is_rendered_with_its_overlap_stated(self):
        """지우개 획을 포함한다는 사실을 블록이 스스로 밝힌다.

        밝히지 않으면 모델이 획 수와 지우기 횟수를 서로 배타적인 값으로 읽어 비율을 만든다.
        """
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(stroke_count=42, erase_count=3)
        )

        self.assertIn("전체 획 수: 42획", block)
        self.assertIn("지우개로 그은 획 포함", block)

    def test_colors_used_count_is_rendered(self):
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(colors_used_count=4)
        )

        self.assertIn("사용한 색: 4가지", block)

    def test_new_metrics_keep_the_zero_none_split(self):
        """None은 '집계 못 함'이라 줄을 빼고, 0은 관찰 사실이라 적는다(기존 지표와 같은 규칙)."""
        none_block = report_client._format_behavior(
            contracts.BehaviorMetrics(erase_count=1)
        )
        self.assertNotIn("전체 획 수", none_block)
        self.assertNotIn("사용한 색", none_block)

        zero_block = report_client._format_behavior(
            contracts.BehaviorMetrics(stroke_count=0, colors_used_count=0)
        )
        self.assertIn("전체 획 수: 0획", zero_block)
        self.assertIn("사용한 색: 0가지", zero_block)

    def test_subject_durations_render_as_one_comparable_line(self):
        """"어느 그림에 더 오래 머물렀는가"의 재료 — 이 이슈의 핵심."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                subject_durations=[
                    contracts.SubjectDuration(
                        drawing_subject="HOUSE", drawing_duration_ms=480_000
                    ),
                    contracts.SubjectDuration(
                        drawing_subject="TREE", drawing_duration_ms=240_000
                    ),
                    contracts.SubjectDuration(
                        drawing_subject="PERSON", drawing_duration_ms=180_000
                    ),
                ]
            ),
            is_htp=True,
        )

        self.assertIn(
            "주제별 그리기 시간: 집 약 8분 · 나무 약 4분 · 사람 약 3분",
            block,
        )

    def test_partial_subject_durations_drop_the_whole_line(self):
        """🔴 부분 목록으로 순위를 매기면 아이에 대한 없는 관찰이 만들어진다.

        한 주제의 시간이 없으면 남은 둘만 적지 않고 줄 자체를 뺀다 — 남겨 두면
        "집을 가장 오래 그렸어요"가 실제로는 거짓일 수 있다.
        """
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                drawing_duration_ms=720_000,
                subject_durations=[
                    contracts.SubjectDuration(
                        drawing_subject="HOUSE", drawing_duration_ms=480_000
                    ),
                    contracts.SubjectDuration(
                        drawing_subject="TREE", drawing_duration_ms=None
                    ),
                ],
            )
        )

        self.assertNotIn("주제별 그리기 시간", block)
        # 나머지 지표는 그대로 실린다 — 한 줄의 문제로 블록 전체를 버리지는 않는다.
        self.assertIn("총 소요시간", block)

    def test_unknown_subject_code_drops_the_whole_line(self):
        """라벨을 모르는 주제가 섞여도 같은 이유로 비교가 성립하지 않는다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                drawing_duration_ms=720_000,
                subject_durations=[
                    contracts.SubjectDuration(
                        drawing_subject="HOUSE", drawing_duration_ms=480_000
                    ),
                    contracts.SubjectDuration(
                        drawing_subject="MYSTERY", drawing_duration_ms=250_000
                    ),
                ],
            )
        )

        self.assertNotIn("주제별 그리기 시간", block)

    def test_diary_has_no_subject_duration_line(self):
        """그림일기는 주제 구분이 없어 목록이 비어 있다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(drawing_duration_ms=720_000)
        )

        self.assertNotIn("주제별 그리기 시간", block)

    def test_new_metrics_alone_do_not_create_an_empty_block(self):
        """적을 관찰이 없으면 빈 블록을 싣지 않는다는 기존 규칙이 새 지표에도 걸린다."""
        block = report_client._format_behavior(
            contracts.BehaviorMetrics(
                subject_durations=[
                    contracts.SubjectDuration(
                        drawing_subject="HOUSE", drawing_duration_ms=None
                    )
                ]
            )
        )

        self.assertEqual("", block)

    def test_be_payload_reaches_the_block(self):
        """🔴 이음매 검증 — BE 가 보내는 camelCase JSON 그대로 파싱해 블록까지 간다.

        902 교훈: 단위 테스트가 통과해도 이음매가 이어져 있지 않으면 값이 도착하지 않는다.
        여기서 별칭(camelCase)이 어긋나면 필드가 조용히 기본값으로 남는다.
        """
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "req-975",
                "analysisId": 1,
                "drawingSessionId": 2,
                "analysisType": "FINAL",
                "behaviorMetrics": {
                    "drawingDurationMs": 900000,
                    "activeDrawingMs": 300000,
                    "strokeCount": 90,
                    "eraseCount": 6,
                    "colorsUsedCount": 3,
                    "pressureAvailable": True,
                    "averagePressure": None,
                    "truncated": False,
                    "subjectDurations": [
                        {
                            "drawingSubject": "HOUSE",
                            "drawingDurationMs": 480000,
                            "activeDrawingMs": 160000,
                        },
                        {
                            "drawingSubject": "TREE",
                            "drawingDurationMs": 240000,
                            "activeDrawingMs": 90000,
                        },
                        {
                            "drawingSubject": "PERSON",
                            "drawingDurationMs": 180000,
                            "activeDrawingMs": 50000,
                        },
                    ],
                },
            }
        )

        self.assertEqual(90, req.behavior_metrics.stroke_count)
        self.assertEqual(3, req.behavior_metrics.colors_used_count)

        block = report_client._format_behavior(req.behavior_metrics, is_htp=True)
        self.assertIn("전체 획 수: 90획", block)
        self.assertIn("사용한 색: 3가지", block)
        self.assertIn("주제별 그리기 시간: 집 약 8분 · 나무 약 4분 · 사람 약 3분", block)

    def test_old_backend_without_the_new_fields_still_works(self):
        """롤아웃 안전 — 구 BE 가 안 보내면 새 줄만 빠지고 나머지는 그대로다(§2.5)."""
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "req-975",
                "analysisId": 1,
                "drawingSessionId": 2,
                "analysisType": "FINAL",
                "behaviorMetrics": {
                    "drawingDurationMs": 720000,
                    "pauseCount": 4,
                    "pressureAvailable": False,
                    "truncated": False,
                },
            }
        )

        self.assertIsNone(req.behavior_metrics.stroke_count)
        self.assertIsNone(req.behavior_metrics.colors_used_count)
        self.assertEqual([], req.behavior_metrics.subject_durations)

        block = report_client._format_behavior(req.behavior_metrics)
        self.assertIn("총 소요시간: 약 12분", block)
        self.assertNotIn("전체 획 수", block)
        self.assertNotIn("주제별 그리기 시간", block)


def _house_summary(**overrides) -> contracts.SubjectSummary:
    """집 그림 한 장의 주제 요약. detected_objects 를 overrides 로 갈아끼운다."""
    payload = {
        "drawingSubject": "HOUSE",
        "drawingDescription": "가운데에 집이 크게 그려져 있어요.",
        "detectedObjectCodes": ["HOUSE", "HOUSE_DOOR"],
        "detectedObjects": [
            {
                "objectCode": "HOUSE",
                "x": 0.21,
                "y": 0.18,
                "width": 0.55,
                "height": 0.60,
                "areaRatio": 0.33,
                "confidence": 0.94,
            },
            {
                "objectCode": "HOUSE_DOOR",
                "x": 0.42,
                "y": 0.70,
                "width": 0.09,
                "height": 0.16,
                "areaRatio": 0.014,
                "confidence": 0.81,
            },
        ],
    }
    payload.update(overrides)
    return contracts.SubjectSummary.model_validate(payload)


class GeometryBlockTest(unittest.TestCase):
    """[OO 크기·위치] 블록 생성 (S15P11B209-839).

    블록 생성만 검증하므로 LLM 호출 없이 _format_geometry 를 직접 부른다.
    """

    def test_area_and_position_are_rendered_as_facts(self):
        block = report_client._format_geometry(_house_summary(), "집 그림")

        self.assertIn("[집 그림 크기·위치]", block)
        self.assertIn("종이의 약 33%", block)
        self.assertIn("화면 한가운데", block)

    def test_part_ratio_is_relative_to_the_subject(self):
        """'집에 비해 문이 작다'를 수치로 남긴다 — 0.014 / 0.33 ≈ 4%."""
        block = report_client._format_geometry(_house_summary(), "집 그림")

        self.assertIn("집 전체의 약 4%", block)

    def test_missing_area_ratio_is_not_estimated(self):
        """areaRatio 가 없으면 점유율을 말하지 않는다 — width*height 로 보정 금지(BE 명시)."""
        summary = _house_summary(
            detectedObjects=[
                {
                    "objectCode": "HOUSE",
                    "x": 0.2,
                    "y": 0.2,
                    "width": 0.5,
                    "height": 0.5,
                    "areaRatio": None,
                    "confidence": 0.9,
                }
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertNotIn("종이의", block)
        self.assertNotIn("%", block)
        self.assertIn("화면", block)  # 위치는 좌표만으로 말할 수 있다

    # ── 기하 없는 탐지 (2026-08-05 운영 결함) ──
    def test_detection_without_geometry_is_skipped(self):
        """좌표가 없으면 그 항목을 블록에서 뺀다 — 없는 근거를 지어내지 않는다.

        BE 906 배포본이 {evidenceSourceId, objectCode} 만 보낸다. 코드 이름만으로 크기·위치
        블록에 줄을 세우면 '관찰된 수치'가 있는 것처럼 읽힌다.
        """
        summary = _house_summary(
            detectedObjects=[{"objectCode": "HOUSE_DOOR", "evidenceSourceId": 10}]
        )

        self.assertEqual("", report_client._format_geometry(summary, "집 그림"))

    def test_block_disappears_entirely_when_no_item_has_geometry(self):
        """빈 블록을 실으면 모델이 채우려 든다(_format_behavior 와 같은 원칙)."""
        summary = _house_summary(
            detectedObjects=[
                {"objectCode": "HOUSE", "evidenceSourceId": 1},
                {"objectCode": "HOUSE_DOOR", "evidenceSourceId": 2},
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertEqual("", block)
        self.assertNotIn("크기·위치", block)

    def test_items_with_geometry_survive_alongside_items_without(self):
        """섞여 와도 있는 것만 싣는다 — 하나가 비었다고 블록을 통째로 버리지 않는다."""
        summary = _house_summary(
            detectedObjects=[
                {"objectCode": "HOUSE_DOOR", "evidenceSourceId": 10},  # 기하 없음
                {
                    "objectCode": "HOUSE",
                    "x": 0.21,
                    "y": 0.18,
                    "width": 0.55,
                    "height": 0.60,
                    "areaRatio": 0.33,
                    "confidence": 0.94,
                },
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertIn("HOUSE:", block)
        self.assertIn("종이의 약 33%", block)
        self.assertNotIn("HOUSE_DOOR", block)

    def test_partial_box_is_not_completed_with_zeros(self):
        """네 값 중 하나라도 없으면 위치를 말하지 않는다 — 빠진 값을 0으로 치면 위치를 지어낸다."""
        summary = _house_summary(
            detectedObjects=[
                {
                    "objectCode": "HOUSE",
                    "x": 0.2,
                    "y": 0.2,
                    "width": 0.5,
                    "height": None,  # 하나만 비어도 위치는 계산할 수 없다
                    "areaRatio": 0.33,
                    "confidence": 0.9,
                }
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertIn("종이의 약 33%", block)  # 주어진 사실은 그대로 쓴다
        self.assertNotIn("화면", block)  # 위치는 지어내지 않는다

    def test_low_confidence_detection_is_dropped(self):
        """탐지 임계값(0.20)은 박스를 남길 기준이지 문장의 근거 기준이 아니다."""
        summary = _house_summary(
            detectedObjects=[
                {
                    "objectCode": "HOUSE_WINDOW",
                    "x": 0.3,
                    "y": 0.3,
                    "width": 0.1,
                    "height": 0.1,
                    "areaRatio": 0.01,
                    "confidence": 0.31,
                }
            ]
        )

        self.assertEqual("", report_client._format_geometry(summary, "집 그림"))

    def test_middle_confidence_detection_is_hedged(self):
        summary = _house_summary(
            detectedObjects=[
                {
                    "objectCode": "HOUSE_WINDOW",
                    "x": 0.3,
                    "y": 0.3,
                    "width": 0.1,
                    "height": 0.1,
                    "areaRatio": 0.01,
                    "confidence": 0.55,
                }
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertIn("확실하지 않아요", block)

    def test_high_confidence_detection_is_not_hedged(self):
        block = report_client._format_geometry(_house_summary(), "집 그림")

        self.assertNotIn("확실하지 않아요", block)

    def test_empty_detected_objects_produces_no_block(self):
        """구 BE·PIXEL 좌표뿐인 주제 — 기존 코드 목록 경로로 폴백한다."""
        summary = _house_summary(detectedObjects=[])

        self.assertEqual("", report_client._format_geometry(summary, "집 그림"))

    def test_diary_has_no_part_ratio(self):
        """그림일기는 주제 전체 객체가 없어 부위:주제 비율을 낼 수 없다."""
        summary = contracts.SubjectSummary.model_validate(
            {
                "drawingSubject": None,
                "detectedObjects": [
                    {
                        "objectCode": "SUN",
                        "x": 0.75,
                        "y": 0.05,
                        "width": 0.15,
                        "height": 0.15,
                        "areaRatio": 0.02,
                        "confidence": 0.88,
                    }
                ],
            }
        )

        block = report_client._format_geometry(summary, "그림")

        self.assertIn("종이의 약 2%", block)
        self.assertNotIn("전체의", block)  # 부위:주제 비율은 낼 수 없다
        self.assertIn("화면 위쪽 오른쪽", block)

    def test_tiny_object_avoids_zero_percent(self):
        """'약 0%'는 안 그린 것처럼 읽힌다."""
        summary = _house_summary(
            detectedObjects=[
                {
                    "objectCode": "HOUSE_CHIMNEY",
                    "x": 0.5,
                    "y": 0.1,
                    "width": 0.03,
                    "height": 0.03,
                    "areaRatio": 0.002,
                    "confidence": 0.9,
                }
            ]
        )

        block = report_client._format_geometry(summary, "집 그림")

        self.assertIn("1% 미만", block)
        self.assertNotIn("약 0%", block)

    def test_geometry_block_reaches_the_prompt(self):
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)
        req = _sample_request()
        req.subject_summaries = [_house_summary()]

        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(req, model="m")

        user_msg = captured["messages"][1]["content"]
        self.assertIn("[집 그림 크기·위치]", user_msg)
        self.assertIn("종이의 약 33%", user_msg)


class DetectedObjectContractTest(unittest.TestCase):
    """탐지 기하 필드가 계약으로 들어오는지 (S15P11B209-836).

    소비(용지 점유율·9분할 위치 서술)는 S15P11B209-839 범위 — 여기서는 계약만 고정한다.
    """

    def test_detected_objects_parse_alongside_codes(self):
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [
                    {
                        "drawingSubject": "HOUSE",
                        "detectedObjectCodes": ["HOUSE", "HOUSE_DOOR"],
                        "detectedObjects": [
                            {
                                "objectCode": "HOUSE",
                                "x": 0.21,
                                "y": 0.18,
                                "width": 0.55,
                                "height": 0.60,
                                "areaRatio": 0.33,
                                "confidence": 0.94,
                            },
                            {
                                "objectCode": "HOUSE_DOOR",
                                "x": 0.42,
                                "y": 0.55,
                                "width": 0.09,
                                "height": 0.16,
                                "areaRatio": None,
                                "confidence": 0.81,
                            },
                        ],
                    }
                ],
            }
        )

        summary = req.subject_summaries[0]
        # 기존 코드 목록은 유지된다 — 신구 필드가 병렬로 존재한다(하위호환).
        self.assertEqual(["HOUSE", "HOUSE_DOOR"], summary.detected_object_codes)
        self.assertEqual(0.33, summary.detected_objects[0].area_ratio)
        # areaRatio 가 없으면 None 그대로 — width*height 로 보정하지 않는다(BE 명시).
        self.assertIsNone(summary.detected_objects[1].area_ratio)

    # ── 운영 결함 회귀: 906 페이로드가 422로 100% 실패했다 (2026-08-05) ──
    def test_production_payload_without_geometry_is_accepted(self):
        """운영 재현 payload — 이게 422를 내던 그 모양이다.

        836이 x·y·width·height 를 **기본값 없는 필수 필드**로 둔 탓에, 906 배포본이
        {evidenceSourceId, objectCode} 만 실어 보내자 POST /internal/v1/observations 가
        운영에서 2건 중 2건 422로 실패했다(성공 0건). 탐지 객체가 하나라도 있으면 전량 실패라
        리포트 파이프라인이 통째로 멈췄다.

        구 오류 5건: x·y·width·height 각 "Field required" +
                     evidenceSourceId "Input should be a valid string"(BE는 Long 숫자로 보냄).

        이 계약의 롤아웃 원칙("구 BE가 안 보내면 기존 경로가 그대로 동작한다" — 740·836 주석)을
        836이 자기 모델에서만 어긴 것이 근인이다. 배포 순서에 무관해야 한다.
        """
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [
                    {
                        "drawingSubject": "HOUSE",
                        "drawingDescription": "집이 있어요.",
                        "detectedObjectCodes": ["HOUSE_DOOR"],
                        "detectedObjects": [
                            {"evidenceSourceId": 10, "objectCode": "HOUSE_DOOR"}
                        ],
                    }
                ],
            }
        )

        obj = req.subject_summaries[0].detected_objects[0]
        self.assertEqual("HOUSE_DOOR", obj.object_code)
        self.assertIsNone(obj.x)
        self.assertIsNone(obj.area_ratio)

    def test_numeric_evidence_source_id_is_normalized_to_string(self):
        """BE는 DB 행 ID(Long)를 숫자로 보낸다. 받아들이되 **문자열로** 보관한다.

        정규화가 검증 통과보다 중요하다 — _allowed_evidence_refs 가 (kind, id) 튜플로
        대조하는데 한쪽이 int 로 남으면 형식은 통과해도 대조에서 어긋나 그 근거가 조용히
        사라진다(422보다 알아채기 어려운 실패다).
        """
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [
                    {
                        "drawingSubject": "HOUSE",
                        "observationEvidenceSourceId": 77,
                        "detectedObjects": [
                            {"evidenceSourceId": 10, "objectCode": "HOUSE_DOOR"}
                        ],
                    }
                ],
                "selectedEmotionRefs": [{"emotionCode": "JOY", "evidenceSourceId": 42}],
                "activityMetricSourceId": "9",
            }
        )

        summary = req.subject_summaries[0]
        self.assertEqual("10", summary.detected_objects[0].evidence_source_id)
        self.assertEqual("77", summary.observation_evidence_source_id)
        self.assertEqual("42", req.selected_emotion_refs[0].evidence_source_id)
        # 근거 대조 집합에 문자열로 들어가야 LLM이 되돌려 준 id 와 맞는다.
        self.assertIn(
            ("DETECTED_OBJECT", "10"), report_client._allowed_evidence_refs(req)
        )
        self.assertIn(
            ("EMOTION_SELECTION", "42"), report_client._allowed_evidence_refs(req)
        )

    def test_string_evidence_source_id_still_works(self):
        """BE가 문자열로 보내던 경로도 그대로 — 정규화가 기존 동작을 바꾸지 않는다."""
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [
                    {
                        "drawingSubject": "HOUSE",
                        "detectedObjects": [
                            {
                                "objectCode": "HOUSE",
                                "x": 0.2,
                                "y": 0.2,
                                "width": 0.5,
                                "height": 0.5,
                                "areaRatio": 0.25,
                                "confidence": 0.9,
                                "evidenceSourceId": "abc-1",
                            }
                        ],
                    }
                ],
            }
        )

        self.assertEqual(
            "abc-1", req.subject_summaries[0].detected_objects[0].evidence_source_id
        )

    def test_geometry_still_parses_when_present(self):
        """기하가 실려 오는 경로는 그대로 동작한다(BE가 채우기 시작해도 회귀 없음)."""
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [
                    {
                        "drawingSubject": "HOUSE",
                        "detectedObjects": [
                            {
                                "objectCode": "HOUSE",
                                "x": 0.21,
                                "y": 0.18,
                                "width": 0.55,
                                "height": 0.60,
                                "areaRatio": 0.33,
                                "confidence": 0.94,
                                "evidenceSourceId": 5,
                            }
                        ],
                    }
                ],
            }
        )

        summary = req.subject_summaries[0]
        block = report_client._format_geometry(summary, "집 그림")
        self.assertIn("종이의 약 33%", block)
        self.assertIn("화면 한가운데", block)

    def test_missing_detected_objects_defaults_to_empty(self):
        """구 BE(그리고 PIXEL 결과만 있는 주제)는 빈 목록으로 들어온다."""
        req = contracts.ObservationGenerationRequest.model_validate(
            {
                "requestId": "r-1",
                "analysisId": 1,
                "drawingSessionId": 1,
                "analysisType": "FINAL",
                "subjectSummaries": [{"drawingSubject": "TREE"}],
            }
        )

        self.assertEqual([], req.subject_summaries[0].detected_objects)

    def test_without_description_prompts_placeholder(self):
        captured = {}

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(_sample_request(), model="m")

        user_msg = captured["messages"][1]["content"]
        self.assertIn("그림 관찰 서술이 제공되지 않았어요", user_msg)

    def test_invalid_visibility_scope_coerced_to_expert_only(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(
            _llm_json(
                features=[
                    {
                        "featureCode": "X",
                        "title": "t",
                        "description": "d",
                        "evidenceSummary": "e",
                        "visibilityScope": "PUBLIC",  # 계약에 없는 값
                    }
                ]
            )
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="m")
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "EXPERT_ONLY"
        )

    def test_openai_error_maps_to_runtime_error(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = OpenAIError("boom")
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            with self.assertRaises(RuntimeError):
                report_client.generate(_sample_request(), model="m")


class DefinitiveDiagnosisQuarantineTest(unittest.TestCase):
    """단정적 진단 표현 격리 — 자체검토 실패 + EXPERT_ONLY 강등 (S15P11B209-591).

    ⚠️ 2026-08-05에 담는 곳이 바뀌었다. 구 구현은 규칙 적중을 expertReviewRequired 로 올렸는데,
    그건 '사람 상담을 권할 신호'(아이 이야기)라 '리포트에 진단어가 섞였다'(품질 실패)와 뜻이 다르다.
    이제 품질 실패는 status 로 간다 — 격리가 약해진 게 아니라 강해졌다:
    구 불리언은 BE Report.expertReviewRecommended 컬럼에만 저장되고 읽는 곳이 없었던 반면,
    status 는 BE가 관찰 카드를 보호자에게 열지 정하는 데 실제로 쓴다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_sample_request(), model="m")

    def test_guardian_feature_with_diagnosis_downgraded_to_expert_only(self):
        result = self._generate(
            features=[
                {
                    "featureCode": "X",
                    "title": "정서 관찰",
                    "description": "이 아이는 불안장애로 진단됩니다.",  # 단정
                    "evidenceSummary": "e",
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ]
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "EXPERT_ONLY"
        )
        # 보호자 노출 내용에 단정 진단이 있으면 자체검토를 통과시키지 않는다.
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)

    def test_hedged_concern_feature_stays_guardian_visible(self):
        result = self._generate(
            expertReviewRequired=False,
            features=[
                {
                    "featureCode": "X",
                    "title": "정서 관찰",
                    "description": "속상한 마음이 담긴 듯 보일 수 있어요.",  # 여지
                    "evidenceSummary": "e",
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ],
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )
        self.assertFalse(result.observation_draft.expert_review_required)

    def test_diagnosis_in_overall_summary_fails_self_review(self):
        result = self._generate(
            expertReviewRequired=False,
            overallSummary="이 아이는 우울증이 있어 보입니다.",  # 장애명 단정
        )
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)
        # 품질 실패를 '사람 상담 권유'로 둔갑시키지 않는다 — 축이 다르다.
        self.assertFalse(result.observation_draft.expert_review_required)


class OverinferenceQuarantineTest(unittest.TestCase):
    """감정·성격 과잉 추론 격리 — 전문가 검토 + EXPERT_ONLY 강등 (S15P11B209-592)."""

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_sample_request(), model="m")

    def test_guardian_feature_with_trait_labeling_downgraded_to_expert_only(self):
        result = self._generate(
            features=[
                {
                    "featureCode": "X",
                    "title": "성격 관찰",
                    "description": "공격적인 성향이 있어요.",  # 고정 특질 규정
                    "evidenceSummary": "e",
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ]
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "EXPERT_ONLY"
        )
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)

    def test_overinference_in_overall_summary_fails_self_review(self):
        result = self._generate(
            expertReviewRequired=False,
            overallSummary="정서적으로 불안한 아이입니다.",  # 정체성 규정
        )
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)
        self.assertFalse(result.observation_draft.expert_review_required)

    def test_behavioral_observation_stays_guardian_visible(self):
        result = self._generate(
            expertReviewRequired=False,
            features=[
                {
                    "featureCode": "X",
                    "title": "활동 관찰",
                    "description": "조심스러운 모습을 보였어요.",  # 행동 관찰
                    "evidenceSummary": "e",
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ],
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )
        self.assertFalse(result.observation_draft.expert_review_required)


class UngroundedInterpretationTest(unittest.TestCase):
    """관찰 사실 ↔ AI 해석 분리 — 근거 없는 해석은 보호자 노출 불가 (S15P11B209-600)."""

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_sample_request(), model="m")

    def test_interpretation_without_evidence_downgraded_to_expert_only(self):
        # description(해석)은 있는데 evidenceSummary(근거)가 비면 억측 → 격리.
        result = self._generate(
            features=[
                {
                    "featureCode": "X",
                    "title": "정서 관찰",
                    "description": "마음이 편안해 보여요.",  # 해석
                    "evidenceSummary": "   ",  # 근거 없음(공백)
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ]
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "EXPERT_ONLY"
        )

    def test_interpretation_with_evidence_stays_guardian_visible(self):
        # 근거가 있으면 그대로 보호자에게 보인다(정상 경로).
        result = self._generate(
            features=[
                {
                    "featureCode": "X",
                    "title": "정서 관찰",
                    "description": "즐겁게 그린 것으로 보여요.",  # 해석
                    "evidenceSummary": "밝은 색을 많이 썼고 지우기가 적었어요.",  # 관찰 사실 근거
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ]
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )


class VersionRecordingTest(unittest.TestCase):
    """리포트 model·prompt·pipelineVersion 저장 (S15P11B209-602)."""

    def test_model_version_carries_prompt_and_pipeline(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(_llm_json())
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="m")
        # 재현성 3종: model_name(모델) + model_version(프롬프트·파이프라인)
        self.assertIn(f"pipeline={report_client.config.PIPELINE_VERSION}", result.model_version)
        self.assertIn("prompt=", result.model_version)
        # '이번에 쓴' 조합만 실린다 — 두 변형을 다 적으면 어느 쪽으로 뽑혔는지 구분이 안 된다.
        # 조합은 축약 태그로 실리고(819) 변형은 라벨로 구분된다.
        self.assertIn(report_client._generation_version(False), result.model_version)
        self.assertIn("prompt=diary@", result.model_version)
        self.assertNotIn("htp@", result.model_version)

    def test_htp_request_records_htp_prompt_version(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(_llm_json())
        with mock.patch.object(
            report_client, "retrieve", return_value=[]
        ), mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_htp_request(), model="m")
        self.assertIn("prompt=htp@", result.model_version)
        self.assertNotIn("diary@", result.model_version)

    def test_model_version_fits_backend_column(self):
        """BE generated_model_version·summary_model_version 컬럼 한계 (S15P11B209-819).

        786에서 리포트 프롬프트가 갈리며 76자가 돼 컬럼(VARCHAR(50))을 넘겼고, 저장 실패가
        리포트 전량 실패로 번졌다(815). 생성 경로에서 직접 한 번 더 못박는다.
        """
        for is_htp in (True, False):
            value = report_client._generation_version(is_htp)
            self.assertLessEqual(
                len(value), prompts_registry.MAX_VERSION_TAG, f"{len(value)}자: {value}"
            )

    def test_model_name_records_actual_served_model(self):
        # GMS가 실제 서빙한 모델 ID를 기록한다(요청 모델명이 아니라).
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(
            _llm_json(), model="gpt-4o-mini-2024-07-18"
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="gpt-4o-mini")
        self.assertEqual(result.model_name, "gpt-4o-mini-2024-07-18")

    def test_model_name_falls_back_to_requested_when_unknown(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(_llm_json())
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="req-model")
        self.assertEqual(result.model_name, "req-model")


class FollowUpAndDisclaimerTest(unittest.TestCase):
    """진단 표현 제거·한계 고지·후속 질문 생성 보장 (S15P11B209-601)."""

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_sample_request(), model="m")

    def test_empty_follow_up_is_filled_with_safe_default(self):
        result = self._generate(followUpQuestion="   ")
        self.assertEqual(
            result.observation_draft.follow_up_question,
            report_client.DEFAULT_FOLLOW_UP_QUESTION,
        )

    def test_diagnostic_follow_up_is_replaced_with_safe_default(self):
        # 후속 질문에 진단성 표현이 섞이면 보호자에게 그대로 내보내지 않고 안전 기본값으로 대체.
        result = self._generate(followUpQuestion="아이가 우울증이 있는지 물어보세요.")
        self.assertEqual(
            result.observation_draft.follow_up_question,
            report_client.DEFAULT_FOLLOW_UP_QUESTION,
        )

    def test_normal_follow_up_is_kept(self):
        result = self._generate(followUpQuestion="이 집에는 누가 살아?")
        self.assertEqual(
            result.observation_draft.follow_up_question, "이 집에는 누가 살아?"
        )

    def test_object_follow_up_extracts_question_text(self):
        # 모델이 스키마를 벗어나 객체로 줘도 questionText만 싣는다(dict가 통째로 문자열화되면 안 됨).
        result = self._generate(
            followUpQuestion={
                "questionText": "그림 속 집은 어떤 곳이야?",
                "questionPurpose": "상상력 자극",
            }
        )
        self.assertEqual(
            result.observation_draft.follow_up_question, "그림 속 집은 어떤 곳이야?"
        )
        self.assertNotIn("questionPurpose", result.observation_draft.follow_up_question)

    def test_object_follow_up_without_question_text_falls_back(self):
        result = self._generate(followUpQuestion={"questionPurpose": "목적만 있음"})
        self.assertEqual(
            result.observation_draft.follow_up_question,
            report_client.DEFAULT_FOLLOW_UP_QUESTION,
        )

    def test_disclaimer_and_limitations_always_present(self):
        # 한계 고지·면책 문구는 LLM이 무엇을 주든 서버가 상수로 항상 보장한다.
        result = self._generate(overallSummary="")
        self.assertEqual(result.observation_draft.disclaimer, report_client.DISCLAIMER)
        self.assertEqual(result.limitations_text, report_client.LIMITATIONS)
        self.assertTrue(result.observation_draft.disclaimer.strip())
        self.assertTrue(result.limitations_text.strip())


class EmotionSourceTest(unittest.TestCase):
    def test_selected(self):
        req = _sample_request(selected_emotions=["JOY"], expressed_emotion_text=None)
        self.assertEqual(report_client._emotion_source(req), "SELECTED")

    def test_stated(self):
        req = _sample_request(selected_emotions=[], expressed_emotion_text="무서웠어")
        self.assertEqual(report_client._emotion_source(req), "STATED")

    def test_inferred(self):
        req = _sample_request(selected_emotions=[], expressed_emotion_text=None)
        self.assertEqual(report_client._emotion_source(req), "INFERRED")


class ExtractJsonTest(unittest.TestCase):
    def test_strips_code_fence(self):
        raw = "```json\n{\"a\": 1}\n```"
        self.assertEqual(report_client._extract_json(raw), {"a": 1})

    def test_ignores_surrounding_prose(self):
        raw = "결과입니다: {\"a\": 2} 이상입니다."
        self.assertEqual(report_client._extract_json(raw), {"a": 2})

    def test_no_json_raises_runtime_error(self):
        with self.assertRaises(RuntimeError):
            report_client._extract_json("여기엔 JSON이 없어요")


class SubjectSummariesTest(unittest.TestCase):
    """주제별 그림 서술·문답 프롬프트 반영 (S15P11B209-740).

    HTP 3주제가 각각 [OO 그림 관찰]·[OO 그림 문답] 블록으로 실리고, 없으면 기존
    단일 [그림 관찰 서술] 경로가 그대로인지(롤아웃 호환) 검증한다.
    """

    def _capture_user_msg(self, req, **generate_kwargs) -> str:
        captured = {}

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(req, model="m", **generate_kwargs)
        return captured["messages"][1]["content"]

    @staticmethod
    def _htp_summaries() -> list[contracts.SubjectSummary]:
        return [
            contracts.SubjectSummary(
                drawing_subject="HOUSE",
                drawing_description="가운데에 집이 크게 그려져 있어요.",
                detected_object_codes=["HOUSE", "HOUSE_DOOR"],
                qa_pairs=[
                    contracts.SubjectQaPair(
                        question="이 집에는 누가 살아?",
                        answer_text="엄마랑 나!",
                        answer_type="VOICE",
                    ),
                    contracts.SubjectQaPair(
                        question="집 앞에는 뭐가 있어?",
                        answer_text=None,
                        answer_type=None,  # SKIPPED 아님 — 단순 무응답
                    ),
                ],
            ),
            contracts.SubjectSummary(
                drawing_subject="TREE",
                drawing_description="나무에 열매가 세 개 달려 있어요.",
                qa_pairs=[
                    contracts.SubjectQaPair(
                        question="이 나무는 어디에 있어?",
                        answer_text=None,
                        answer_type="SKIPPED",
                    )
                ],
            ),
            contracts.SubjectSummary(
                drawing_subject="PERSON",
                drawing_description="사람 두 명이 손을 잡고 있어요.",
            ),
        ]

    def test_subject_blocks_rendered_per_subject(self):
        req = _sample_request(subject_summaries=self._htp_summaries())
        user_msg = self._capture_user_msg(req)

        for label in ("[집 그림 관찰]", "[나무 그림 관찰]", "[사람 그림 관찰]"):
            self.assertIn(label, user_msg)
        self.assertIn("[집 그림 문답]", user_msg)
        self.assertIn("이 집에는 누가 살아?", user_msg)
        self.assertIn("엄마랑 나!", user_msg)
        self.assertIn("HOUSE_DOOR", user_msg)  # 참고용 요소 코드
        # 주제별 블록이 실리면 레거시 단일 블록은 없다.
        self.assertNotIn("[그림 관찰 서술]", user_msg)
        # 문답 없는 주제(사람)는 문답 블록도 없다.
        self.assertNotIn("[사람 그림 문답]", user_msg)

    def test_subject_blocks_take_priority_over_legacy_description(self):
        req = _sample_request(subject_summaries=self._htp_summaries())
        user_msg = self._capture_user_msg(
            req, drawing_description="레거시 단일 서술입니다."
        )
        self.assertNotIn("레거시 단일 서술입니다.", user_msg)
        self.assertIn("[집 그림 관찰]", user_msg)

    def test_art_diary_none_subject_uses_generic_label(self):
        req = _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject=None,
                    drawing_description="공룡이 풍선을 들고 있어요.",
                    qa_pairs=[
                        contracts.SubjectQaPair(question="공룡은 기분이 어때?")
                    ],
                )
            ]
        )
        user_msg = self._capture_user_msg(req)
        self.assertIn("[그림 관찰]", user_msg)
        self.assertIn("[그림 문답]", user_msg)
        # '그림 그림' 같은 라벨 중복이 없어야 한다.
        self.assertNotIn("그림 그림", user_msg)

    def test_skipped_question_rendered_distinctly_from_unanswered(self):
        req = _sample_request(subject_summaries=self._htp_summaries())
        user_msg = self._capture_user_msg(req)
        # SKIPPED(나무 문답)는 '건너뜀'으로, 타입 없는 무응답(집 두 번째 문답)은 별도 표기.
        self.assertIn("(건너뛴 질문)", user_msg)
        self.assertIn("(답하지 않았어요)", user_msg)

    def test_empty_subject_summaries_keeps_legacy_block(self):
        req = _sample_request(subject_summaries=[])
        user_msg = self._capture_user_msg(
            req, drawing_description="가운데에 집이 크게."
        )
        self.assertIn("[그림 관찰 서술]", user_msg)
        self.assertIn("가운데에 집이 크게.", user_msg)

    def test_answer_text_hidden_from_repr(self):
        qa = contracts.SubjectQaPair(question="누가 살아?", answer_text="비밀 발화")
        self.assertNotIn("비밀 발화", repr(qa))
        req = _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(drawing_subject="HOUSE", qa_pairs=[qa])
            ]
        )
        self.assertNotIn("비밀 발화", repr(req))

    def test_camelcase_json_parses_like_be_payload(self):
        # BE(Jackson)가 보내는 camelCase JSON이 그대로 파싱되는지 — 계약 왕복 검증.
        payload = {
            "requestId": "req-9",
            "analysisId": 1,
            "drawingSessionId": 2,
            "analysisType": "FINAL",
            "subjectSummaries": [
                {
                    "drawingSubject": "TREE",
                    "drawingDescription": "나무 한 그루",
                    "detectedObjectCodes": ["TREE"],
                    "qaPairs": [
                        {
                            "question": "무슨 나무야?",
                            "answerText": "사과나무",
                            "answerType": "OPTION",
                        }
                    ],
                }
            ],
        }
        req = contracts.ObservationGenerationRequest.model_validate(payload)
        self.assertEqual(len(req.subject_summaries), 1)
        self.assertEqual(req.subject_summaries[0].drawing_subject, "TREE")
        self.assertEqual(req.subject_summaries[0].qa_pairs[0].answer_text, "사과나무")

    def test_old_be_payload_without_subject_summaries_still_parses(self):
        # 롤아웃 호환: 구 BE 요청(필드 부재)이 깨지지 않는다.
        payload = {
            "requestId": "req-8",
            "analysisId": 1,
            "drawingSessionId": 2,
            "analysisType": "FINAL",
        }
        req = contracts.ObservationGenerationRequest.model_validate(payload)
        self.assertEqual(req.subject_summaries, [])


class RagInjectionTest(unittest.TestCase):
    """RAG 근거 주입·출처 반환 (S15P11B209-614) — retrieve는 mock, GMS 미의존."""

    def _generate(self, req, *, chunks=None, unavailable=False, **kwargs):
        captured = {}

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)

        if unavailable:
            retrieve_patch = mock.patch.object(
                report_client,
                "retrieve",
                side_effect=report_client.RagUnavailableError("인덱스 없음"),
            )
        else:
            retrieve_patch = mock.patch.object(
                report_client, "retrieve", return_value=chunks or []
            )
        kb_patch = mock.patch.object(
            report_client, "rag_knowledge_base_version", return_value="kb-2026.07-1"
        )
        with retrieve_patch, kb_patch, mock.patch.object(
            report_client, "get_client", return_value=fake_client
        ):
            result = report_client.generate(req, model="m", **kwargs)
        return result, captured["messages"][1]["content"]

    @staticmethod
    def _chunks():
        from rag import Chunk

        return [
            Chunk(
                chunk_id="kicce-mr2303#0",
                source_id="kicce-mr2303",
                title="아동 사회·정서 발달지원",
                text="이 연령대 아이들은 그림으로 감정을 표현하는 것이 자연스럽습니다.",
                score=0.8,
            ),
            Chunk(
                chunk_id="kicce-mr2303#4",
                source_id="kicce-mr2303",  # 같은 자료의 다른 청크 — 출처는 1건으로 dedupe
                title="아동 사회·정서 발달지원",
                text="놀이와 그리기는 정서 표현의 통로입니다.",
                score=0.7,
            ),
        ]

    def test_chunks_injected_into_prompt_and_sources_returned(self):
        # 관찰 재료(서술)가 있어야 검색이 성립한다 — _build_rag_query 규칙과 정합.
        result, user_msg = self._generate(
            _htp_request(),
            chunks=self._chunks(),
            drawing_description="집이 크게 그려져 있어요.",
        )
        self.assertIn("[전문 자료 근거]", user_msg)
        self.assertIn("감정을 표현하는 것이 자연스럽습니다", user_msg)
        # 출처는 자료 단위 dedupe — 청크 2개, 참조 1건.
        self.assertEqual(len(result.rag_references), 1)
        self.assertEqual(result.rag_references[0].source_id, "kicce-mr2303")
        self.assertEqual(result.knowledge_base_version, "kb-2026.07-1")

    def test_unavailable_rag_degrades_not_blocks(self):
        # 인덱스 미배포·임베딩 실패 → 리포트는 그대로 생성, RAG 필드는 비움(기존 응답과 동일).
        result, user_msg = self._generate(_htp_request(), unavailable=True)
        self.assertNotIn("[전문 자료 근거]", user_msg)
        self.assertEqual(result.rag_references, [])
        self.assertIsNone(result.knowledge_base_version)
        self.assertIn("즐겁게", result.observation_draft.overall_summary)

    def test_empty_chunks_omit_block_and_kb_version(self):
        # 검색은 됐지만 임계값 미달(빈 목록) — 근거를 안 썼으므로 KB Version도 싣지 않는다.
        result, user_msg = self._generate(_htp_request(), chunks=[])
        self.assertNotIn("[전문 자료 근거]", user_msg)
        self.assertIsNone(result.knowledge_base_version)

    def test_query_excludes_child_utterances(self):
        # 질의는 관찰 서술·객체·선택 감정로만 — 아이 발화(답변·대표 발화)는 GMS로 안 나간다(정책 §1-1).
        req = _sample_request(
            representative_utterance="우리 엄마가 만든 김밥이 최고야",
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject="HOUSE",
                    drawing_description="집이 크게 그려져 있어요.",
                    detected_object_codes=["HOUSE"],
                    qa_pairs=[
                        contracts.SubjectQaPair(
                            question="누구랑 살아?", answer_text="비밀 발화 내용"
                        )
                    ],
                )
            ],
        )
        query = report_client._build_rag_query(req, None)
        self.assertIn("집이 크게 그려져 있어요.", query)
        self.assertIn("HOUSE", query)
        self.assertNotIn("비밀 발화 내용", query)
        self.assertNotIn("김밥", query)

    def test_no_query_material_skips_search(self):
        # 서술·객체·감정이 전부 없으면 임베딩 호출 자체를 하지 않는다.
        req = _sample_request(selected_emotions=[], subject_summaries=[])
        with mock.patch.object(report_client, "retrieve") as retrieve_spy:
            chunks, reason = report_client._search_rag(req, None)
        self.assertEqual(chunks, [])
        self.assertEqual(reason, "RAG_NO_QUERY")
        retrieve_spy.assert_not_called()


class RagSkippedReasonTest(unittest.TestCase):
    """근거를 싣지 못한 사유 코드 (S15P11B209-615) — 실패 종류별 표기와 응답 반영."""

    def _req_with_material(self):
        return _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject="HOUSE", drawing_description="집이 크게."
                )
            ]
        )

    def test_no_index_maps_to_rag_no_index(self):
        from rag import RagUnavailableError

        with mock.patch.object(
            report_client,
            "retrieve",
            side_effect=RagUnavailableError("미배포", reason="NO_INDEX"),
        ):
            chunks, reason = report_client._search_rag(self._req_with_material(), None)
        self.assertEqual((chunks, reason), ([], "RAG_NO_INDEX"))

    def test_search_failure_maps_to_rag_unavailable(self):
        from rag import RagUnavailableError

        with mock.patch.object(
            report_client,
            "retrieve",
            side_effect=RagUnavailableError("GMS 실패", reason="SEARCH_FAILED"),
        ):
            chunks, reason = report_client._search_rag(self._req_with_material(), None)
        self.assertEqual((chunks, reason), ([], "RAG_UNAVAILABLE"))

    def test_empty_results_map_to_low_score(self):
        with mock.patch.object(report_client, "retrieve", return_value=[]):
            chunks, reason = report_client._search_rag(self._req_with_material(), None)
        self.assertEqual((chunks, reason), ([], "RAG_LOW_SCORE"))

    def test_success_has_no_reason(self):
        from rag import Chunk

        chunk = Chunk(
            chunk_id="s#0", source_id="s", title="제목", text="본문", score=0.9
        )
        with mock.patch.object(report_client, "retrieve", return_value=[chunk]):
            chunks, reason = report_client._search_rag(self._req_with_material(), None)
        self.assertEqual(len(chunks), 1)
        self.assertIsNone(reason)

    def test_reason_lands_in_response(self):
        # 사유가 응답(ragSkippedReason)까지 흐르는지 — 미배포 시나리오로 종단 확인.
        from rag import RagUnavailableError

        fake_client = _fake_client()
        with mock.patch.object(
            report_client,
            "retrieve",
            side_effect=RagUnavailableError("미배포", reason="NO_INDEX"),
        ), mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(self._req_with_material(), model="m")
        self.assertEqual(result.rag_skipped_reason, "RAG_NO_INDEX")
        self.assertEqual(result.rag_references, [])
        self.assertIsNone(result.knowledge_base_version)

    def test_success_response_has_null_reason(self):
        from rag import Chunk

        chunk = Chunk(
            chunk_id="s#0", source_id="s", title="제목", text="본문", score=0.9
        )

        fake_client = _fake_client()
        with mock.patch.object(
            report_client, "retrieve", return_value=[chunk]
        ), mock.patch.object(
            report_client, "rag_knowledge_base_version", return_value="kb-2026.07-1"
        ), mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(self._req_with_material(), model="m")
        self.assertIsNone(result.rag_skipped_reason)
        self.assertEqual(len(result.rag_references), 1)


class ActivityPromptSplitTest(unittest.TestCase):
    """리포트 프롬프트 HTP/그림일기 분리 — 근거 화이트리스트·RAG 적용 범위."""

    def _generate(self, req):
        """generate()를 돌리고 (결과, system 프롬프트, retrieve 스파이)를 돌려준다.

        ⚠️ generate()는 생성 다음에 자체검토를 한 번 더 부른다 — call_args(마지막 호출)를 보면
        검토 프롬프트가 잡힌다. 첫 호출만 기록하는 헬퍼로 생성 프롬프트를 잡는다.
        """
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)
        with mock.patch.object(
            report_client, "retrieve", return_value=[]
        ) as retrieve_spy, mock.patch.object(
            report_client, "get_client", return_value=fake_client
        ):
            result = report_client.generate(req, model="m")
        return result, captured["messages"][0]["content"], retrieve_spy

    def test_htp_request_selects_htp_prompt(self):
        _, system, _ = self._generate(_htp_request())
        self.assertIn("HTP(집·나무·사람)", system)
        self.assertNotIn("그림일기", system)

    def test_diary_request_selects_diary_prompt(self):
        # drawingSubject가 없는 subject_summaries = 그림일기 1건.
        req = _sample_request(
            subject_summaries=[
                contracts.SubjectSummary(drawing_description="하늘을 파랗게 칠했어요.")
            ]
        )
        _, system, _ = self._generate(req)
        self.assertIn("그림일기", system)
        self.assertNotIn("HTP(집·나무·사람)", system)

    def test_both_activity_prompts_declare_the_same_output_schema(self):
        """두 자기완결 파일의 출력 JSON 스키마 키가 같아야 한다 (S15P11B209-993).

        공용 report_common을 활동별로 흡수하면서(사용자 결정 2026-08-07) 스키마가 두 벌이
        됐다. 두 파일 모두 같은 BE 계약(ObservationGenerationResult)으로 파싱되므로,
        한쪽 스키마만 고치면 다른 활동의 리포트가 조용히 계약과 어긋난다 —
        키 집합 일치를 못 박아 드리프트를 배포 전에 잡는다.
        (예시 값·설명 문구는 활동별로 달라도 된다. 지키는 것은 키다.)
        """
        import json as jsonlib

        def schema_keys(name: str) -> dict:
            text = prompts_registry.load(name)
            start = text.index('{\n  "overallSummary"')
            schema = jsonlib.loads(text[start:])
            nested = {
                key: sorted(schema[key][0]) if isinstance(schema[key], list)
                and schema[key] and isinstance(schema[key][0], dict) else None
                for key in schema
            }
            return {"top": sorted(schema), "nested": nested}

        htp, diary = schema_keys("report_htp"), schema_keys("report_diary")
        self.assertEqual(htp["top"], diary["top"])
        self.assertEqual(htp["nested"], diary["nested"])

    def test_legacy_request_without_summaries_uses_diary_prompt(self):
        # 구 BE(subject_summaries 미전달)도 '단일 그림 + RAG 없음' 경로라 그림일기 쪽이 맞다.
        _, system, _ = self._generate(_sample_request())
        self.assertIn("그림일기", system)

    def test_both_variants_carry_common_rules_and_schema(self):
        for req in (_htp_request(), _sample_request()):
            _, system, _ = self._generate(req)
            # 공통부(report_common)가 뒤에 이어붙는다 — 사실/해석 분리와 출력 스키마.
            self.assertIn("관찰 '사실'과 AI '해석'을 분리한다", system)
            self.assertIn('"overallSummary"', system)
            self.assertIn('"visibilityScope"', system)
            # 출력 형식이 프롬프트 맨 끝에 오는지(모델이 형식을 놓치지 않게).
            self.assertGreater(system.index("출력 형식:"), system.index("근거 범위"))

    def test_whitelist_names_every_block_that_is_actually_injected(self):
        """근거 화이트리스트 누락 회귀 — 구 report.txt가 주제별 블록·RAG를 빠뜨렸다.

        '~만 근거로 삼는다'는 화이트리스트라, 실제 주입되는 블록이 목록에 없으면
        모델이 그 블록을 버린다(RAG 무력화·HTP 그림 내용 누락).
        """
        _, htp_system, _ = self._generate(_htp_request())
        for block in ("[집 그림 관찰]", "[형식적 분석]", "[전문 자료 근거]", "[활동 데이터]"):
            self.assertIn(block, htp_system)

        _, diary_system, _ = self._generate(_sample_request())
        for block in ("[그림 관찰]", "[형식적 분석]", "[활동 데이터]"):
            self.assertIn(block, diary_system)
        # 그림일기 프롬프트는 RAG 블록을 근거로 두지 않는다(검색도 하지 않으므로).
        self.assertNotIn("[전문 자료 근거]", diary_system)

    def test_diary_skips_rag_search_entirely(self):
        result, _, retrieve_spy = self._generate(_sample_request())
        retrieve_spy.assert_not_called()
        self.assertEqual(result.rag_skipped_reason, report_client.RAG_NOT_APPLICABLE)
        self.assertEqual(result.rag_references, [])
        self.assertIsNone(result.knowledge_base_version)

    def test_htp_still_searches_rag(self):
        _, _, retrieve_spy = self._generate(_htp_request())
        retrieve_spy.assert_called_once()


class ReportCommonContradictionTest(unittest.TestCase):
    """report_common.txt 안에서 같은 내용에 두 지시가 갈리지 않는지 (S15P11B209-788 E·F).

    프롬프트 '문구'를 직접 본다 — 여기서 고친 것은 모델에게 주는 지시의 일관성이고,
    조립·호출 경로는 ActivityPromptSplitTest가 이미 덮는다.
    """

    def setUp(self):
        import prompts_registry

        self.text = prompts_registry.load("report_htp")

    # ── E: 걱정 신호 배출구 ──
    def test_two_concern_outlets_are_defined_with_distinct_roles(self):
        """배출구는 여전히 둘이지만 2026-08-05에 독자가 갈렸다.

        EXPERT_ONLY 관찰 카드 = 보호자에게 열지 않고 사람 상담·안전 경로로만.
        attentionPoints = 보호자가 다음에 더 지켜볼 점(구: 전문가가 추가 확인할 것).
        """
        self.assertIn("걱정 신호를 담는 자리 두 곳", self.text)
        self.assertIn("같은 내용을 양쪽에 중복해 적지 마", self.text)
        self.assertIn("관찰 카드", self.text)
        self.assertIn("다음에 무엇을 더 지켜보면 좋을지", self.text)
        # 존재하지 않는 '전문가 독자'를 다시 들이지 않는다.
        self.assertNotIn("전문가 채널 두 곳", self.text)
        self.assertNotIn("전문가 검토용으로만 저장", self.text)

    def test_attention_points_is_no_longer_the_only_outlet(self):
        """구 문구는 걱정 신호를 attentionPoints '로만' 옮기라고 해서, 코드가 전제하는
        EXPERT_ONLY feature 경로(report_client._feature 강등 로직)와 어긋났다."""
        self.assertNotIn("attentionPoints(전문가용)로만 옮긴다", self.text)
        self.assertNotIn("관찰된 사실만 attentionPoints(전문가용)로 옮긴다", self.text)

    def test_expert_only_channel_matches_code_behaviour(self):
        # 코드가 실제로 EXPERT_ONLY feature 경로를 갖고 있다(프롬프트가 그걸 부정하면 안 된다).
        self.assertIn("EXPERT_ONLY", report_client._VALID_SCOPES)
        self.assertIn('features 의 EXPERT_ONLY 항목', self.text)

    def test_attention_points_is_not_a_summary_of_cards(self):
        self.assertIn("EXPERT_ONLY 관찰 카드를 다시 요약하지 마", self.text)

    # ── F: 형식적 분석 수치의 자리 ──
    def test_metric_facts_and_emotion_link_have_separate_homes(self):
        """구 문구는 수치를 evidenceSummary에 넣고 거기서 감정과 '연결'하라고 했는데,
        같은 파일의 사실/해석 분리 원칙은 evidenceSummary에 감정 판단을 금지한다."""
        self.assertIn("수치와 감정을 잇는 문장은 '해석'이라 자리가 다르다", self.text)
        self.assertIn("evidenceSummary 에는 수치만 남기고", self.text)
        # 사실/해석 분리 원칙은 그대로 살아 있어야 한다.
        self.assertIn("감정 판단·심리 해석(\"안정감을 느낀다\" 등)을 절대 넣지 마", self.text)

    def test_metric_link_instruction_appears_before_fact_split_principle(self):
        # 앞에 오는 지시가 뒤의 원칙과 어긋나면 모델이 어느 쪽을 따를지 알 수 없다 —
        # 이제 앞쪽이 뒤쪽 원칙을 가리킨다.
        self.assertIn("아래 사실/해석 분리 원칙", self.text)
        self.assertLess(
            self.text.index("아래 사실/해석 분리 원칙"),
            self.text.index("관찰 '사실'과 AI '해석'을 분리한다"),
        )

    def test_emotion_inference_requires_multiple_aligned_signals(self):
        """그림·필압 기반 추론은 허용하되, 단일 신호 억측과 성격 일반화는 막는다."""
        self.assertIn("단일 신호만으로 감정을 추론하지 마", self.text)
        self.assertIn("독립적인 관찰 신호가 두 가지 이상", self.text)
        self.assertIn("신호가 엇갈리거나 근거가 약하면 감정을 추론하지 않는다", self.text)
        self.assertIn("이번 활동에서는", self.text)
        self.assertIn("평소 마음·성격·발달 상태로 넓히지 않는다", self.text)


class ReportContractAlignmentTest(unittest.TestCase):
    """프롬프트가 BE 수신·화면 도달 실태와 맞는지 (S15P11B209-826).

    구 문구는 "각 필드가 화면에서 쓰이는 자리"로 7항목을 열거했는데 4.5개가 거짓이었다.
    모델이 그 맥락을 믿고 화면에 안 나가는 필드에 공을 들이고, 정작 보호자 조언 영역
    전부인 followUpGuides는 강조 없이 스키마 맨 끝에 있었다(818 근인 후보).
    """

    def setUp(self):
        self.text = prompts_registry.load("report_htp")

    # ── 3. 렌더링 설명이 사실과 맞는가 ──
    def test_guardian_facing_fields_are_named_exactly(self):
        """보호자 화면에 실제로 도달하는 셋만 [1]로 분류돼야 한다.

        경로: ReportDetailQueryService → ReportDetailResponse → report_screen.dart.
        그 서비스에는 observedFeature·guardianQuestion·observationResult 저장소가
        주입되지 않는다 — 읽기 경로 부재의 확정 증거다.
        """
        section = self.text.split("[1]", 1)[1].split("[2]", 1)[0]
        for field in ("activityNotes", "conversationSummary.summaryText", "guidance"):
            self.assertIn(field, section)
        # 전문가 계층 필드가 '보호자 화면' 칸에 섞이면 안 된다.
        for field in ("overallSummary", "positiveSignals", "features", "attentionPoints"):
            self.assertNotIn(field, section)

    def test_expert_only_fields_are_not_claimed_as_guardian_screen(self):
        """§13.1은 AI 관찰 초안을 ExpertReviewMaterial 계층에 둔다(REPORT-03 미구현)."""
        self.assertNotIn("리포트 맨 위 전체 요약", self.text)
        self.assertNotIn("'아이의 좋은 모습' 영역", self.text)
        self.assertNotIn("'관찰된 특징' 카드 목록", self.text)
        # 대신 '전문가 검토용으로만 저장' 갈래로 옮겨졌다.
        expert = self.text.split("[2]", 1)[1].split("[3]", 1)[0]
        for field in ("overallSummary", "positiveSignals", "features", "attentionPoints"):
            self.assertIn(field, expert)

    def test_unused_fields_are_marked_as_such(self):
        unused = self.text.split("[3]", 1)[1].split("어느 갈래든", 1)[0]
        for field in ("detailText", "guardianQuestions", "mainTopic", "expressedEmotion"):
            self.assertIn(field, unused)

    def test_screen_section_title_matches_the_frontend(self):
        """FE 섹션 제목은 '이런 질문으로 대화해 보세요'다 — 구 문구의 '집에서 이렇게 해보세요'가 아니다."""
        self.assertIn("이런 질문으로 대화해 보세요", self.text)
        self.assertNotIn("'집에서 이렇게 해보세요' 안내와 질문", self.text)

    def test_follow_up_guides_are_question_first_with_one_attitude_slot(self):
        self.assertIn("그대로 물어볼 수 있는 질문을 앞에 둔다", self.text)
        self.assertIn("마지막 1개는 질문 대신 듣는 태도 안내로 써도 좋다", self.text)

    # ── 1. NOT NULL 필드가 필수로 표시되는가 ──
    def test_not_null_fields_are_marked_required(self):
        """BE 컬럼이 NOT NULL인데 프롬프트에 표시가 없었다.

        지금 예외가 안 나는 이유는 report_client._assemble이 빈 문자열을 채우기 때문이고,
        BE는 saveActivityNotes만 blank를 스킵한다 — 나머지는 빈 행이 저장돼 화면에
        빈 불릿으로 나간다.
        """
        self.assertIn("비어 있으면 안 된다", self.text)
        for field in ("followUpGuides", "questionText", "description", "visibilityScope"):
            self.assertIn(field, self.text)
        self.assertIn("비워 두지 마라", self.text)

    # ── 2. 조용히 잘리는 길이 상한이 명시되는가 ──
    def test_silent_truncation_limits_are_stated_as_numbers(self):
        """ColumnTextLimiter.fit은 초과분을 잘라내고 log.warn만 남긴다(조용한 절단)."""
        for limit in ("50자", "100자", "80자", "200자"):
            self.assertIn(limit, self.text)
        self.assertIn("말없이 잘라내", self.text)

    def test_limits_match_backend_column_constants(self):
        """BE ObservationReportPersistenceService의 *_LIMIT 값과 어긋나면 안 된다.

        어긋나면 프롬프트가 허용한 길이가 조용히 잘린다 — 두 벌을 따로 관리하는 함정이라
        값이 바뀌면 이 테스트가 먼저 깨지도록 둔다.
        """
        expected = {
            "expressedEmotion": "50자",  # EXPRESSED_EMOTION_LIMIT
            "mainTopic": "100자",  # MAIN_TOPIC_LIMIT
            "questionPurpose": "50자",  # QUESTION_PURPOSE_LIMIT
            "featureCode": "80자",  # FEATURE_CODE_LIMIT
            "title": "200자",  # FEATURE_TITLE_LIMIT
        }
        block = self.text.split("길이 상한", 1)[1].split("{", 1)[0]
        for field, limit in expected.items():
            with self.subTest(field=field):
                self.assertRegex(block + self.text, rf"{field}[^\n]*{limit}|{limit}[^\n]*{field}")


def _request_with_evidence_refs(**overrides):
    """근거 식별자가 실려 온 요청 (S15P11B209-886).

    AI는 **요청에 실려 온 식별자만** 근거로 참조할 수 있다. 식별자가 없으면 근거가 전부 버려지므로,
    경향 카드 조립·게이트를 검증하는 테스트는 이 요청을 써야 한다.
    drawing_subject 는 None으로 둔다 — HTP로 판별되면 RAG 검색 경로까지 타서 검증 범위가 넓어진다.
    """
    overrides.setdefault(
        "subject_summaries",
        [
            contracts.SubjectSummary(
                drawing_subject=None,
                drawing_description="집이 가운데에 크게 그려져 있어요.",
                observation_evidence_source_id="obs-1",
                detected_objects=[
                    contracts.SubjectDetectedObject(
                        object_code="HOUSE",
                        x=0.2,
                        y=0.2,
                        width=0.5,
                        height=0.5,
                        evidence_source_id="d1",
                    )
                ],
                qa_pairs=[
                    contracts.SubjectQaPair(
                        question="이 집에는 누가 살아?",
                        answer_text="우리 가족",
                        answer_message_id=202,
                    ),
                    contracts.SubjectQaPair(
                        question="이 사람은 뭐 하고 있어?",
                        answer_text="가족을 기다려요",
                        answer_message_id=318,
                    ),
                    contracts.SubjectQaPair(
                        question="더 그리고 싶은 게 있어?",
                        answer_text="목도리",
                        answer_message_id=777,
                    ),
                    # 미확정 STT — 식별자가 실리지 않아 근거가 될 수 없다(875 §6-1).
                    contracts.SubjectQaPair(
                        question="기분이 어땠어?",
                        answer_text="조은데 무서워",
                        answer_message_id=555,
                        stt_needs_confirmation=True,
                    ),
                ],
            )
        ],
    )
    overrides.setdefault(
        "selected_emotion_refs",
        [contracts.SelectedEmotionRef(emotion_code="JOY", evidence_source_id="e5")],
    )
    overrides.setdefault("activity_metric_source_id", "m1")
    return _sample_request(**overrides)


def _evidence(evidence_id, source_type="CHILD_ANSWER", kind="QA_ANSWER", ref="202"):
    return {
        "evidenceId": evidence_id,
        "sourceType": source_type,
        "text": f"근거 {evidence_id}",
        "sourceRef": {"kind": kind, "id": ref},
    }


def _card(refs, **overrides):
    card = {
        "category": "RELATIONSHIP",
        "title": "가족과의 정서적 연결",
        "tendencyText": "가족에게 의지하려는 경향이 보일 수 있습니다.",
        "scopeText": "이번 그림 활동에서 나타난 가능성입니다.",
        "homeObservationGuide": "새로운 상황에서도 비슷한지 살펴봐 주세요.",
        "evidenceRefs": refs,
    }
    card.update(overrides)
    return card


class PublicInterpretationAssemblyTest(unittest.TestCase):
    """경향 해석 조립 — 875 계약 정본 v1.1 (S15P11B209-887).

    여기서 검증하는 것은 '조립 위생'이다: 계약 허용값·참조 정합·배타 규칙·표현 안전.
    독립 근거 계수 게이트(2건·아이 표현 1건)는 S15P11B209-888이 별도 모듈로 붙인다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_card_and_referenced_evidence_are_carried(self):
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        card = result.public_interpretations[0]
        self.assertEqual(card.category, "RELATIONSHIP")
        self.assertEqual(card.evidence_refs, [1, 2])
        self.assertEqual({i.evidence_id for i in result.evidence_items}, {1, 2})
        self.assertEqual(result.evidence_items[0].source_ref.kind, "QA_ANSWER")

    def test_empty_is_normal_when_model_gives_nothing(self):
        """근거가 없으면 빈 배열이 정상이다 — 리포트 생성은 성공한다(875 §10)."""
        result = self._generate()
        self.assertEqual(result.public_interpretations, [])
        self.assertEqual(result.evidence_items, [])

    def test_dangling_reference_drops_the_card(self):
        """존재하지 않는 근거만 가리키는 카드는 근거 없는 카드다 — 내지 않는다."""
        result = self._generate(
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([99])],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_unknown_ref_is_filtered_but_card_survives_with_valid_ones(self):
        # 근거는 2건 준다 — 1건만 주면 888 구조 게이트에서 카드가 빠져 이 검증이 무의미해진다.
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2, 99])],
        )
        self.assertEqual(result.public_interpretations[0].evidence_refs, [1, 2])

    def test_evidence_without_identifier_is_dropped(self):
        """식별자 없는 근거는 서버가 독립성을 검증할 수 없다 — 버린다(계약 §4)."""
        result = self._generate(
            evidenceItems=[
                {"evidenceId": 1, "sourceType": "CHILD_ANSWER", "text": "근거"}
            ],
            publicInterpretations=[_card([1])],
        )
        self.assertEqual(result.evidence_items, [])
        self.assertEqual(result.public_interpretations, [])

    def test_fabricated_ref_kind_is_dropped(self):
        result = self._generate(
            evidenceItems=[_evidence(1, kind="MADE_UP_KIND")],
            publicInterpretations=[_card([1])],
        )
        self.assertEqual(result.evidence_items, [])

    def test_both_source_ref_and_derived_from_is_invalid(self):
        """배타 규칙 — 정확히 하나여야 한다(875 §4)."""
        item = _evidence(1)
        item["derivedFrom"] = [{"kind": "QA_ANSWER", "id": "318"}]
        result = self._generate(
            evidenceItems=[item], publicInterpretations=[_card([1])]
        )
        self.assertEqual(result.evidence_items, [])

    def test_derived_evidence_uses_derived_from_only(self):
        result = self._generate(
            evidenceItems=[
                {
                    "evidenceId": 1,
                    "sourceType": "REPEATED_SUBJECT",
                    "text": "집과 사람 그림 모두에서 가족을 언급했어요.",
                    "derivedFrom": [
                        {"kind": "QA_ANSWER", "id": "202"},
                        {"kind": "QA_ANSWER", "id": "318"},
                    ],
                },
                _evidence(2, ref="318"),
            ],
            publicInterpretations=[_card([1, 2])],
        )
        derived = result.evidence_items[0]
        self.assertIsNone(derived.source_ref)
        self.assertEqual(len(derived.derived_from), 2)

    def test_definitive_tone_card_is_dropped(self):
        """단정 어조는 가능성 어조 규칙 위반이다 — 카드를 내지 않는다(875 §3)."""
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[
                _card([1, 2], tendencyText="가족 의존성이 매우 높습니다.")
            ],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_labeling_card_is_dropped_and_fails_self_review(self):
        """낙인 표현은 카드에 EXPERT_ONLY 자리가 없어 제외하고, 신호는 남긴다.

        여지 표현이 붙어 있어도(=단정 어조 검사는 통과) 고정 특질 규정은 걸러야 한다.
        """
        result = self._generate(
            expertReviewRequired=False,
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[
                _card([1, 2], tendencyText="애정결핍이 있을 수 있습니다.", title="애정")
            ],
        )
        self.assertEqual(result.public_interpretations, [])
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)

    def test_unsafe_card_signal_survives_even_if_malformed(self):
        """구조까지 어긋난 카드라도 진단 표현이 있었다는 신호는 사라지지 않아야 한다.

        안전 검사가 구조 검사보다 뒤에 있으면 이 신호가 조용히 없어진다(검사 순서 회귀 방지).
        """
        result = self._generate(
            expertReviewRequired=False,
            evidenceItems=[_evidence(1)],
            publicInterpretations=[
                _card([], category="NOPE", tendencyText="애정결핍이 있을 수 있습니다.")
            ],
        )
        self.assertEqual(result.public_interpretations, [])
        self.assertEqual(result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT)

    def test_unknown_category_is_dropped(self):
        result = self._generate(
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([1], category="ATTACHMENT_STYLE")],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_missing_scope_text_drops_the_card(self):
        result = self._generate(
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([1], scopeText="")],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_unreferenced_evidence_is_not_shipped(self):
        """카드가 쓰지 않는 근거는 싣지 않는다 — 화면에 쓰이지 않는 발화 인용을 남기지 않는다."""
        result = self._generate(
            evidenceItems=[
                _evidence(1),
                _evidence(2, ref="318"),
                _evidence(3, ref="777"),  # 어느 카드도 참조하지 않는다
            ],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual([i.evidence_id for i in result.evidence_items], [1, 2])

    def test_duplicate_evidence_id_keeps_first_only(self):
        result = self._generate(
            evidenceItems=[
                _evidence(1),
                _evidence(1, ref="999"),  # 같은 번호 재사용 — 참조가 모호해진다
                _evidence(2, ref="318"),
            ],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual([i.evidence_id for i in result.evidence_items], [1, 2])
        first = next(i for i in result.evidence_items if i.evidence_id == 1)
        self.assertEqual(first.source_ref.id, "202")


class EvidenceIdentifierTest(unittest.TestCase):
    """근거 식별자 수용·강제 (S15P11B209-886).

    AI가 참조할 수 있는 것은 **요청에 실려 온 식별자뿐**이다. kind 형식만 검사하면 그럴듯한
    번호를 지어내도 통과하므로, 실제로 받은 값인지 대조한다 — 그게 "BE 발급 ID만"의 실효 장치다.
    """

    def _blocks(self, req):
        return report_client._format_subject_blocks(req)

    def test_qa_identifier_is_offered_to_the_model(self):
        blocks = self._blocks(_request_with_evidence_refs())
        self.assertIn("근거 식별자: QA_ANSWER:202", blocks)

    def test_unconfirmed_stt_gets_no_identifier(self):
        """미확정 STT는 표시는 유지하되 식별자를 주지 않는다 — 재료를 안 주는 편이 확실하다."""
        blocks = self._blocks(_request_with_evidence_refs())
        self.assertIn("조은데 무서워", blocks)  # 표시는 유지
        self.assertNotIn("QA_ANSWER:555", blocks)  # 근거로는 쓸 수 없다
        self.assertIn("근거로 쓸 수 없어요", blocks)

    def test_observation_and_object_identifiers_are_offered(self):
        blocks = self._blocks(_request_with_evidence_refs())
        self.assertIn("VLM_OBSERVATION:obs-1", blocks)
        self.assertIn("HOUSE=d1", blocks)

    def test_emotion_and_metric_identifiers_are_offered(self):
        prompt = report_client._format_activity(
            _request_with_evidence_refs(), drawing_description=None
        )
        self.assertIn("EMOTION_SELECTION:e5", prompt)
        self.assertIn("ACTIVITY_METRIC:m1", prompt)

    def test_allowed_and_blocked_sets_are_derived_from_the_request(self):
        req = _request_with_evidence_refs()
        allowed = report_client._allowed_evidence_refs(req)
        blocked = report_client._blocked_evidence_refs(req)
        self.assertIn(("QA_ANSWER", "202"), allowed)
        self.assertIn(("VLM_OBSERVATION", "obs-1"), allowed)
        self.assertIn(("DETECTED_OBJECT", "d1"), allowed)
        self.assertIn(("EMOTION_SELECTION", "e5"), allowed)
        self.assertIn(("ACTIVITY_METRIC", "m1"), allowed)
        # 미확정 STT는 허용 목록에 없고 배제 목록에 있다(이중 방어).
        self.assertNotIn(("QA_ANSWER", "555"), allowed)
        self.assertIn(("QA_ANSWER", "555"), blocked)

    def test_request_without_identifiers_yields_no_evidence(self):
        """구 BE(식별자 없음)는 200으로 동작하고 카드만 비운다 — 리포트 본문은 유지된다."""
        self.assertEqual(report_client._allowed_evidence_refs(_sample_request()), frozenset())


class FabricatedIdentifierTest(unittest.TestCase):
    """지어낸 식별자는 형식이 맞아도 통과하지 못한다 (S15P11B209-886)."""

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_unknown_identifier_is_dropped(self):
        result = self._generate(
            evidenceItems=[_evidence(1, ref="999"), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(result.evidence_items, [])  # 카드가 빠지며 근거도 함께 빠진다
        self.assertEqual(result.public_interpretations, [])

    def test_unconfirmed_stt_identifier_cannot_become_evidence(self):
        """모델이 다른 곳에서 본 번호를 옮겨 적어도 근거가 되지 못한다."""
        result = self._generate(
            evidenceItems=[_evidence(1, ref="555"), _evidence(2, ref="202")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_real_identifiers_survive(self):
        result = self._generate(
            evidenceItems=[_evidence(1, ref="202"), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)

    def test_mixed_kind_identifiers_pass_when_provided(self):
        """서로 다른 종류를 섞어도 요청에 있으면 통과한다 — 아이 표현 1건 조건은 지켜야 한다."""
        result = self._generate(
            evidenceItems=[
                _evidence(1, ref="202"),
                _evidence(2, source_type="VISION", kind="DETECTED_OBJECT", ref="d1"),
            ],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)


class InterpretationGateWiringTest(unittest.TestCase):
    """구조 게이트가 응답 조립에 실제로 걸려 있는지 (S15P11B209-888).

    게이트 로직 자체는 test_interpretation_gate.py가 검증한다. 여기서는 배선만 본다 —
    모듈이 있어도 호출되지 않으면 규칙이 없는 것과 같다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_single_evidence_card_is_dropped_by_the_gate(self):
        result = self._generate(
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([1])],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_two_independent_origins_pass_the_gate(self):
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)

    def test_card_without_child_expression_is_dropped(self):
        """그림 관찰·활동 지표만으로 만든 카드는 공개하지 않는다."""
        result = self._generate(
            evidenceItems=[
                _evidence(1, source_type="VISION", kind="DETECTED_OBJECT", ref="d1"),
                _evidence(
                    2, source_type="ACTIVITY_METRIC", kind="ACTIVITY_METRIC", ref="m1"
                ),
            ],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_gate_failure_does_not_downgrade_features(self):
        """게이트 실패는 제외이고 강등이 아니다 — features 노출 범위를 건드리지 않는다."""
        result = self._generate(
            expertReviewRequired=False,
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([1])],
            features=[
                {
                    "featureCode": "X",
                    "title": "관찰",
                    "description": "차분히 그린 모습이 보여요.",
                    "evidenceSummary": "약 10분간 그렸어요.",
                    "visibilityScope": "REVIEWED_GUARDIAN",
                }
            ],
        )
        self.assertEqual(result.public_interpretations, [])
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )
        self.assertFalse(result.observation_draft.expert_review_required)


class ConfidenceWiringTest(unittest.TestCase):
    """확신도가 **응답까지 실제로 도달하는지** (S15P11B209-982).

    등급 규칙 자체는 test_interpretation_gate.py 가 검증한다. 여기서 보는 것은 이음매다 —
    902에서 저장 메서드를 만들어 두고 아무도 부르지 않아 몇 주간 빈 화면이었고, 그때도
    단위 테스트는 전부 통과했다. 계산이 맞는지와 값이 도착하는지는 다른 질문이다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_published_card_reaches_the_response_with_a_grade(self):
        """아이 답변 두 건 → STRONG 이 응답 카드에 실려 나온다."""
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        self.assertEqual(result.public_interpretations[0].confidence, "STRONG")

    def test_grade_reflects_evidence_kind_not_model_wish(self):
        """감정 선택 + 그림이면 발화가 없다 — 모델이 STRONG 이라 적어 보내도 WEAK 다."""
        result = self._generate(
            evidenceItems=[
                _evidence(
                    1, source_type="SELECTED_EMOTION", kind="EMOTION_SELECTION", ref="e5"
                ),
                _evidence(2, source_type="VISION", kind="DETECTED_OBJECT", ref="d1"),
            ],
            publicInterpretations=[_card([1, 2], confidence="STRONG")],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        self.assertEqual(result.public_interpretations[0].confidence, "WEAK")

    def test_utterance_plus_drawing_is_moderate_end_to_end(self):
        result = self._generate(
            evidenceItems=[
                _evidence(1),
                _evidence(2, source_type="VISION", kind="DETECTED_OBJECT", ref="d1"),
            ],
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(result.public_interpretations[0].confidence, "MODERATE")

    def test_grade_is_serialized_for_be(self):
        """BE 로 나가는 JSON에 confidence 가 실린다 — 필드가 계약 밖이면 화면까지 못 간다."""
        result = self._generate(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        payload = result.model_dump(by_alias=True)
        self.assertEqual(payload["publicInterpretations"][0]["confidence"], "STRONG")

    def test_confidence_is_given_to_the_self_reviewer(self):
        """검토자가 OVERCLAIM 을 판정하려면 등급을 알아야 한다 — 검토 payload 에 실린다."""
        captured: dict = {}
        client = mock.Mock()
        client.chat.completions.create.side_effect = _capture_generation(
            captured,
            _llm_json(
                evidenceItems=[_evidence(1), _evidence(2, ref="318")],
                publicInterpretations=[_card([1, 2])],
            ),
        )
        with mock.patch.object(report_client, "get_client", return_value=client):
            report_client.generate(_request_with_evidence_refs(), model="m")
        review_text = json.dumps(captured["review_messages"], ensure_ascii=False)
        self.assertIn("확신도", review_text)
        self.assertIn("STRONG", review_text)


class OverclaimExclusionTest(unittest.TestCase):
    """확신도 대비 과장은 카드를 뺀다 (S15P11B209-982 규칙 2).

    약한 근거를 강한 주장으로 승격하는 마지막 통로가 **문장의 세기**다. 등급은 코드가 정해도
    문장이 등급을 넘어서면 보호자는 약한 추측을 강한 근거로 읽는다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def _weak_evidence(self):
        # 감정 선택 + 그림 → 게이트는 통과하지만(아이 표현 1건) 발화가 없어 WEAK.
        return [
            _evidence(
                1, source_type="SELECTED_EMOTION", kind="EMOTION_SELECTION", ref="e5"
            ),
            _evidence(2, source_type="VISION", kind="DETECTED_OBJECT", ref="d1"),
        ]

    def test_weak_card_generalizing_beyond_the_activity_is_dropped(self):
        """WEAK 인데 '평소에도 그렇다'로 넓힌 카드는 뺀다."""
        result = self._generate(
            evidenceItems=self._weak_evidence(),
            publicInterpretations=[
                _card(
                    [1, 2],
                    tendencyText="평소에도 가족에게 의지하려는 경향이 보일 수 있습니다.",
                )
            ],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_weak_card_written_carefully_survives(self):
        """등급이 낮다는 이유만으로 빼지 않는다 — WEAK 도 조심스러우면 보호자에게 간다."""
        result = self._generate(
            evidenceItems=self._weak_evidence(),
            publicInterpretations=[_card([1, 2])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        self.assertEqual(result.public_interpretations[0].confidence, "WEAK")

    def test_certainty_wording_is_dropped(self):
        """확정 어휘는 등급과 무관하게 뺀다 — 이 리포트에 단정할 자리는 없다."""
        result = self._generate(
            evidenceItems=self._weak_evidence(),
            publicInterpretations=[
                _card(
                    [1, 2],
                    tendencyText="분명히 가족에게 의지하려는 경향이 보일 수 있습니다.",
                )
            ],
        )
        self.assertEqual(result.public_interpretations, [])

    def test_overclaim_does_not_fail_the_whole_report(self):
        """문제 카드만 빠지고 리포트는 살아난다 — 전체 실패는 보호자 화면을 통째로 지운다."""
        result = self._generate(
            evidenceItems=self._weak_evidence(),
            publicInterpretations=[
                _card([1, 2], tendencyText="평소에도 그런 경향이 보일 수 있습니다.")
            ],
        )
        self.assertEqual(result.public_interpretations, [])
        self.assertTrue(result.observation_draft.overall_summary)
        self.assertTrue(result.limitations_text)

    def test_home_observation_guide_may_say_pyeongso(self):
        """'평소에도 살펴봐 주세요'는 가정 관찰 안내의 정상 문구다 — 주장 문장만 검사한다."""
        result = self._generate(
            evidenceItems=self._weak_evidence(),
            publicInterpretations=[
                _card(
                    [1, 2],
                    homeObservationGuide="평소에도 비슷한 모습이 있는지 살펴봐 주세요.",
                )
            ],
        )
        self.assertEqual(len(result.public_interpretations), 1)


class ReportWithoutInterpretationTest(unittest.TestCase):
    """해석이 한 건도 없는 세션에서도 리포트는 정상 생성된다 (875 §10 · 982).

    빈 카드가 정상 출력임을 계약과 프롬프트 양쪽에 적었다. 그 약속이 코드에서도 지켜지는지 —
    빈 배열을 실패로 다루기 시작하면 모델이 근거를 지어내는 압력으로 돌아온다.
    """

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_no_cards_still_produces_a_complete_report(self):
        result = self._generate(publicInterpretations=[], evidenceItems=[])
        self.assertEqual(result.public_interpretations, [])
        self.assertEqual(result.evidence_items, [])
        # 리포트의 나머지는 온전하다 — 카드가 없다고 실패가 아니다.
        self.assertTrue(result.observation_draft.overall_summary)
        self.assertTrue(result.observation_draft.disclaimer)
        self.assertTrue(result.limitations_text)
        self.assertTrue(result.activity_notes)
        self.assertEqual(result.observation_draft.status, "AI_REVIEWED")

    def test_all_cards_failing_the_gate_still_produces_a_report(self):
        """근거가 모자라 카드가 전부 빠져도 리포트는 성공한다."""
        result = self._generate(
            evidenceItems=[_evidence(1)],
            publicInterpretations=[_card([1])],
        )
        self.assertEqual(result.public_interpretations, [])
        self.assertTrue(result.observation_draft.overall_summary)
        self.assertTrue(result.limitations_text)


class ParentGuideAssemblyTest(unittest.TestCase):
    """보호자 가이드 — 검토 대상 유형은 LLM이 채우지 못한다 (S15P11B209-887)."""

    def _generate(self, **overrides):
        fake_client = _fake_client(_llm_json(**overrides))
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(_request_with_evidence_refs(), model="m")

    def test_ai_generated_types_are_kept(self):
        result = self._generate(
            parentGuides=[
                {"guideType": "DRAWING_CONVERSATION", "items": ["무엇을 하고 싶은지 물어보세요."]},
                {"guideType": "HOME_OBSERVATION", "items": ["비슷한 모습이 반복되는지 살펴봐 주세요."]},
            ]
        )
        self.assertEqual(
            [g.guide_type for g in result.parent_guides],
            ["DRAWING_CONVERSATION", "HOME_OBSERVATION"],
        )

    def test_reviewed_types_from_llm_are_dropped(self):
        """DAILY_PARENTING·PROFESSIONAL_SUPPORT 는 검토된 문장·고정 템플릿 소유다(875 §7-1).

        LLM이 채우면 미검토 육아 조언·상담 안내가 보호자에게 나간다 — 이 필드의 유일한 사고 유형.
        """
        result = self._generate(
            parentGuides=[
                {"guideType": "DAILY_PARENTING", "items": ["이렇게 하세요."]},
                {"guideType": "PROFESSIONAL_SUPPORT", "items": ["상담을 받으세요."]},
            ]
        )
        self.assertEqual(result.parent_guides, [])

    def test_unsafe_item_is_dropped(self):
        result = self._generate(
            parentGuides=[
                {
                    "guideType": "DRAWING_CONVERSATION",
                    "items": ["이 아이는 불안장애로 보입니다.", "무엇을 하고 싶은지 물어보세요."],
                }
            ]
        )
        self.assertEqual(result.parent_guides[0].items, ["무엇을 하고 싶은지 물어보세요."])


class DrawnItemsAssemblyTest(unittest.TestCase):
    """'그린 것' — 관찰 서술에 실제로 있는 이름만 남는다 (S15P11B209-911).

    보호자 리포트의 그 줄은 지금까지 BE가 탐지 라벨(YOLO)을 그대로 나열해 채웠다. 탐지
    임계값은 0.20이고 그 목록엔 신뢰도 필터가 없어 오탐이 확정 사실로 나갔다.
    여기서 검증하는 것은 "프롬프트에 부탁하는 게 아니라 코드가 서술 원문과 대조해 막는다"다.
    """

    def _generate(self, request=None, **overrides):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(
            _llm_json(**overrides)
        )
        with mock.patch.object(
            report_client, "retrieve", return_value=[]
        ), mock.patch.object(report_client, "get_client", return_value=fake_client):
            return report_client.generate(
                request if request is not None else _request_with_evidence_refs(),
                model="m",
            )

    @staticmethod
    def _request(*subjects):
        """(drawingSubject, 관찰 서술) 쌍으로 요청을 만든다."""
        return _request_with_evidence_refs(
            subject_summaries=[
                contracts.SubjectSummary(
                    drawing_subject=subject, drawing_description=description
                )
                for subject, description in subjects
            ]
        )

    def test_name_present_in_description_is_kept(self):
        result = self._generate(drawnItems=[{"drawingSubject": None, "name": "집"}])
        self.assertEqual(
            [(i.drawing_subject, i.name) for i in result.drawn_items], [(None, "집")]
        )

    def test_name_absent_from_description_is_dropped(self):
        """탐지 코드 줄에만 있는 이름은 근거가 아니다.

        기본 요청의 탐지 객체는 HOUSE 하나이고 서술은 '집이 가운데에 크게 그려져 있어요.'다.
        모델이 서술에 없는 대상을 덧붙이면 여기서 사라져야 한다.
        """
        result = self._generate(
            drawnItems=[
                {"drawingSubject": None, "name": "울타리"},
                {"drawingSubject": None, "name": "집"},
            ]
        )
        self.assertEqual([i.name for i in result.drawn_items], ["집"])

    def test_unknown_subject_is_dropped(self):
        """그리지 않은 그림의 항목 — 요청에 없는 주제는 대조할 서술이 없다."""
        result = self._generate(drawnItems=[{"drawingSubject": "TREE", "name": "집"}])
        self.assertEqual(result.drawn_items, [])

    def test_duplicate_name_in_same_subject_is_collapsed(self):
        result = self._generate(
            drawnItems=[
                {"drawingSubject": None, "name": "집"},
                {"drawingSubject": None, "name": "집"},
            ]
        )
        self.assertEqual([i.name for i in result.drawn_items], ["집"])

    def test_name_over_length_limit_is_dropped(self):
        """상한을 넘으면 BE 컬럼에서 조용히 잘려 이름이 중간에서 끊긴다.

        서술 원문에 그대로 있는 문구라도 길면 이름이 아니다 — 서술 한 구절을 옮긴 것이다.
        """
        long_name = "화면 가운데에 빨간 지붕을 얹은 커다란 이층집"
        self.assertGreater(len(long_name), report_client._DRAWN_ITEM_NAME_MAX)
        request = self._request((None, f"{long_name}이 서 있어요."))
        result = self._generate(
            request, drawnItems=[{"drawingSubject": None, "name": long_name}]
        )
        self.assertEqual(result.drawn_items, [])

    def test_per_subject_count_is_capped(self):
        """서술은 2~4문장이라, 그보다 많으면 서술이 아니라 탐지 코드 목록을 옮긴 것이다."""
        request = self._request((None, "집과 나무와 해와 구름과 새가 함께 그려져 있어요."))
        result = self._generate(
            request,
            drawnItems=[
                {"drawingSubject": None, "name": name}
                for name in ("집", "나무", "해", "구름", "새")
            ],
        )
        self.assertEqual(
            [i.name for i in result.drawn_items], ["집", "나무", "해", "구름"]
        )

    def test_subject_order_follows_the_request(self):
        """BE가 이름을 쉼표로 이어 한 줄로 보이므로 순서가 곧 문장이다."""
        request = self._request(
            ("HOUSE", "집이 있어요."),
            ("TREE", "나무가 있어요."),
            ("PERSON", "사람이 있어요."),
        )
        result = self._generate(
            request,
            drawnItems=[
                {"drawingSubject": "PERSON", "name": "사람"},
                {"drawingSubject": "HOUSE", "name": "집"},
                {"drawingSubject": "TREE", "name": "나무"},
            ],
        )
        self.assertEqual([i.name for i in result.drawn_items], ["집", "나무", "사람"])

    def test_missing_field_is_empty_list(self):
        """구 BE·FE 동작 불변 — 모델이 안 주면 빈 목록이고 그것이 정상이다."""
        self.assertEqual(self._generate().drawn_items, [])

    def test_prompt_states_the_description_is_the_only_source(self):
        """문구가 빠지면 모델이 탐지 코드 줄을 옮겨 적는다(코드가 막지만 매번 버려진다)."""
        text = prompts_registry.load("report_htp")
        self.assertIn("'탐지된 요소 코드' 줄은 이 목록의 근거가 **아니다.**", text)
        # 908에서 확인: 새 필드는 스키마 예시에 있어야 채워진다(지시문보다 예시가 세다).
        self.assertIn('"drawnItems"', text.split("출력 형식:", 1)[1])


class CrisisAlertOwnershipTest(unittest.TestCase):
    """위기 안내는 LLM이 만들지 않는다 — 889가 검토된 템플릿으로 채운다 (S15P11B209-887)."""

    def test_crisis_alert_is_not_built_from_llm_output(self):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.return_value = _fake_response(
            _llm_json(
                crisisAlert={
                    "reasonCode": "SELF_HARM_RISK",
                    "severity": "HIGH",
                    "title": "지어낸 위기 안내",
                    "message": "LLM이 만든 문구",
                }
            )
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="m")
        self.assertIsNone(result.crisis_alert)


class RoutingSingleOwnerTest(unittest.TestCase):
    """표시 위치를 [1]/[2]/[3] 절만 말하는지 (S15P11B209-871).

    826이 라우팅을 재정의한 뒤 845가 "우려 소견도 보호자에게 보낸다"를 추가해, 같은 파일이
    features 에 대해 '보호자에게 보낸다'와 '보호자 화면에 안 나간다'를 동시에 말했다.
    스키마 설명도 826 이전의 "보호자에게 노출 가능한" 문구를 그대로 달고 있었다.
    소유자를 한 곳으로 못박아, 다음 수정자가 다른 구역에 목적지를 또 쓰지 않게 한다.
    """

    def setUp(self):
        self.text = prompts_registry.load("report_htp")
        self.schema = self.text[self.text.index("{\n  \"overallSummary\"") :]

    def test_routing_ownership_is_declared(self):
        head = self.text.split("[1]", 1)[0]
        self.assertIn("이 절에서만", head)
        self.assertIn("표시 위치는 다시 적지 않는다", head)

    def test_schema_descriptions_make_no_display_claims(self):
        """스키마 설명이 목적지를 말하면 [1]/[2]/[3]과 어긋날 수 있다 — 아예 말하지 않는다."""
        for claim in ("보호자 화면", "노출 가능", "전문가 검토용", "화면에 안 나감"):
            self.assertNotIn(claim, self.schema, f"스키마 설명에 표시 위치 주장: {claim}")

    def test_expert_tier_fields_are_not_promised_to_guardian(self):
        """845 회귀 — features 를 '보호자에게 보낸다'고 말하면 [2]와 정면 충돌한다."""
        self.assertNotIn("이 조건을 갖추면 보호자에게 보낸다", self.text)
        self.assertNotIn("근거가 분명하면 보호자에게 전할 수 있고", self.text)

    def test_concerning_findings_have_a_named_destination(self):
        """'보호자에게 전할 수 있다'고만 하면 담을 자리가 없다 — 필드를 지목해야 한다."""
        rule = self.text.split("걱정되는 점이 보이면", 1)[1].split("\n-", 1)[0]
        self.assertIn("features", rule)
        self.assertIn("REVIEWED_GUARDIAN", rule)

    def test_visibility_scope_is_described_as_the_gate(self):
        """2026-08-05 — 사후 분류값이 아니라 보호자 도달을 실제로 가르는 값이 됐다.

        구 문구는 "지금 화면 도달 여부를 바꾸지 않는다 … 나중에 열릴 때를 대비한 분류값"이었다.
        사람 전문가 독자가 없다는 것이 확인된 뒤로는 자체검토가 그 관문이라, 값이 실효를 갖는다.
        """
        expert = self.text.split("[2]", 1)[1].split("[3]", 1)[0]
        self.assertIn("visibilityScope", expert)
        self.assertNotIn("분류값", expert)
        self.assertIn("보호자 도달 여부를 실제로 가른다", expert)

    def test_activity_notes_count_floor_is_stated(self):
        """스키마에서 '불릿' 표시를 걷어내자 activityNotes 가 평균 2.67 → 1.00 으로 줄었다.

        표시 위치 주장 없이 개수 신호를 살리려면 개수를 소유한 출력 형식 절이 하한을 말해야
        한다. 이 줄이 빠지면 보호자 '활동 기록' 카드가 한 줄짜리가 된다(실측 회귀).
        """
        self.assertIn("activityNotes 는 **2~3개**를 채운다(3개를 넘기지 마)", self.text)


class SelfReviewTest(unittest.TestCase):
    """AI 자체검토(2-pass, 2026-08-05).

    이 서비스에는 리포트를 읽는 사람 전문가가 없다(실측: ObservationReviewStatus 값이 AI_DRAFT
    하나뿐 · 전이 코드 0건 · EXPERT 읽기 경로 0건 · 운영 관찰 특징 97건 전량 EXPERT_ONLY).
    그 관문을 AI가 대신하므로, 여기서 고정하는 것은 **무엇이 보호자에게 열리는가**다.
    """

    def _run(self, review: str, generation: str | None = None, *, req=None):
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(
            captured, generation, review
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(req or _sample_request(), model="m")
        return result, captured

    # ── 통과 경로 ──
    def test_clean_report_is_marked_reviewed(self):
        result, captured = self._run(_REVIEW_PASS)

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_REVIEWED
        )
        # 검토는 별도 호출이고 검토 프롬프트를 쓴다.
        self.assertIn("검토하는 검토자", captured["review_messages"][0]["content"])

    def test_review_payload_carries_facts_and_ids(self):
        """검토자는 '관찰 사실'과 id 붙은 '검토 대상'을 받는다 — id 는 코드가 발급한다."""
        _, captured = self._run(_REVIEW_PASS)

        payload = json.loads(captured["review_messages"][1]["content"])
        ids = {item["id"] for item in payload["검토 대상"]}
        self.assertIn("draft.overallSummary", ids)
        self.assertIn("feature.0", ids)
        self.assertTrue(payload["관찰 사실"])

    def test_evidence_summary_is_reviewed_not_only_pooled(self):
        """근거 자리에 해석이 섞이면 다른 문장들이 그걸 사실로 알고 기댄다 — 빠지면 안 된다."""
        _, captured = self._run(_REVIEW_PASS)

        payload = json.loads(captured["review_messages"][1]["content"])
        ids = {item["id"] for item in payload["검토 대상"]}
        self.assertIn("draft.evidenceSummary", ids)

    def test_child_quotes_are_not_listed_as_review_targets(self):
        """근거 인용은 '해석'으로 잡을 자리가 아니다 — 근거 풀로만 넘긴다."""
        generation = _llm_json(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        _, captured = self._run(
            _REVIEW_PASS, generation, req=_request_with_evidence_refs()
        )

        payload = json.loads(captured["review_messages"][1]["content"])
        ids = {item["id"] for item in payload["검토 대상"]}
        self.assertFalse({i for i in ids if i.startswith("evidence")})
        self.assertIn("card.0", ids)

    def test_review_runs_at_temperature_zero(self):
        """판정이 회차마다 흔들리면 같은 리포트가 열렸다 닫혔다 한다."""
        calls = []

        def create(**kwargs):
            calls.append(kwargs)
            return _fake_response(_llm_json() if len(calls) == 1 else _REVIEW_PASS)

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = create
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(_sample_request(), model="m")

        self.assertEqual(calls[1]["temperature"], 0)

    def test_review_call_is_time_boxed(self):
        """생성+검토 두 번이 BE read timeout(30s) 안에 끝나야 한다 — 넘기면 생성까지 버려진다."""
        calls = []

        def create(**kwargs):
            calls.append(kwargs)
            return _fake_response(_llm_json() if len(calls) == 1 else _REVIEW_PASS)

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = create
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            report_client.generate(_sample_request(), model="m")

        self.assertEqual(calls[1]["timeout"], config.REPORT_REVIEW_TIMEOUT_SEC)
        self.assertLess(config.REPORT_REVIEW_TIMEOUT_SEC, 30)

    # ── 담아낼 수 있는 지적: 항목만 가리고 리포트는 연다 ──
    def test_flagged_feature_is_demoted_not_deleted(self):
        result, _ = self._run(
            _review_findings({"target": "feature.0", "issue": "NO_EVIDENCE"})
        )

        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "EXPERT_ONLY"
        )
        # 내용은 보존한다 — 격리지 폐기가 아니다.
        self.assertIn("가운데", result.observation_draft.features[0].description)
        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_REVIEWED
        )

    def test_flagged_card_is_dropped_with_its_orphaned_evidence(self):
        generation = _llm_json(
            evidenceItems=[_evidence(1), _evidence(2, ref="318")],
            publicInterpretations=[_card([1, 2])],
        )
        result, _ = self._run(
            _review_findings({"target": "card.0", "issue": "OVERREACH"}),
            generation,
            req=_request_with_evidence_refs(),
        )

        self.assertEqual(result.public_interpretations, [])
        # 화면에 쓰이지 않는 아이 발화 인용이 응답에 남지 않게 함께 솎는다(최소 노출).
        self.assertEqual(result.evidence_items, [])
        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_REVIEWED
        )

    # ── 담아낼 수 없는 지적: 리포트 전체를 열지 않는다 ──
    def test_flagged_narrative_field_fails_the_whole_report(self):
        result, _ = self._run(
            _review_findings({"target": "draft.overallSummary", "issue": "DIAGNOSTIC"})
        )

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )
        # 문장을 다시 쓰거나 비우지 않는다 — 비우면 보호자 화면이 무너지고, 고치면 2차 생성이다.
        self.assertIn("즐겁게", result.observation_draft.overall_summary)

    def test_flagged_activity_note_fails_the_whole_report(self):
        result, _ = self._run(
            _review_findings({"target": "activityNote.0", "issue": "OVERREACH"})
        )

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )
        self.assertTrue(result.activity_notes)  # [1] 필수 필드는 비우지 않는다

    def test_rule_filter_hit_blocks_even_when_review_passes(self):
        """1층(정규식)과 2층(LLM)은 합쳐진다 — 한쪽만 통과해도 열지 않는다."""
        result, _ = self._run(
            _REVIEW_PASS,
            _llm_json(overallSummary="이 아이는 우울증이 있어 보입니다."),
        )

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )

    def test_attention_points_now_passes_through_the_rule_filter(self):
        """2026-08-05에 보호자가 읽는 자리가 됐다 — 검사 면제를 남겨 두면 구멍이다."""
        result, _ = self._run(
            _REVIEW_PASS, _llm_json(attentionPoints="이 아이는 ADHD로 진단됩니다.")
        )

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )

    # ── 검토를 믿지 않는 부분 ──
    def test_unknown_target_and_issue_are_ignored(self):
        """모델이 지어낸 id·코드로 리포트를 떨어뜨리지 못하게 한다(886의 식별자 대조와 같은 결)."""
        result, _ = self._run(
            _review_findings(
                {"target": "draft.nope", "issue": "DIAGNOSTIC"},
                {"target": "feature.0", "issue": "NOT_A_CODE"},
                {"target": "feature.99", "issue": "STIGMA"},
            )
        )

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_REVIEWED
        )
        self.assertEqual(
            result.observation_draft.features[0].visibility_scope, "REVIEWED_GUARDIAN"
        )

    def test_expert_only_features_are_not_sent_for_review(self):
        """이미 보호자에게 안 나가는 카드다 — 넣으면 '무거운 관찰'을 또 잡아 전체를 떨어뜨린다."""
        generation = _llm_json(
            features=[
                {
                    "featureCode": "X",
                    "title": "관찰",
                    "description": "안전이 걱정되는 신호가 보여요.",
                    "evidenceSummary": "e",
                    "visibilityScope": "EXPERT_ONLY",
                }
            ]
        )
        _, captured = self._run(_REVIEW_PASS, generation)

        payload = json.loads(captured["review_messages"][1]["content"])
        self.assertNotIn(
            "feature.0", {item["id"] for item in payload["검토 대상"]}
        )

    # ── 실패는 차단이 아니라 기능 저하 ──
    def test_review_call_failure_leaves_report_unreviewed(self):
        calls = []

        def create(**kwargs):
            calls.append(kwargs)
            if len(calls) == 1:
                return _fake_response(_llm_json())
            raise OpenAIError("boom")

        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = create
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="m")

        # 리포트 자체는 나간다. 다만 '검토 못 했으니 열지 않는다'가 보수적인 쪽이다.
        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )
        self.assertIn("즐겁게", result.observation_draft.overall_summary)

    def test_unparseable_review_leaves_report_unreviewed(self):
        result, _ = self._run("검토 결과를 알려드릴게요")

        self.assertEqual(
            result.observation_draft.status, report_client.REVIEW_STATUS_DRAFT
        )

    def test_generation_failure_still_raises(self):
        """생성 실패는 여전히 차단이다 — 검토 실패와 뜻이 다르다."""
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = OpenAIError("boom")
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            with self.assertRaises(RuntimeError):
                report_client.generate(_sample_request(), model="m")

    # ── 축 분리 ──
    def test_consult_signal_is_owned_by_the_model_not_the_filters(self):
        """expertReviewRequired = 사람 상담을 권할 신호. 품질 실패로 켜지지 않는다."""
        flagged, _ = self._run(
            _review_findings({"target": "draft.overallSummary", "issue": "STIGMA"}),
            _llm_json(expertReviewRequired=False),
        )
        self.assertFalse(flagged.observation_draft.expert_review_required)

        concerned, _ = self._run(
            _REVIEW_PASS, _llm_json(expertReviewRequired=True)
        )
        self.assertTrue(concerned.observation_draft.expert_review_required)
        # 상담 권유가 필요한 리포트여도 문장이 안전하면 보호자에게는 열린다 — 축이 다르다.
        self.assertEqual(
            concerned.observation_draft.status, report_client.REVIEW_STATUS_REVIEWED
        )


class SelfReviewPromptTest(unittest.TestCase):
    """report_review.txt 가 '과탐지로 리포트를 죽이지 않게' 쓰였는지.

    이 검토자의 실패 모드는 두 방향이다. 놓치면 진단·낙인이 보호자에게 나가고, 과하게 잡으면
    보호자가 볼 것이 통째로 사라진다. 후자가 실제로 더 자주 나므로 문구로 고정한다.
    """

    def setUp(self):
        self.text = prompts_registry.load("report_review")

    def test_hedged_interpretation_is_explicitly_allowed(self):
        self.assertIn("애매하면 잡지 않는다", self.text)
        self.assertIn("근거가 있는데 부드럽게 쓴 것은 통과시킨다", self.text)

    def test_heavy_topics_are_not_a_reason_to_flag(self):
        """무거운 주제를 잡으면 보호자에게서 관찰을 감추는 일이 된다(report_common 2.0.0과 같은 결)."""
        self.assertIn("주제가 무겁다는 이유로 잡지 마라", self.text)

    def test_reviewer_does_not_rewrite(self):
        """고치기 시작하면 2차 생성이라 안전 검증을 처음부터 다시 받아야 한다."""
        self.assertIn("문장을 고치지 않는다", self.text)
        self.assertIn("품질 첨삭은 하지 않는다", self.text)

    def test_issue_codes_match_the_code(self):
        for code in report_client._REVIEW_ISSUES:
            self.assertIn(code, self.text, f"프롬프트에 없는 코드: {code}")

    def test_child_utterances_are_not_echoed_into_notes(self):
        self.assertIn("아이의 말이나 개인적인 내용을 그대로 옮겨 적지 마", self.text)

    def test_imagined_story_written_as_fact_is_catchable(self):
        """상상한 이야기를 있었던 일로 적은 문장 (S15P11B209-999).

        대화 프롬프트가 실제/상상 확인을 "반드시 묻지 않는다"로 바꾸면서, 모르는 채로 넘어온
        이야기가 정상 경로가 됐다. 초안이 그걸 사실로 적어도 기존 여섯 코드가 가리키는 곳이
        없었다 — 코드를 늘리지 않고 NO_EVIDENCE 에 귀속시킨다.
        """
        self.assertIn("상상한 이야기로 말한 것을 실제로 있었던 일처럼 적은 문장", self.text)

    def test_unstated_time_is_catchable(self):
        """활동을 한 날짜와 그림 속 일이 일어난 때는 다르다 — OVERREACH 쪽이다."""
        self.assertIn("아이가 말하지 않은 시점을 정해 적은 문장", self.text)


class DiaryRealityAndTimeRulesTest(unittest.TestCase):
    """그림일기 리포트가 실제/상상·시점을 단정하지 않는다 (S15P11B209-999).

    conversations_diary 4.1.0이 "실제 경험인지 상상인지 반드시 묻지 않는다"로 바뀌었다.
    아이에게는 그게 맞지만, 리포트 쪽에 지시가 없으면 모델은 **모르는 것을 있었던 일로 적는다.**
    두 프롬프트가 같은 축을 반대로 다루면 대화에서 지킨 것이 리포트에서 무너진다.
    """

    def setUp(self):
        self.text = prompts_registry.load("report_diary")

    def test_unknown_reality_is_left_unknown(self):
        self.assertIn("둘 중 하나로 정하지 마", self.text)

    def test_imagined_story_is_recorded_as_a_told_story(self):
        self.assertIn("실제로 있었던 일처럼 적지 마", self.text)

    def test_time_is_not_invented(self):
        self.assertIn("시점을 말하지 않았으면", self.text)
        self.assertIn("활동을 한 날짜와 그림 속 일이 일어난 때는 다르다", self.text)

    def test_htp_prompt_is_untouched(self):
        # 이 규칙은 자유 그림에만 붙인다. HTP는 주제가 정해진 활동이라 축이 다르다.
        htp = prompts_registry.load("report_htp")
        self.assertNotIn("상상한 이야기", htp)


# ── 주제별 관찰 (875 §5) ─────────────────────────────────────────
def _htp_subject(subject, description="집이 가운데에 크게 그려져 있어요.", **overrides):
    """주제 하나의 요청 블록. 근거 식별자를 함께 실어 경향 카드 검증에도 쓸 수 있게 한다."""
    base = {
        "drawing_subject": subject,
        "drawing_description": description,
        "observation_evidence_source_id": f"obs-{subject}",
    }
    base.update(overrides)
    return contracts.SubjectSummary(**base)


def _htp_three_subject_request(**overrides):
    """집·나무·사람 세 장 + 근거 식별자가 실린 HTP 요청.

    ⚠️ 주제를 **일부러 나무→사람→집 순서로** 넣는다. 875 §5의 표시 순서(집→나무→사람)는
       요청 순서가 아니라 계약이므로, 요청이 뒤섞여 와도 출력이 고정되는지 봐야 한다.
    """
    overrides.setdefault(
        "subject_summaries",
        [
            _htp_subject("TREE", "나무가 왼쪽에 서 있어요."),
            _htp_subject(
                "PERSON",
                "사람 두 명이 나란히 서 있어요.",
                qa_pairs=[
                    contracts.SubjectQaPair(
                        question="이 사람은 누구야?",
                        answer_text="엄마랑 나",
                        answer_message_id=202,
                    )
                ],
            ),
            _htp_subject("HOUSE"),
        ],
    )
    overrides.setdefault(
        "selected_emotion_refs",
        [contracts.SelectedEmotionRef(emotion_code="JOY", evidence_source_id="e5")],
    )
    overrides.setdefault("activity_metric_source_id", "m1")
    return _sample_request(**overrides)


def _subject_report(subject, observations, refs=None):
    return {
        "subjectType": subject,
        "visionObservations": observations,
        "interpretationRefs": refs if refs is not None else [],
    }


class SubjectReportsTest(unittest.TestCase):
    """주제별 관찰 조립 — 875 §5.

    HTP는 집·나무·사람 세 장을 그리는데 출력에 주제 구분이 남지 않아 보호자 화면의
    '주제별 관찰 사실과 문답' 섹션을 만들 재료가 없었다. 여기서 보는 것은 세 가지다:
    골격이 **요청**에서 나오는가 · 순서가 계약대로인가 · 카드 참조가 재매핑되는가.
    """

    def _generate(self, req=None, review=_REVIEW_PASS, **overrides):
        fake_client = _fake_client(_llm_json(**overrides), review)
        # RAG는 이 검증의 관심사가 아니다 — HTP 경로라 검색을 타므로 비워서 막는다.
        with mock.patch.object(report_client, "get_client", return_value=fake_client), \
                mock.patch.object(report_client, "retrieve", return_value=[]):
            return report_client.generate(req or _htp_three_subject_request(), model="m")

    def test_subject_order_is_house_tree_person_regardless_of_input_order(self):
        """요청도 모델 출력도 뒤섞여 있어도 표시 순서는 계약이 정한다(875 §5)."""
        result = self._generate(
            subjectReports=[
                _subject_report("PERSON", ["사람 두 명이 나란히 서 있어요."]),
                _subject_report("HOUSE", ["집이 가운데에 크게 그려져 있어요."]),
                _subject_report("TREE", ["나무가 왼쪽에 서 있어요."]),
            ]
        )
        self.assertEqual(
            [r.subject_type for r in result.subject_reports], ["HOUSE", "TREE", "PERSON"]
        )

    def test_skeleton_comes_from_the_request_not_the_model(self):
        """모델이 주제를 빠뜨려도 그 그림이 리포트에서 사라지지 않는다."""
        result = self._generate(
            subjectReports=[_subject_report("HOUSE", ["집이 가운데에 크게 그려져 있어요."])]
        )
        self.assertEqual(
            [r.subject_type for r in result.subject_reports], ["HOUSE", "TREE", "PERSON"]
        )
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(by_subject["HOUSE"].vision_observations, ["집이 가운데에 크게 그려져 있어요."])
        self.assertEqual(by_subject["TREE"].vision_observations, [])

    def test_subject_that_was_not_drawn_is_dropped(self):
        """요청에 없는 주제는 그리지 않은 그림이다 — 모델이 지어내도 싣지 않는다."""
        req = _sample_request(subject_summaries=[_htp_subject("HOUSE")])
        result = self._generate(
            req=req,
            subjectReports=[
                _subject_report("HOUSE", ["집이 가운데에 크게 그려져 있어요."]),
                _subject_report("PERSON", ["사람을 그렸어요."]),
            ],
        )
        self.assertEqual([r.subject_type for r in result.subject_reports], ["HOUSE"])

    def test_observation_needs_a_description_to_lean_on(self):
        """관찰 서술이 없는 그림에 관찰 사실을 적는 것은 관찰이 아니라 창작이다."""
        req = _sample_request(subject_summaries=[_htp_subject("HOUSE", description="")])
        result = self._generate(
            req=req, subjectReports=[_subject_report("HOUSE", ["집을 크게 그렸어요."])]
        )
        self.assertEqual(result.subject_reports[0].vision_observations, [])

    def test_unsafe_expression_drops_the_sentence_and_keeps_report_unreviewed(self):
        """사실 자리에 낙인이 섞이면 다른 문장들이 그걸 사실로 알고 기댄다 — 문장은 빼고 닫는다."""
        result = self._generate(
            subjectReports=[
                _subject_report(
                    "HOUSE", ["자존감이 낮습니다.", "집이 가운데에 크게 그려져 있어요."]
                )
            ]
        )
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(
            by_subject["HOUSE"].vision_observations, ["집이 가운데에 크게 그려져 있어요."]
        )
        self.assertEqual(result.observation_draft.status, "AI_DRAFT")

    def test_observations_are_capped_per_subject(self):
        result = self._generate(
            subjectReports=[_subject_report("HOUSE", [f"관찰 {i}" for i in range(9)])]
        )
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(
            len(by_subject["HOUSE"].vision_observations),
            report_client._VISION_OBSERVATIONS_PER_SUBJECT_MAX,
        )

    def test_legacy_request_without_subjects_stays_empty(self):
        """구 BE(주제 블록 미전달)는 지금까지와 똑같이 동작한다 — 롤아웃 안전."""
        fake_client = _fake_client(
            _llm_json(subjectReports=[_subject_report("HOUSE", ["집을 그렸어요."])])
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client):
            result = report_client.generate(_sample_request(), model="m")
        self.assertEqual(result.subject_reports, [])

    def test_model_silence_keeps_every_other_field_intact(self):
        """모델이 subjectReports 를 아예 안 보내도 기존 경로는 그대로다(필드 단위 롤아웃 안전)."""
        result = self._generate()
        self.assertEqual(
            [r.subject_type for r in result.subject_reports], ["HOUSE", "TREE", "PERSON"]
        )
        self.assertTrue(all(not r.vision_observations for r in result.subject_reports))
        self.assertIn("즐겁게", result.observation_draft.overall_summary)
        self.assertEqual(result.observation_draft.status, "AI_REVIEWED")


class SubjectInterpretationRefsTest(unittest.TestCase):
    """interpretationRefs 재매핑 — 875 §5-1.

    참조는 카드 **배열 위치**다. 게이트·자체검토가 카드를 뺄 때마다 뒤 카드가 앞으로 당겨지는데,
    참조를 그대로 두면 조용히 다른 카드를 가리킨다. 875가 "재정렬하지 마라"로 경고한 사고다.
    """

    def _generate(self, review=_REVIEW_PASS, **overrides):
        fake_client = _fake_client(_llm_json(**overrides), review)
        with mock.patch.object(report_client, "get_client", return_value=fake_client), \
                mock.patch.object(report_client, "retrieve", return_value=[]):
            return report_client.generate(_htp_three_subject_request(), model="m")

    def _two_good_evidences(self):
        # QA_ANSWER + EMOTION_SELECTION → 독립 근거 2건·아이 표현 1건(888 게이트 통과).
        return [
            _evidence(1),
            _evidence(2, source_type="SELECTED_EMOTION", kind="EMOTION_SELECTION", ref="e5"),
        ]

    def test_ref_survives_when_card_survives(self):
        result = self._generate(
            evidenceItems=self._two_good_evidences(),
            publicInterpretations=[_card([1, 2])],
            subjectReports=[_subject_report("HOUSE", ["집을 크게 그렸어요."], refs=[0])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(by_subject["HOUSE"].interpretation_refs, [0])

    def test_ref_is_remapped_when_an_earlier_card_fails_the_gate(self):
        """0번 카드가 근거 부족으로 빠지면 1번이 0번이 된다 — 참조도 함께 옮겨야 한다."""
        result = self._generate(
            evidenceItems=self._two_good_evidences(),
            publicInterpretations=[
                _card([1], category="EMOTION"),  # 독립 근거 1건 → 게이트 탈락
                _card([1, 2]),
            ],
            subjectReports=[_subject_report("HOUSE", ["집을 크게 그렸어요."], refs=[1])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        self.assertEqual(result.public_interpretations[0].category, "RELATIONSHIP")
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(by_subject["HOUSE"].interpretation_refs, [0])

    def test_ref_to_a_dropped_card_disappears(self):
        result = self._generate(
            evidenceItems=self._two_good_evidences(),
            publicInterpretations=[_card([1], category="EMOTION")],  # 게이트 탈락
            subjectReports=[_subject_report("HOUSE", ["집을 크게 그렸어요."], refs=[0])],
        )
        self.assertEqual(result.public_interpretations, [])
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(by_subject["HOUSE"].interpretation_refs, [])

    def test_ref_is_remapped_when_self_review_removes_an_earlier_card(self):
        """자체검토가 카드를 빼는 경로에서도 같은 재매핑이 필요하다."""
        result = self._generate(
            review=_review_findings({"target": "card.0", "issue": "NO_EVIDENCE"}),
            evidenceItems=self._two_good_evidences(),
            publicInterpretations=[_card([1, 2], category="EMOTION"), _card([1, 2])],
            subjectReports=[_subject_report("HOUSE", ["집을 크게 그렸어요."], refs=[0, 1])],
        )
        self.assertEqual(len(result.public_interpretations), 1)
        self.assertEqual(result.public_interpretations[0].category, "RELATIONSHIP")
        by_subject = {r.subject_type: r for r in result.subject_reports}
        # 빠진 0번 참조는 사라지고, 살아남은 1번이 0번으로 당겨진다.
        self.assertEqual(by_subject["HOUSE"].interpretation_refs, [0])

    def test_unknown_ref_is_dropped(self):
        result = self._generate(
            evidenceItems=self._two_good_evidences(),
            publicInterpretations=[_card([1, 2])],
            subjectReports=[
                _subject_report("HOUSE", ["집을 크게 그렸어요."], refs=[0, 7, "x"])
            ],
        )
        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(by_subject["HOUSE"].interpretation_refs, [0])


class SubjectObservationSelfReviewTest(unittest.TestCase):
    """주제별 관찰이 자체검토를 통과하는 경로 (2-pass).

    사실 자리에 해석이 섞이는 것(MIXED_EVIDENCE)은 정규식으로 잡히지 않아 검토자가 맡는다.
    지적은 **그 문장만** 빼서 담아내므로 리포트를 막지 않는다.
    """

    def _generate(self, review=_REVIEW_PASS, **overrides):
        fake_client = _fake_client(_llm_json(**overrides), review)
        with mock.patch.object(report_client, "get_client", return_value=fake_client), \
                mock.patch.object(report_client, "retrieve", return_value=[]):
            return report_client.generate(_htp_three_subject_request(), model="m")

    def test_observations_are_offered_to_the_reviewer_as_fact_slots(self):
        captured = {}
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(
            captured,
            _llm_json(
                subjectReports=[_subject_report("HOUSE", ["집이 가운데에 크게 그려져 있어요."])]
            ),
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client), \
                mock.patch.object(report_client, "retrieve", return_value=[]):
            report_client.generate(_htp_three_subject_request(), model="m")

        payload = json.loads(captured["review_messages"][1]["content"])
        targets = {t["id"]: t for t in payload["검토 대상"]}
        self.assertIn("subject.0.0", targets)
        self.assertEqual(targets["subject.0.0"]["자리"], report_client._FACT_SLOT_LABEL)
        # 근거로도 함께 넘긴다 — 안 넘기면 이 관찰에 기댄 문장이 NO_EVIDENCE 로 오탐된다.
        self.assertIn("집이 가운데에 크게 그려져 있어요.", payload["관찰 사실"])

    def test_flagged_observation_is_removed_but_report_still_opens(self):
        fake_client = _fake_client(
            _llm_json(
                subjectReports=[
                    _subject_report(
                        "HOUSE", ["집이 가운데에 크게 그려져 있어요.", "차분하게 몰입했어요."]
                    )
                ]
            ),
            _review_findings({"target": "subject.0.1", "issue": "MIXED_EVIDENCE"}),
        )
        with mock.patch.object(report_client, "get_client", return_value=fake_client), \
                mock.patch.object(report_client, "retrieve", return_value=[]):
            result = report_client.generate(_htp_three_subject_request(), model="m")

        by_subject = {r.subject_type: r for r in result.subject_reports}
        self.assertEqual(
            by_subject["HOUSE"].vision_observations, ["집이 가운데에 크게 그려져 있어요."]
        )
        # 담아낼 수 있는 지적이라 리포트 전체를 막지 않는다(feature·card와 같은 처리).
        self.assertEqual(result.observation_draft.status, "AI_REVIEWED")

    def test_prompt_forbids_interpretation_in_the_fact_slot(self):
        text = prompts_registry.load("report_htp")
        self.assertIn("subjectReports", text)
        self.assertIn("눈으로 확인된 사실", text)
        self.assertIn("interpretationRefs", text)

    def test_review_prompt_knows_the_fact_slot_label(self):
        self.assertIn(
            report_client._FACT_SLOT_LABEL, prompts_registry.load("report_review")
        )


class SubjectReportContractTest(unittest.TestCase):
    """계약 모델 — BE가 1:1로 맞춰야 하는 형태. 신설 필드는 전부 기본값이 있다.

    ⚠️ 2026-08-05 운영에서 신설 필드를 필수로 둔 탓에 요청이 전량 422로 떨어진 적이 있다(933).
       롤아웃 안전은 목록이 아니라 **필드 단위**로 지킨다.
    """

    def test_result_is_constructible_without_the_new_field(self):
        result = contracts.ObservationGenerationResult(
            request_id="r",
            model_name="m",
            model_version="v",
            observation_draft=contracts.ObservationDraft(
                overall_summary="요약",
                positive_signals="긍정",
                attention_points="특이 관찰 사항 없음",
                evidence_summary="근거",
                guardian_guidance="안내",
                follow_up_question="질문?",
                disclaimer=report_client.DISCLAIMER,
            ),
            conversation_summary=contracts.ConversationSummaryDraft(
                summary_text="대화",
                main_topic="주제",
                expressed_emotion="즐거움",
                emotion_source="SELECTED",
                representative_utterance="응",
            ),
            limitations_text=report_client.LIMITATIONS,
        )
        self.assertEqual(result.subject_reports, [])

    def test_subject_report_defaults_are_empty(self):
        draft = contracts.SubjectReportDraft()
        self.assertIsNone(draft.subject_type)
        self.assertEqual(draft.vision_observations, [])
        self.assertEqual(draft.interpretation_refs, [])

    def test_serialises_with_the_875_field_names(self):
        payload = contracts.SubjectReportDraft(
            subject_type="HOUSE", vision_observations=["집"], interpretation_refs=[0]
        ).model_dump(by_alias=True)
        self.assertEqual(
            payload,
            {
                "subjectType": "HOUSE",
                "visionObservations": ["집"],
                "interpretationRefs": [0],
            },
        )

    def test_image_url_and_qa_pairs_are_not_ai_owned(self):
        """875 §5의 나머지 둘은 BE가 채운다 — 아이 발화를 LLM에 되돌려 받지 않는다."""
        fields = contracts.SubjectReportDraft.model_fields
        self.assertNotIn("image_url", fields)
        self.assertNotIn("qa_pairs", fields)


class ReportModelSelectionTest(unittest.TestCase):
    """리포트는 대화와 다른 모델을 쓴다 (S15P11B209-972).

    두 경로가 한 변수를 공유하던 시절엔 리포트 모델을 올리면 대화 지연이 함께 올라갔다.
    배선이 되돌아가면(다시 config.LLM_MODEL 을 읽으면) 이 테스트가 깨진다 — 두 값이 같은
    로컬·CI 기본 환경에서는 어느 쪽을 읽든 통과하므로, **일부러 다른 값**을 주입해 본다.
    """

    def _generate(self, captured: dict, **overrides):
        fake_client = mock.Mock()
        fake_client.chat.completions.create.side_effect = _capture_generation(captured)
        with (
            mock.patch.object(report_client, "get_client", return_value=fake_client),
            mock.patch.object(config, "LLM_MODEL", "conversation-model"),
            mock.patch.object(config, "REPORT_LLM_MODEL", "report-model"),
        ):
            return report_client.generate(
                _sample_request(), drawing_description="가운데에 집이 크게 있어요.", **overrides
            )

    def test_generation_call_uses_report_model_not_conversation_model(self):
        captured: dict = {}
        self._generate(captured)
        self.assertEqual(captured["model"], "report-model")
        self.assertNotEqual(captured["model"], "conversation-model")

    def test_self_review_uses_the_same_model_as_generation(self):
        """생성과 검토가 다른 모델이면 버전 태그는 하나인데 열림 기준이 둘이 된다."""
        captured: dict = {}
        self._generate(captured)
        self.assertEqual(captured["review_model"], captured["model"])

    def test_explicit_model_argument_still_wins(self):
        """draft·스모크가 넘기는 명시 인자는 env 설정보다 우선한다(기존 동작 유지)."""
        captured: dict = {}
        result = self._generate(captured, model="explicit-model")
        self.assertEqual(captured["model"], "explicit-model")
        self.assertEqual(captured["review_model"], "explicit-model")
        # 서빙 모델 응답이 없으면 요청 모델명이 재현성 기록으로 남는다.
        self.assertEqual(result.model_name, "explicit-model")


if __name__ == "__main__":
    unittest.main()
